<?php
$themeColors = [];
if ($theme) {
    $decoded = json_decode($theme['custom_colors'], true);
    if (is_array($decoded)) {
        $themeColors = $decoded;
    }
}
$primary = $themeColors['primary_color'] ?? '#0d6efd';
$secondary = $themeColors['secondary_color'] ?? '#6c757d';
$bg = $themeColors['bg_color'] ?? '#f4f7ff';
$text = $themeColors['text_color'] ?? '#1f2937';
$sidebar = $themeColors['sidebar_color'] ?? '#1f2937';
$card = $themeColors['card_color'] ?? '#ffffff';
?>
<div class="chat-shell" style="--primary-color: <?= htmlspecialchars($primary) ?>; --secondary-color: <?= htmlspecialchars($secondary) ?>; --bg-color: <?= htmlspecialchars($bg) ?>; --text-color: <?= htmlspecialchars($text) ?>; --sidebar-color: <?= htmlspecialchars($sidebar) ?>; --card-color: <?= htmlspecialchars($card) ?>;">
    <div class="chat-sidebar">
        <div class="chat-sidebar-header">
            <h5><i class="bi bi-chat-dots"></i> Messages</h5>
            <button class="btn btn-sm btn-outline-light" data-bs-toggle="modal" data-bs-target="#themeModal"><i class="bi bi-palette"></i></button>
        </div>
        <div class="chat-contact-list">
            <?php foreach ($contacts as $contact): ?>
                <button class="chat-contact" data-contact-id="<?= (int)$contact['id'] ?>">
                    <div class="avatar"><?= strtoupper(substr($contact['full_name'], 0, 1)) ?></div>
                    <div class="contact-body">
                        <div class="contact-name"><?= htmlspecialchars($contact['full_name']) ?></div>
                        <div class="contact-role"><?= htmlspecialchars($contact['role']) ?></div>
                    </div>
                    <span class="status-dot online"></span>
                </button>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="chat-main">
        <div class="chat-header">
            <div class="d-flex align-items-center gap-2">
                <div class="avatar large">U</div>
                <div>
                    <h6 class="mb-0">Select a contact</h6>
                    <small class="text-muted">Online</small>
                </div>
            </div>
            <div class="chat-actions">
                <button class="btn btn-sm btn-light"><i class="bi bi-telephone"></i></button>
                <button class="btn btn-sm btn-light"><i class="bi bi-camera-video"></i></button>
            </div>
        </div>

        <div id="chatMessages" class="chat-messages"></div>

        <div class="chat-input-bar">
            <button class="btn btn-outline-secondary" type="button"><i class="bi bi-plus-lg"></i></button>
            <input id="messageInput" class="form-control" placeholder="Type a message" />
            <button class="btn btn-outline-secondary" type="button"><i class="bi bi-emoji-smile"></i></button>
            <button class="btn btn-outline-secondary" type="button"><i class="bi bi-mic"></i></button>
            <button id="sendMessageBtn" class="btn btn-primary" type="button"><i class="bi bi-send"></i></button>
        </div>
        <div class="call-panel">
            <button class="btn btn-success btn-sm"><i class="bi bi-telephone"></i> Audio call</button>
            <button class="btn btn-danger btn-sm"><i class="bi bi-camera-video"></i> Video call</button>
            <a class="btn btn-outline-secondary btn-sm" href="/print/report"><i class="bi bi-printer"></i> Print report</a>
        </div>
    </div>
</div>

<div class="modal fade" id="themeModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Theme Customizer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Preset themes</label>
            <select id="themePreset" class="form-select">
              <?php foreach ($presetThemes as $preset): ?>
                <option value="<?= htmlspecialchars($preset['name']) ?>"><?= htmlspecialchars($preset['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Primary color</label>
            <input id="primaryColor" type="color" class="form-control form-control-color" value="<?= htmlspecialchars($primary) ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Background color</label>
            <input id="bgColor" type="color" class="form-control form-control-color" value="<?= htmlspecialchars($bg) ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Text color</label>
            <input id="textColor" type="color" class="form-control form-control-color" value="<?= htmlspecialchars($text) ?>">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" id="saveThemeBtn" class="btn btn-primary">Save theme</button>
      </div>
    </div>
  </div>
</div>

<script>
window.currentChatId = null;
window.currentContactId = null;
</script>
