<?php require_once __DIR__ . '/layouts/main.php'; ?>

<div class="hero-section">
    <div class="container">
        <h1>Welcome to Abuu Nufay'sah University</h1>
        <p>Your gateway to quality education and academic excellence</p>
        
        <div class="cta-buttons">
            <?php if ($auth->isAuthenticated()): ?>
                <?php if ($auth->getCurrentRole() === 'admin'): ?>
                    <a href="/admin/dashboard" class="btn btn-primary">Go to Dashboard</a>
                <?php elseif ($auth->getCurrentRole() === 'lecturer'): ?>
                    <a href="/lecturer/dashboard" class="btn btn-primary">Go to Dashboard</a>
                <?php elseif ($auth->getCurrentRole() === 'student'): ?>
                    <a href="/student/dashboard" class="btn btn-primary">Go to Dashboard</a>
                <?php endif; ?>
            <?php else: ?>
                <a href="/login" class="btn btn-primary">Login</a>
                <a href="/register" class="btn btn-secondary">Register</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="features-section">
    <div class="container">
        <div class="mb-4">
            <a href="/privacy-policy" class="me-3">Privacy Policy</a>
            <a href="/terms-of-service" class="me-3">Terms of Service</a>
            <a href="/cookie-policy" class="me-3">Cookie Policy</a>
            <a href="/data-protection-policy">Data Protection Policy</a>
        </div>
        <div class="feature-grid">
            <div class="feature-card">
                <h3>Quality Education</h3>
                <p>Access world-class educational resources and experienced faculty</p>
            </div>
            <div class="feature-card">
                <h3>Modern Facilities</h3>
                <p>State-of-the-art classrooms, laboratories, and library</p>
            </div>
            <div class="feature-card">
                <h3>Student Support</h3>
                <p>Comprehensive support services for academic and personal growth</p>
            </div>
        </div>
    </div>
</div>
