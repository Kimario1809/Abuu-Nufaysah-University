<?php
/**
 * Push Notification Toggle Component
 * Reusable toggle for enabling/disabling push notifications
 */

use App\Core\Auth;
use App\Core\Env;

$auth = Auth::getInstance();
$vapidPublicKey = Env::get('VAPID_PUBLIC_KEY', '');
?>

<!-- Push Notification Toggle -->
<div class="push-notification-toggle-container">
    <label class="push-notification-toggle">
        <input type="checkbox" class="push-notification-toggle-checkbox" id="pushToggle">
        <span class="push-notification-toggle-slider"></span>
        <span class="push-notification-toggle-label">
            <i class="bi bi-bell"></i>
            Push Notifications
        </span>
    </label>
    <span class="push-notification-status" id="pushStatus"></span>
</div>

<!-- VAPID Public Key -->
<meta name="vapid-key" content="<?php echo htmlspecialchars($vapidPublicKey); ?>">

<!-- Include Push Notification Script -->
<script src="/assets/js/push-notifications.js"></script>

<style>
.push-notification-toggle-container {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 8px 12px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 8px;
    margin-right: 16px;
}

.push-notification-toggle {
    display: flex;
    align-items: center;
    cursor: pointer;
    user-select: none;
}

.push-notification-toggle-checkbox {
    display: none;
}

.push-notification-toggle-slider {
    position: relative;
    width: 44px;
    height: 24px;
    background-color: rgba(255, 255, 255, 0.3);
    border-radius: 12px;
    transition: background-color 0.3s ease;
}

.push-notification-toggle-slider::before {
    content: '';
    position: absolute;
    top: 2px;
    left: 2px;
    width: 20px;
    height: 20px;
    background-color: white;
    border-radius: 50%;
    transition: transform 0.3s ease;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.push-notification-toggle-checkbox:checked + .push-notification-toggle-slider {
    background-color: #28a745;
}

.push-notification-toggle-checkbox:checked + .push-notification-toggle-slider::before {
    transform: translateX(20px);
}

.push-notification-toggle-label {
    display: flex;
    align-items: center;
    gap: 6px;
    color: white;
    font-size: 0.9rem;
    font-weight: 500;
}

.push-notification-toggle-label i {
    font-size: 1rem;
}

.push-notification-status {
    font-size: 0.75rem;
    color: rgba(255, 255, 255, 0.7);
}

@media (max-width: 768px) {
    .push-notification-toggle-container {
        padding: 6px 10px;
    }
    
    .push-notification-toggle-label {
        display: none;
    }
}
</style>

<script>
// Initialize push notification toggle state
document.addEventListener('DOMContentLoaded', function() {
    const toggle = document.getElementById('pushToggle');
    const status = document.getElementById('pushStatus');
    
    if (toggle && window.pushNotificationManager) {
        // Set initial state based on subscription status
        const isSubscribed = window.pushNotificationManager.isSubscribed();
        toggle.checked = isSubscribed;
        
        if (isSubscribed) {
            status.textContent = 'Enabled';
        } else {
            status.textContent = 'Disabled';
        }
        
        // Update status on permission change
        const originalOnPermissionGranted = window.pushNotificationManager.onPermissionGranted;
        const originalOnPermissionDenied = window.pushNotificationManager.onPermissionDenied;
        
        window.pushNotificationManager.onPermissionGranted = function() {
            if (originalOnPermissionGranted) originalOnPermissionGranted();
            status.textContent = 'Enabled';
        };
        
        window.pushNotificationManager.onPermissionDenied = function() {
            if (originalOnPermissionDenied) originalOnPermissionDenied();
            status.textContent = 'Denied';
        };
    }
});
</script>
