<?php
/**
 * Mobile Bottom Navigation
 * App-like bottom navigation for PWA mobile experience
 */

use App\Core\Auth;

$auth = Auth::getInstance();
$role = $auth->getCurrentRole();
$currentPath = $_SERVER['REQUEST_URI'] ?? '/';
?>

<!-- Mobile Bottom Navigation -->
<nav class="mobile-bottom-nav d-md-none">
    <a href="/<?= $role ?>/dashboard" class="nav-item <?= strpos($currentPath, 'dashboard') !== false ? 'active' : '' ?>">
        <i class="bi bi-speedometer2"></i>
        <span>Dashboard</span>
    </a>
    
    <?php if ($role === 'admin' || $role === 'lecturer'): ?>
    <a href="/courses" class="nav-item <?= strpos($currentPath, 'courses') !== false ? 'active' : '' ?>">
        <i class="bi bi-book"></i>
        <span>Courses</span>
    </a>
    <?php endif; ?>
    
    <?php if ($role === 'student'): ?>
    <a href="/student/courses" class="nav-item <?= strpos($currentPath, 'student/courses') !== false ? 'active' : '' ?>">
        <i class="bi bi-book"></i>
        <span>Courses</span>
    </a>
    <?php endif; ?>
    
    <a href="/notifications" class="nav-item <?= strpos($currentPath, 'notifications') !== false ? 'active' : '' ?>">
        <i class="bi bi-bell"></i>
        <span>Notifications</span>
    </a>
    
    <a href="/<?= $role ?>/profile" class="nav-item <?= strpos($currentPath, 'profile') !== false ? 'active' : '' ?>">
        <i class="bi bi-person"></i>
        <span>Profile</span>
    </a>
</nav>

<style>
.mobile-bottom-nav {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 60px;
    background: white;
    border-top: 1px solid #dee2e6;
    display: flex;
    justify-content: space-around;
    align-items: center;
    z-index: 1000;
    padding-bottom: env(safe-area-inset-bottom);
}

.mobile-bottom-nav .nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex: 1;
    height: 100%;
    color: #6c757d;
    text-decoration: none;
    transition: all 0.3s ease;
    padding: 8px 4px;
}

.mobile-bottom-nav .nav-item i {
    font-size: 20px;
    margin-bottom: 4px;
}

.mobile-bottom-nav .nav-item span {
    font-size: 11px;
    font-weight: 500;
}

.mobile-bottom-nav .nav-item.active {
    color: #0d6efd;
}

.mobile-bottom-nav .nav-item:active {
    transform: scale(0.95);
}

/* Adjust spacing for PWA install button */
@media (max-width: 768px) {
    .mobile-bottom-nav {
        bottom: 0;
    }
    
    body:not(.offline) .mobile-bottom-nav {
        bottom: 0;
    }
}
</style>
