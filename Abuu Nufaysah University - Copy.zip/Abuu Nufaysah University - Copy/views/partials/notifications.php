<?php
/**
 * Notification Bell Component
 * Reusable notification bell with badge and dropdown
 */

use App\Core\Auth;
use App\Core\CSRF;

$auth = Auth::getInstance();
$csrfToken = CSRF::getToken();
?>

<!-- Notification Container -->
<div class="notification-container">
    <!-- Notification Bell -->
    <div class="notification-bell" id="notificationBell" title="Notifications">
        <i class="bi bi-bell"></i>
        <span class="notification-badge" id="notificationBadge"></span>
    </div>
    
    <!-- Notification Dropdown -->
    <div class="notification-dropdown" id="notificationDropdown">
        <!-- Header -->
        <div class="notification-header">
            <h3>Notifications</h3>
            <div class="notification-header-actions">
                <button id="markAllReadBtn" title="Mark all as read">
                    <i class="bi bi-check-all"></i>
                </button>
                <button id="refreshNotificationsBtn" title="Refresh">
                    <i class="bi bi-arrow-clockwise"></i>
                </button>
                <button id="closeNotificationsBtn" title="Close">
                    <i class="bi bi-x"></i>
                </button>
            </div>
        </div>
        
        <!-- Notification List -->
        <div class="notification-list" id="notificationList">
            <div class="notification-empty">
                <i class="bi bi-bell-slash"></i>
                <p>Loading notifications...</p>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="notification-footer">
            <a href="/notifications">View All Notifications</a>
        </div>
    </div>
</div>

<!-- CSRF Token for AJAX requests -->
<meta name="csrf-token" content="<?php echo htmlspecialchars($csrfToken); ?>">

<!-- Include Notification Styles -->
<link rel="stylesheet" href="/assets/css/notifications.css">

<!-- Include Notification Script -->
<script src="/assets/js/notifications.js"></script>

<script>
// Initialize notification dropdown toggle
document.addEventListener('DOMContentLoaded', function() {
    const bell = document.getElementById('notificationBell');
    const dropdown = document.getElementById('notificationDropdown');
    const closeBtn = document.getElementById('closeNotificationsBtn');
    const markAllReadBtn = document.getElementById('markAllReadBtn');
    const refreshBtn = document.getElementById('refreshNotificationsBtn');
    
    // Toggle dropdown on bell click
    if (bell) {
        bell.addEventListener('click', function(e) {
            e.stopPropagation();
            dropdown.classList.toggle('active');
        });
    }
    
    // Close dropdown on close button click
    if (closeBtn) {
        closeBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            dropdown.classList.remove('active');
        });
    }
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!dropdown.contains(e.target) && !bell.contains(e.target)) {
            dropdown.classList.remove('active');
        }
    });
    
    // Mark all as read
    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', async function(e) {
            e.stopPropagation();
            
            if (window.notificationPoller) {
                const success = await window.notificationPoller.markAllAsRead();
                if (success) {
                    // Update UI
                    document.querySelectorAll('.notification-item.unread').forEach(item => {
                        item.classList.remove('unread');
                        item.classList.add('read');
                        const markBtn = item.querySelector('.notification-mark-read');
                        if (markBtn) markBtn.remove();
                    });
                }
            }
        });
    }
    
    // Refresh notifications
    if (refreshBtn) {
        refreshBtn.addEventListener('click', async function(e) {
            e.stopPropagation();
            
            if (window.notificationPoller) {
                refreshBtn.querySelector('i').classList.add('spin');
                await window.notificationPoller.poll();
                refreshBtn.querySelector('i').classList.remove('spin');
            }
        });
    }
    
    // Handle WebSocket notifications
    document.addEventListener('websocketNotification', function(e) {
        const notification = e.detail;
        
        // Play sound
        if (typeof playNotificationSound === 'function') {
            playNotificationSound();
        }
        
        // Update badge
        const badge = document.getElementById('notificationBadge');
        if (badge) {
            const currentCount = parseInt(badge.textContent) || 0;
            badge.textContent = currentCount + 1;
            badge.style.display = 'flex';
            
            // Pulse animation
            badge.style.animation = 'none';
            badge.offsetHeight; // Trigger reflow
            badge.style.animation = 'pulse 0.5s ease-out';
        }
        
        // Add to notification list if dropdown is open
        const dropdown = document.getElementById('notificationDropdown');
        if (dropdown && dropdown.classList.contains('active')) {
            const list = document.getElementById('notificationList');
            if (list && window.notificationPoller) {
                // Prepend new notification
                const notificationHtml = window.notificationPoller.renderNotificationItem(notification, true);
                const emptyState = list.querySelector('.notification-empty');
                if (emptyState) {
                    emptyState.remove();
                }
                list.insertAdjacentHTML('afterbegin', notificationHtml);
                
                // Limit to 10 notifications in dropdown
                const items = list.querySelectorAll('.notification-item');
                if (items.length > 10) {
                    items[items.length - 1].remove();
                }
            }
        }
        
        // Show toast notification
        showToastNotification(notification);
    });
    
    // Show toast notification for real-time alerts
    function showToastNotification(notification) {
        // Remove existing toast if any
        const existingToast = document.querySelector('.ws-toast .toast');
        if (existingToast) {
            existingToast.remove();
        }
        
        // Create toast container if not exists
        let toastContainer = document.querySelector('.ws-toast');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'ws-toast';
            document.body.appendChild(toastContainer);
        }
        
        // Create toast
        const toast = document.createElement('div');
        toast.className = 'toast show';
        toast.innerHTML = `
            <div class="toast-header">
                <i class="bi bi-bell me-2"></i>
                <strong class="me-auto">New Notification</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                <strong>${notification.title}</strong><br>
                ${notification.message}
                ${notification.link ? `<br><a href="${notification.link}" class="text-primary">View</a>` : ''}
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            toast.remove();
        }, 5000);
        
        // Close button handler
        toast.querySelector('.btn-close').addEventListener('click', () => {
            toast.remove();
        });
    }
    
    // Add spin animation for refresh button
    const style = document.createElement('style');
    style.textContent = `
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        .spin {
            animation: spin 0.5s linear infinite;
        }
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.3); }
            100% { transform: scale(1); }
        }
    `;
    document.head.appendChild(style);
});
</script>
