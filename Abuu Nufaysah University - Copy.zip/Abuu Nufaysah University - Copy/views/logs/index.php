<?php
$auth = App\Core\Auth::getInstance();
$user = $auth->getCurrentUser();
$logger = App\Core\Logger::getInstance();
$files = $logger->getLogFiles();
$stats = $logger->getStats();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs - Abuu Nufay'sah University</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5><i class="bi bi-file-text"></i> System Logs</h5>
                        <div>
                            <span class="badge bg-info me-2">Files: <?= $stats['total_files'] ?></span>
                            <span class="badge bg-success me-2">Size: <?= $stats['total_size'] ?></span>
                            <span class="badge bg-warning">Archive: <?= $stats['archive_count'] ?></span>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if (empty($files)): ?>
                            <p class="text-muted">No log files found.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>File Name</th>
                                            <th>Size</th>
                                            <th>Modified</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($files as $file): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($file['name']) ?></td>
                                            <td><?= $file['size_formatted'] ?></td>
                                            <td><?= date('Y-m-d H:i:s', $file['modified']) ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-primary view-log" data-file="<?= $file['name'] ?>">
                                                    <i class="bi bi-eye"></i>
                                                </button>
                                                <button class="btn btn-sm btn-danger delete-log" data-file="<?= $file['name'] ?>">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Log Viewer Modal -->
        <div class="modal fade" id="logViewerModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Log Viewer</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div id="log-content" style="background: #1e1e1e; color: #d4d4d4; padding: 15px; border-radius: 5px; font-family: monospace; font-size: 12px; max-height: 500px; overflow: auto; white-space: pre-wrap;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(document).ready(function() {
        // View log
        $('.view-log').on('click', function() {
            const file = $(this).data('file');
            $.ajax({
                url: '/api/logs/' + file,
                method: 'GET',
                success: function(response) {
                    if (response.content) {
                        $('#log-content').text(response.content);
                        $('#logViewerModal').modal('show');
                    } else {
                        alert('No content found');
                    }
                },
                error: function() {
                    alert('Failed to load log file');
                }
            });
        });
        
        // Delete log
        $('.delete-log').on('click', function() {
            const file = $(this).data('file');
            if (confirm('Are you sure you want to delete ' + file + '?')) {
                $.ajax({
                    url: '/api/logs/' + file,
                    method: 'DELETE',
                    success: function() {
                        location.reload();
                    },
                    error: function() {
                        alert('Failed to delete log file');
                    }
                });
            }
        });
    });
    </script>
</body>
</html>