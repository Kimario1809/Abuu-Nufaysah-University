<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Assistant</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f4f7fb; }
        .chat-shell { max-width: 900px; margin: 30px auto; background: white; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,.08); overflow: hidden; }
        .chat-header { background: linear-gradient(135deg, #0d6efd, #7c3aed); color: white; padding: 18px 20px; }
        .chat-body { height: 480px; overflow-y: auto; padding: 20px; background: #fafcff; }
        .bubble { max-width: 75%; padding: 10px 14px; border-radius: 14px; margin-bottom: 10px; }
        .bubble.user { background: #0d6efd; color: white; margin-left: auto; }
        .bubble.assistant { background: #e9eefc; color: #24324a; }
        .chat-footer { padding: 15px; border-top: 1px solid #ddd; }
    </style>
</head>
<body>
<div class="chat-shell">
    <div class="chat-header">
        <h4 class="mb-0">AI Assistant</h4>
        <small>Ask about fees, timetable, attendance, results, and registration</small>
    </div>
    <div class="chat-body" id="chatBody"></div>
    <div class="chat-footer">
        <form id="aiForm" class="d-flex gap-2">
            <input type="text" id="message" class="form-control" placeholder="Type your question here..." required>
            <button class="btn btn-primary">Send</button>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function addBubble(sender, text) {
  const body = $('#chatBody');
  const cls = sender === 'user' ? 'user' : 'assistant';
  body.append(`<div class="bubble ${cls}">${text}</div>`);
  body.scrollTop(body[0].scrollHeight);
}

function loadHistory() {
  $.get('/ai/history', function (res) {
    $('#chatBody').empty();
    (res || []).forEach(item => addBubble(item.sender, item.message));
  });
}

$('#aiForm').on('submit', function (e) {
  e.preventDefault();
  const message = $('#message').val().trim();
  if (!message) return;
  addBubble('user', message);
  $('#message').val('');
  $.post('/ai/ask', { message }, function (res) {
    if (res.success) addBubble('assistant', res.answer);
    else addBubble('assistant', res.message || 'Sorry, the AI is unavailable.');
  }).fail(function () {
    addBubble('assistant', 'Sorry, the AI service is unavailable right now.');
  });
});

loadHistory();
</script>
</body>
</html>
