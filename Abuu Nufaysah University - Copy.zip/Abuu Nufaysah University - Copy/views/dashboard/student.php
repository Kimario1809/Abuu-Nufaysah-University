<?php
$auth = App\Core\Auth::getInstance();
$user = $auth->getCurrentUser();
?>
<div class="container-fluid mt-4">
    <!-- Welcome Section -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h3>Welcome back, <?= htmlspecialchars($user['full_name']) ?>!</h3>
                    <p class="text-muted">Student ID: <?= htmlspecialchars($stats['student']['student_id']) ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Stats Cards -->
    <div class="row">
        <div class="col-md-3 mb-3">
            <div class="card text-white bg-primary">
                <div class="card-body">
                    <h5 class="card-title">Current GPA</h5>
                    <h2 class="display-4"><?= number_format($stats['current_gpa'], 2) ?></h2>
                    <small>CGPA: <?= number_format($stats['current_gpa'], 2) ?></small>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <h5 class="card-title">Enrolled Courses</h5>
                    <h2 class="display-4"><?= count($stats['enrolled_courses']) ?></h2>
                    <small>This semester</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <h5 class="card-title">Pending Fees</h5>
                    <h2 class="display-4">$<?= number_format($stats['pending_fees'], 2) ?></h2>
                    <small>Due payments</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <h5 class="card-title">Attendance Rate</h5>
                    <h2 class="display-4"><?= $stats['attendance_rate'] ?>%</h2>
                    <small>This semester</small>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Timetable -->
    <div class="row mt-4">
        <div class="col-md-7">
            <div class="card">
                <div class="card-header">
                    <h5>My Timetable</h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($stats['timetable'])): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Day</th>
                                        <th>Time</th>
                                        <th>Course</th>
                                        <th>Venue</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($stats['timetable'] as $item): ?>
                                    <tr>
                                        <td><?= $item['day_of_week'] ?></td>
                                        <td><?= date('H:i', strtotime($item['start_time'])) ?> - 
                                            <?= date('H:i', strtotime($item['end_time'])) ?></td>
                                        <td><?= htmlspecialchars($item['course_code']) ?>: 
                                            <?= htmlspecialchars($item['course_name']) ?></td>
                                        <td><?= htmlspecialchars($item['venue'] ?? 'TBD') ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No classes scheduled</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Announcements -->
        <div class="col-md-5">
            <div class="card">
                <div class="card-header">
                    <h5>Recent Announcements</h5>
                </div>
                <div class="card-body" id="announcements-list">
                    <?php foreach ($announcements as $announcement): ?>
                    <div class="announcement-item mb-3">
                        <h6><?= htmlspecialchars($announcement['title']) ?></h6>
                        <small class="text-muted"><?= date('M d, Y', strtotime($announcement['created_at'])) ?></small>
                        <p class="mt-1"><?= htmlspecialchars(substr($announcement['content'], 0, 100)) ?>...</p>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>