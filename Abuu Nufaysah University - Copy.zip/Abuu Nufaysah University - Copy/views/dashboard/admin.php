<?php
$auth = App\Core\Auth::getInstance();
?>
<div class="container-fluid mt-4">
    <!-- Stats Cards -->
    <div class="row">
        <div class="col-md-3 mb-3">
            <div class="card text-white bg-primary">
                <div class="card-body">
                    <h5 class="card-title">Total Students</h5>
                    <h2 class="display-4" id="total-students"><?= $stats['total_students'] ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <h5 class="card-title">Total Courses</h5>
                    <h2 class="display-4" id="total-courses"><?= $stats['total_courses'] ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <h5 class="card-title">Pending Fees</h5>
                    <h2 class="display-4" id="pending-fees">$<?= number_format($stats['pending_fees'], 2) ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-white bg-danger">
                <div class="card-body">
                    <h5 class="card-title">New Announcements</h5>
                    <h2 class="display-4" id="new-announcements"><?= count($announcements) ?></h2>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Activity -->
    <div class="row mt-4">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5>Recent Enrollments</h5>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Course</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody id="recent-enrollments">
                            <?php foreach ($stats['recent_enrollments'] as $enrollment): ?>
                            <tr>
                                <td><?= htmlspecialchars($enrollment['student_name']) ?></td>
                                <td><?= htmlspecialchars($enrollment['course_name']) ?></td>
                                <td><?= date('M d, Y', strtotime($enrollment['enrollment_date'])) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5>Recent Announcements</h5>
                </div>
                <div class="card-body" id="announcements-list">
                    <?php foreach ($announcements as $announcement): ?>
                    <div class="announcement-item mb-3">
                        <h6><?= htmlspecialchars($announcement['title']) ?></h6>
                        <small class="text-muted"><?= date('M d, Y H:i', strtotime($announcement['created_at'])) ?></small>
                        <p class="mt-2"><?= htmlspecialchars(substr($announcement['content'], 0, 100)) ?>...</p>
                    </div>
                    <hr>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Real-time updates using AJAX polling
setInterval(function() {
    $.ajax({
        url: '/api/dashboard-stats',
        method: 'GET',
        success: function(response) {
            if (response.stats) {
                $('#total-students').text(response.stats.total_students);
                $('#total-courses').text(response.stats.total_courses);
                $('#pending-fees').text('$' + response.stats.pending_payments.toFixed(2));
                $('#new-announcements').text(response.stats.new_announcements);
            }
        }
    });
    
    // Check for new announcements
    $.ajax({
        url: '/api/notifications',
        method: 'GET',
        data: { limit: 5 },
        success: function(response) {
            if (response.notifications && response.notifications.length > 0) {
                // Update announcements list
                var html = '';
                response.notifications.forEach(function(notif) {
                    html += '<div class="announcement-item mb-3">' +
                        '<h6>' + notif.title + '</h6>' +
                        '<small class="text-muted">' + new Date(notif.created_at).toLocaleString() + '</small>' +
                        '<p class="mt-2">' + notif.message.substring(0, 100) + '...</p>' +
                        '</div><hr>';
                });
                $('#announcements-list').html(html);
            }
        }
    });
}, 5000); // Poll every 5 seconds
</script>