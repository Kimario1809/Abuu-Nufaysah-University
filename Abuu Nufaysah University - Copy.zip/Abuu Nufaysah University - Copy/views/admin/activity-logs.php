<?php
use App\Core\Auth;
use App\Models\ActivityLog;

$auth = Auth::getInstance();
$filters = $_GET ?? [];

// Get filters
$userId = $filters['user_id'] ?? null;
$action = $filters['action'] ?? null;
$entityType = $filters['entity_type'] ?? null;
$dateFrom = $filters['date_from'] ?? null;
$dateTo = $filters['date_to'] ?? null;

// Build filter array
$filterArray = [];
if ($userId) $filterArray['user_id'] = $userId;
if ($action) $filterArray['action'] = $action;
if ($entityType) $filterArray['entity_type'] = $entityType;
if ($dateFrom) $filterArray['date_from'] = $dateFrom;
if ($dateTo) $filterArray['date_to'] = $dateTo;

// Pagination
$page = (int)($filters['page'] ?? 1);
$limit = 50;
$offset = ($page - 1) * $limit;

// Get logs
$logs = ActivityLog::getAll($filterArray, $limit, $offset);
$totalLogs = ActivityLog::count($filterArray);
$totalPages = ceil($totalLogs / $limit);

// Get available actions for filter dropdown
$allLogs = ActivityLog::getAll([], 1000);
$actions = array_unique(array_column($allLogs, 'action'));
$entityTypes = array_unique(array_filter(array_column($allLogs, 'entity_type')));
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">
                            <i class="bi bi-clock-history"></i> Activity Logs
                        </h4>
                        <div class="btn-group">
                            <button class="btn btn-outline-primary btn-sm" onclick="exportLogs()">
                                <i class="bi bi-download"></i> Export
                            </button>
                            <button class="btn btn-outline-danger btn-sm" onclick="clearOldLogs()">
                                <i class="bi bi-trash"></i> Clear Old Logs
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Filters -->
                    <form method="GET" class="mb-4">
                        <div class="row g-3">
                            <div class="col-md-2">
                                <input type="text" class="form-control" name="user_id" 
                                       placeholder="User ID" value="<?php echo htmlspecialchars($userId ?? ''); ?>">
                            </div>
                            <div class="col-md-2">
                                <select class="form-select" name="action">
                                    <option value="">All Actions</option>
                                    <?php foreach ($actions as $act): ?>
                                        <option value="<?php echo htmlspecialchars($act); ?>" 
                                                <?php echo $action === $act ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($act); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <select class="form-select" name="entity_type">
                                    <option value="">All Entities</option>
                                    <?php foreach ($entityTypes as $type): ?>
                                        <option value="<?php echo htmlspecialchars($type); ?>" 
                                                <?php echo $entityType === $type ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($type); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <input type="date" class="form-control" name="date_from" 
                                       value="<?php echo htmlspecialchars($dateFrom ?? ''); ?>">
                            </div>
                            <div class="col-md-2">
                                <input type="date" class="form-control" name="date_to" 
                                       value="<?php echo htmlspecialchars($dateTo ?? ''); ?>">
                            </div>
                            <div class="col-md-2">
                                <div class="btn-group w-100">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-search"></i> Filter
                                    </button>
                                    <a href="/admin/activity-logs" class="btn btn-outline-secondary">
                                        <i class="bi bi-x"></i> Clear
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!-- Logs Table -->
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Action</th>
                                    <th>Entity</th>
                                    <th>Description</th>
                                    <th>IP Address</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($logs)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-4">
                                            <i class="bi bi-inbox fs-4 text-muted"></i>
                                            <p class="text-muted mb-0">No activity logs found</p>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($logs as $log): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($log['id']); ?></td>
                                            <td>
                                                <?php if ($log['user_id']): ?>
                                                    <strong><?php echo htmlspecialchars($log['full_name'] ?? 'Unknown'); ?></strong>
                                                    <br>
                                                    <small class="text-muted">
                                                        <?php echo htmlspecialchars($log['email'] ?? ''); ?>
                                                        (<?php echo htmlspecialchars($log['role'] ?? ''); ?>)
                                                    </small>
                                                <?php else: ?>
                                                    <span class="text-muted">System</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?php echo getActionBadgeColor($log['action']); ?>">
                                                    <?php echo htmlspecialchars($log['action']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($log['entity_type']): ?>
                                                    <?php echo htmlspecialchars($log['entity_type']); ?>
                                                    <?php if ($log['entity_id']): ?>
                                                        #<?php echo htmlspecialchars($log['entity_id']); ?>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo htmlspecialchars($log['description'] ?? '-'); ?>
                                                <?php if ($log['metadata']): ?>
                                                    <button class="btn btn-sm btn-link p-0 ms-1" 
                                                            onclick="toggleMetadata(<?php echo $log['id']; ?>)">
                                                        <i class="bi bi-info-circle"></i>
                                                    </button>
                                                    <div id="metadata-<?php echo $log['id']; ?>" class="d-none mt-1">
                                                        <pre class="bg-light p-2 rounded"><?php echo htmlspecialchars(json_encode($log['metadata'], JSON_PRETTY_PRINT)); ?></pre>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <small><?php echo htmlspecialchars($log['ip_address'] ?? '-'); ?></small>
                                            </td>
                                            <td>
                                                <small><?php echo date('M d, Y H:i:s', strtotime($log['created_at'])); ?></small>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <nav aria-label="Page navigation" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?<?php echo http_build_query(array_merge($filters, ['page' => $page - 1])); ?>">
                                            Previous
                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?<?php echo http_build_query(array_merge($filters, ['page' => $i])); ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $totalPages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?<?php echo http_build_query(array_merge($filters, ['page' => $page + 1])); ?>">
                                            Next
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                        <p class="text-center text-muted">
                            Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $limit, $totalLogs); ?> of <?php echo $totalLogs; ?> logs
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleMetadata(id) {
    const element = document.getElementById('metadata-' + id);
    element.classList.toggle('d-none');
}

function exportLogs() {
    if (confirm('Export activity logs to CSV?')) {
        const filters = new URLSearchParams(window.location.search);
        window.location.href = '/admin/activity-logs/export?' + filters.toString();
    }
}

function clearOldLogs() {
    if (confirm('Delete logs older than 90 days? This action cannot be undone.')) {
        fetch('/admin/activity-logs/clear-old', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Old logs cleared successfully');
                location.reload();
            } else {
                alert('Failed to clear old logs: ' + data.message);
            }
        })
        .catch(error => {
            alert('Error: ' + error.message);
        });
    }
}

<?php
function getActionBadgeColor($action) {
    $actionColors = [
        'login' => 'success',
        'logout' => 'secondary',
        'failed_login' => 'danger',
        'password_changed' => 'warning',
        'password_reset_requested' => 'info',
        'profile_updated' => 'primary',
        'created' => 'success',
        'updated' => 'primary',
        'deleted' => 'danger',
        'viewed' => 'info',
        'downloaded' => 'info',
        'exported' => 'primary',
        'imported' => 'primary',
        'payment_created' => 'success',
        'payment_confirmed' => 'success',
        'payment_failed' => 'danger',
        'enrollment_enrolled' => 'success',
        'enrollment_dropped' => 'warning',
        'grade_posted' => 'success',
        'grade_updated' => 'primary',
        'assignment_created' => 'success',
        'assignment_submitted' => 'info',
        'assignment_graded' => 'primary',
        'announcement_created' => 'success',
        'announcement_updated' => 'primary',
        'announcement_deleted' => 'danger',
        'security' => 'danger',
        'api_request' => 'info',
        'system' => 'warning'
    ];
    
    return $actionColors[$action] ?? 'secondary';
}
?>
</script>
