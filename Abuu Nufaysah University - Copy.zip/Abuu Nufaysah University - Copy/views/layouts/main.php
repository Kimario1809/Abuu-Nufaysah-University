<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Abuu Nufay'sah University Sims</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
    <link href="/assets/css/notifications.css" rel="stylesheet">
    <link href="/assets/css/websocket-status.css" rel="stylesheet">
    <link href="/assets/css/pwa-install.css" rel="stylesheet">
    <link href="/assets/css/splash-screen.css" rel="stylesheet">
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#0d6efd">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="Abuu University">
    <?php if (isset($extra_css)) echo $extra_css; ?>
    
    <!-- WebSocket Configuration -->
    <meta name="ws-server-url" content="<?php echo Env::get('WEBSOCKET_SERVER', 'localhost'); ?>">
    <meta name="ws-port" content="<?php echo Env::get('WEBSOCKET_PORT', '3001'); ?>">
    <meta name="ws-use-ssl" content="<?php echo Env::get('WEBSOCKET_HTTPS', 'false'); ?>">
</head>
<body data-authenticated="<?php echo isset($auth) && $auth->isAuthenticated() ? 'true' : 'false'; ?>" data-user-id="<?php echo isset($auth) && $auth->isAuthenticated() ? $auth->getCurrentUser()['id'] : ''; ?>">
    
    <!-- PWA Splash Screen -->
    <div id="splashScreen" class="splash-screen">
        <div class="logo">
            <img src="/assets/images/logo-icon.png" alt="App Logo" onerror="this.style.display='none'">
        </div>
        <div class="app-name">Abuu Nufay'sah University</div>
        <div class="tagline">University Management System</div>
        <div class="loader"></div>
    </div>
    
    <?php if (isset($auth) && $auth->isAuthenticated()): ?>
    <!-- Navigation -->
    <nav class="navbar navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="/<?= $auth->getCurrentRole() ?>/dashboard">
                <i class="bi bi-mortarboard"></i> Abuu Nufay'sah University
            </a>
            <div class="d-flex align-items-center">
                <!-- Push Notification Toggle -->
                <?php require_once __DIR__ . '/../partials/push-toggle.php'; ?>
                
                <!-- Notification Bell -->
                <?php require_once __DIR__ . '/../partials/notifications.php'; ?>
                
                <span class="text-white me-3">
                    <i class="bi bi-person-circle"></i> <?= htmlspecialchars($auth->getCurrentUser()['full_name']) ?>
                </span>
                <a href="/logout" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
    </nav>
    
    <!-- Sidebar -->
    <div class="d-flex w-100">
        <div class="sidebar">
            <?php require_once "sidebar-{$auth->getCurrentRole()}.php"; ?>
        </div>
        <div class="main-content">
    <?php else: ?>
        <div class="container">
    <?php endif; ?>
    
    <!-- Content -->
    <?php include $viewFile; ?>
    
    <?php if (isset($auth) && $auth->isAuthenticated()): ?>
        </div>
    </div>
    <?php else: ?>
        </div>
    <?php endif; ?>
    
    <!-- Mobile Bottom Navigation -->
    <?php if (isset($auth) && $auth->isAuthenticated()): ?>
        <?php require_once __DIR__ . '/../partials/mobile-nav.php'; ?>
    <?php endif; ?>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>
    <script src="/assets/js/app.js"></script>
    <script src="/assets/js/chat.js"></script>
    <script src="/assets/js/websocket.js"></script>
    <script src="/assets/js/pwa-install.js"></script>
    <script src="/assets/js/offline-detection.js"></script>
    <?php if (isset($extra_js)) echo $extra_js; ?>
    
    <!-- Service Worker Registration -->
    <script>
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', function() {
                navigator.serviceWorker.register('/sw.js')
                    .then(function(registration) {
                        console.log('Service Worker registered with scope:', registration.scope);
                        
                        // Listen for updates
                        registration.addEventListener('updatefound', function() {
                            const newWorker = registration.installing;
                            newWorker.addEventListener('statechange', function() {
                                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                                    // New service worker is available
                                    if (confirm('A new version of the app is available. Reload to update?')) {
                                        newWorker.postMessage({ type: 'SKIP_WAITING' });
                                        window.location.reload();
                                    }
                                }
                            });
                        });
                    })
                    .catch(function(error) {
                        console.log('Service Worker registration failed:', error);
                    });
            });
        }
        
        // Listen for service worker controlling the page
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.addEventListener('controllerchange', function() {
                console.log('Controller changed - reloading page');
                window.location.reload();
            });
        }
        
        // Hide splash screen after page loads
        window.addEventListener('load', function() {
            setTimeout(function() {
                const splashScreen = document.getElementById('splashScreen');
                if (splashScreen) {
                    splashScreen.classList.add('hidden');
                    setTimeout(function() {
                        splashScreen.remove();
                    }, 500);
                }
            }, 1500);
        });
    </script>
    
    <!-- WebSocket Connection Status Indicator -->
    <div id="wsStatusIndicator" class="ws-status-indicator disconnected" style="display: none;">
        <div class="ws-status-dot"></div>
        <span id="wsStatusText">Disconnected</span>
    </div>
    
    <!-- Offline Indicator -->
    <div id="offlineIndicator" class="offline-indicator" style="display: none;">
        <i class="bi bi-wifi-off"></i>
        <span>You are offline</span>
    </div>
</body>
</html>