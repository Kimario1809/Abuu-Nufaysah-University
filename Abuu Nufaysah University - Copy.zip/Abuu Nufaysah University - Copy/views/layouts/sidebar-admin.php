<div class="sidebar">
    <div class="nav-header">Main Navigation</div>
    
    <a href="/admin/dashboard" class="nav-link <?= $activePage === 'dashboard' ? 'active' : '' ?>">
        <i class="bi bi-speedometer2"></i> Dashboard
    </a>
    <a href="/students" class="nav-link <?= $activePage === 'students' ? 'active' : '' ?>">
        <i class="bi bi-person"></i> Students
    </a>
    <a href="/lecturers" class="nav-link <?= $activePage === 'lecturers' ? 'active' : '' ?>">
        <i class="bi bi-person-badge"></i> Lecturers
    </a>
    <a href="/courses" class="nav-link <?= $activePage === 'courses' ? 'active' : '' ?>">
        <i class="bi bi-book"></i> Courses
    </a>
    
    <div class="nav-header">Management</div>
    <a href="/payments" class="nav-link <?= $activePage === 'payments' ? 'active' : '' ?>">
        <i class="bi bi-credit-card"></i> Payments
    </a>
    <a href="/announcements" class="nav-link <?= $activePage === 'announcements' ? 'active' : '' ?>">
        <i class="bi bi-megaphone"></i> Announcements
    </a>
    <a href="/timetable" class="nav-link <?= $activePage === 'timetable' ? 'active' : '' ?>">
        <i class="bi bi-calendar"></i> Timetable
    </a>
    <a href="/departments" class="nav-link <?= $activePage === 'departments' ? 'active' : '' ?>">
        <i class="bi bi-building"></i> Departments
    </a>
    <a href="/admin/activity-logs" class="nav-link <?= $activePage === 'activity-logs' ? 'active' : '' ?>">
        <i class="bi bi-clock-history"></i> Activity Logs
    </a>
    
    <div class="nav-header">Reports</div>
    <a href="/reports" class="nav-link <?= $activePage === 'reports' ? 'active' : '' ?>">
        <i class="bi bi-file-earmark-text"></i> Reports
    </a>
    <a href="/settings" class="nav-link <?= $activePage === 'settings' ? 'active' : '' ?>">
        <i class="bi bi-gear"></i> Settings
    </a>
    <a href="/ai/chat" class="nav-link <?= $activePage === 'ai' ? 'active' : '' ?>">
        <i class="bi bi-robot"></i> AI Assistant
    </a>
</div>