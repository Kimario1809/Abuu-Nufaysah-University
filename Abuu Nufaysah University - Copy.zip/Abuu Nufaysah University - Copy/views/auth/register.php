<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Abuu Nufay'sah University</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            padding: 20px;
            position: relative;
            overflow: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.03)" stroke-width="1"/></svg>');
            background-size: 100px 100px;
            animation: float 20s linear infinite;
        }

        @keyframes float {
            0% { transform: translateY(0) rotate(0deg); }
            100% { transform: translateY(-100px) rotate(360deg); }
        }

        .auth-container {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 600px;
        }

        .auth-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 48px 40px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5),
                        0 0 0 1px rgba(255, 255, 255, 0.1) inset;
            animation: slideUp 0.6s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .auth-title {
            text-align: center;
            margin-bottom: 40px;
        }

        .auth-title .logo-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
            animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        .auth-title .logo-icon i {
            font-size: 2.5rem;
            color: white;
        }

        .auth-title h2 {
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 8px;
            font-size: 1.75rem;
        }

        .auth-title p {
            color: #64748b;
            font-size: 0.95rem;
            font-weight: 400;
        }

        .form-label {
            font-weight: 500;
            color: #334155;
            font-size: 0.9rem;
            margin-bottom: 8px;
        }

        .input-group {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .input-group:focus-within {
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2);
        }

        .input-group-text {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            color: #64748b;
            padding: 12px 16px;
        }

        .form-control, .form-select {
            border: 1px solid #e2e8f0;
            padding: 12px 16px;
            font-size: 0.95rem;
            background: #f8fafc;
            transition: all 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            background: white;
            border-color: #667eea;
            box-shadow: none;
        }

        .form-control::placeholder {
            color: #94a3b8;
        }

        .btn-outline-secondary {
            border: 1px solid #e2e8f0;
            background: #f8fafc;
            color: #64748b;
            padding: 12px 16px;
            transition: all 0.3s ease;
        }

        .btn-outline-secondary:hover {
            background: #e2e8f0;
            color: #334155;
            border-color: #cbd5e1;
        }

        .form-check {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-check-input {
            width: 18px;
            height: 18px;
            border: 2px solid #cbd5e1;
            cursor: pointer;
        }

        .form-check-input:checked {
            background-color: #667eea;
            border-color: #667eea;
        }

        .form-check-label {
            font-size: 0.9rem;
            color: #64748b;
            cursor: pointer;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 14px 24px;
            font-weight: 600;
            font-size: 1rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
            background: linear-gradient(135deg, #5a6fd6 0%, #6a4190 100%);
        }

        .btn-primary:active {
            transform: translateY(0);
        }

        .text-muted {
            font-size: 0.8rem;
            color: #94a3b8 !important;
            margin-top: 6px;
            display: block;
        }

        .role-selector {
            display: flex;
            gap: 15px;
            margin: 10px 0;
        }

        .role-option {
            flex: 1;
            padding: 20px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            background: #f8fafc;
        }

        .role-option:hover {
            border-color: #667eea;
            background: rgba(102, 126, 234, 0.05);
        }

        .role-option.selected {
            border-color: #667eea;
            background: rgba(102, 126, 234, 0.1);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.2);
        }

        .role-option i {
            font-size: 2rem;
            display: block;
            margin-bottom: 8px;
            color: #64748b;
            transition: color 0.3s ease;
        }

        .role-option.selected i {
            color: #667eea;
        }

        .role-option span {
            font-weight: 500;
            color: #334155;
        }

        .role-option input[type="radio"] {
            display: none;
        }

        .department-select {
            display: none;
            animation: fadeIn 0.3s ease;
        }

        .department-select.show {
            display: block;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .password-strength {
            height: 4px;
            margin-top: 8px;
            border-radius: 2px;
            transition: all 0.3s ease;
            background: #e2e8f0;
        }

        .password-strength.weak {
            width: 25%;
            background: #ef4444;
        }

        .password-strength.medium {
            width: 50%;
            background: #f59e0b;
        }

        .password-strength.strong {
            width: 75%;
            background: #10b981;
        }

        .password-strength.very-strong {
            width: 100%;
            background: #3b82f6;
        }

        .password-requirements {
            font-size: 0.8rem;
            color: #64748b;
            margin-top: 12px;
            background: #f8fafc;
            padding: 12px;
            border-radius: 8px;
        }

        .password-requirements .requirement {
            display: flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 4px;
        }

        .password-requirements .requirement:last-child {
            margin-bottom: 0;
        }

        .password-requirements .requirement i {
            font-size: 0.75rem;
        }

        .password-requirements .requirement.valid {
            color: #10b981;
        }

        .password-requirements .requirement.invalid {
            color: #ef4444;
        }

        .mt-3.text-center {
            margin-top: 24px;
            font-size: 0.9rem;
        }

        .mt-3.text-center a {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .mt-3.text-center a:hover {
            color: #764ba2;
        }

        .invalid-feedback {
            font-size: 0.8rem;
            color: #ef4444;
            margin-top: 4px;
        }

        @media (max-width: 576px) {
            .auth-card {
                padding: 32px 24px;
            }

            .auth-title h2 {
                font-size: 1.5rem;
            }

            .role-selector {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <!-- Header -->
            <div class="auth-title">
                <div class="logo-icon">
                    <i class="bi bi-mortarboard-fill"></i>
                </div>
                <h2>Create Account</h2>
                <p>Join Abuu Nufay'sah University</p>
            </div>
            
            <!-- Registration Form -->
            <form id="register-form" action="/register" method="POST" data-ajax="true">
                <!-- CSRF Token -->
                <input type="hidden" name="csrf_token" value="<?= \App\Core\CSRF::getToken() ?>">
                
                <!-- Full Name -->
                <div class="mb-3">
                    <label for="full_name" class="form-label">Full Name</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                        <input type="text" class="form-control" id="full_name" name="full_name" 
                               placeholder="Enter your full name" required autofocus>
                    </div>
                    <div class="invalid-feedback"></div>
                </div>
                
                <!-- Email -->
                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input type="email" class="form-control" id="email" name="email" 
                               placeholder="Enter your email" required>
                    </div>
                    <div class="invalid-feedback"></div>
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label">Phone Number</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-telephone"></i></span>
                        <input type="text" class="form-control" id="phone" name="phone" 
                               placeholder="e.g. +255712345678 or +1 555 123 4567" required>
                    </div>
                    <small class="text-muted">Use your international phone number.</small>
                    <div class="invalid-feedback"></div>
                </div>
                
                <!-- Role Selection -->
                <div class="mb-3">
                    <label class="form-label">I want to register as</label>
                    <div class="role-selector">
                        <label class="role-option selected" id="role-student">
                            <input type="radio" name="role" value="student" checked>
                            <i class="bi bi-person-graduate"></i>
                            <span>Student</span>
                        </label>
                        <label class="role-option" id="role-lecturer">
                            <input type="radio" name="role" value="lecturer">
                            <i class="bi bi-person-badge"></i>
                            <span>Lecturer</span>
                        </label>
                    </div>
                </div>
                
                <!-- Department Selection (for Students) -->
                <div class="mb-3 department-select show" id="student-department">
                    <label for="department_id" class="form-label">Department</label>
                    <select class="form-select" id="department_id" name="department_id">
                        <option value="">Select Department</option>
                        <?php if (isset($departments) && !empty($departments)): ?>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?= $dept['id'] ?>"><?= htmlspecialchars($dept['name']) ?></option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="">No departments available</option>
                        <?php endif; ?>
                    </select>
                    <div class="invalid-feedback"></div>
                </div>
                
                <!-- Department Selection (for Lecturers) -->
                <div class="mb-3 department-select" id="lecturer-department">
                    <label for="lecturer_department_id" class="form-label">Department</label>
                    <select class="form-select" id="lecturer_department_id" name="lecturer_department_id">
                        <option value="">Select Department</option>
                        <?php if (isset($departments) && !empty($departments)): ?>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?= $dept['id'] ?>"><?= htmlspecialchars($dept['name']) ?></option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="">No departments available</option>
                        <?php endif; ?>
                    </select>
                    <div class="invalid-feedback"></div>
                </div>
                
                <!-- Password -->
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                        <input type="password" class="form-control" id="password" name="password" 
                               placeholder="Create a password (min 8 characters)" required>
                        <button class="btn btn-outline-secondary" type="button" id="toggle-password">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                    
                    <!-- Password Strength Bar -->
                    <div class="password-strength" id="password-strength"></div>
                    
                    <!-- Password Requirements -->
                    <div class="password-requirements">
                        <div class="requirement invalid" id="req-length">
                            <i class="bi bi-x-circle"></i>
                            <span>At least 8 characters</span>
                        </div>
                        <div class="requirement invalid" id="req-uppercase">
                            <i class="bi bi-x-circle"></i>
                            <span>At least one uppercase letter</span>
                        </div>
                        <div class="requirement invalid" id="req-lowercase">
                            <i class="bi bi-x-circle"></i>
                            <span>At least one lowercase letter</span>
                        </div>
                        <div class="requirement invalid" id="req-number">
                            <i class="bi bi-x-circle"></i>
                            <span>At least one number</span>
                        </div>
                        <div class="requirement invalid" id="req-special">
                            <i class="bi bi-x-circle"></i>
                            <span>At least one special character (!@#$%^&*)</span>
                        </div>
                    </div>
                    
                    <div class="invalid-feedback"></div>
                </div>
                
                <!-- Confirm Password -->
                <div class="mb-3">
                    <label for="password_confirmation" class="form-label">Confirm Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                        <input type="password" class="form-control" id="password_confirmation" 
                               name="password_confirmation" placeholder="Confirm your password" required>
                    </div>
                    <div class="invalid-feedback"></div>
                </div>
                
                <!-- Terms -->
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                    <label class="form-check-label" for="terms">
                        I agree to the <a href="/terms" target="_blank">Terms of Service</a> and 
                        <a href="/privacy" target="_blank">Privacy Policy</a>
                    </label>
                    <div class="invalid-feedback">You must agree to the terms</div>
                </div>
                
                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary w-100 py-2" id="register-btn">
                    <span class="spinner-border spinner-border-sm d-none" role="status"></span>
                    Create Account
                </button>
            </form>
            
            <!-- Login Link -->
            <div class="mt-3 text-center">
                Already have an account? <a href="/login" class="text-decoration-none">Sign In</a>
            </div>
        </div>
    </div>
    
    <!-- Toast Container -->
    <div class="toast-container"></div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/app.js"></script>
    
    <script>
        $(document).ready(function() {
            // ==========================================
            // ROLE SELECTION
            // ==========================================
            $('.role-option').on('click', function() {
                // Remove selected class from all
                $('.role-option').removeClass('selected');
                // Add selected class to clicked
                $(this).addClass('selected');
                // Check the radio button
                $(this).find('input[type="radio"]').prop('checked', true);
                
                // Show/hide department select based on role
                const role = $(this).find('input[type="radio"]').val();
                if (role === 'student') {
                    $('#student-department').addClass('show');
                    $('#lecturer-department').removeClass('show');
                } else {
                    $('#student-department').removeClass('show');
                    $('#lecturer-department').addClass('show');
                }
            });
            
            // ==========================================
            // PASSWORD TOGGLE
            // ==========================================
            $('#toggle-password').on('click', function() {
                const input = $('#password');
                const icon = $(this).find('i');
                
                if (input.attr('type') === 'password') {
                    input.attr('type', 'text');
                    icon.removeClass('bi-eye').addClass('bi-eye-slash');
                } else {
                    input.attr('type', 'password');
                    icon.removeClass('bi-eye-slash').addClass('bi-eye');
                }
            });
            
            // ==========================================
            // PASSWORD STRENGTH CHECKER
            // ==========================================
            $('#password').on('input', function() {
                const password = $(this).val();
                const strengthBar = $('#password-strength');
                
                // Check requirements
                const hasLength = password.length >= 8;
                const hasUppercase = /[A-Z]/.test(password);
                const hasLowercase = /[a-z]/.test(password);
                const hasNumber = /[0-9]/.test(password);
                const hasSpecial = /[!@#$%^&*]/.test(password);
                
                // Update requirement indicators
                updateRequirement('#req-length', hasLength);
                updateRequirement('#req-uppercase', hasUppercase);
                updateRequirement('#req-lowercase', hasLowercase);
                updateRequirement('#req-number', hasNumber);
                updateRequirement('#req-special', hasSpecial);
                
                // Calculate strength
                let score = 0;
                if (hasLength) score++;
                if (hasUppercase) score++;
                if (hasLowercase) score++;
                if (hasNumber) score++;
                if (hasSpecial) score++;
                
                // Update strength bar
                strengthBar.removeClass('weak medium strong very-strong');
                if (password.length === 0) {
                    strengthBar.css('width', '0');
                } else if (score <= 2) {
                    strengthBar.addClass('weak');
                } else if (score === 3) {
                    strengthBar.addClass('medium');
                } else if (score === 4) {
                    strengthBar.addClass('strong');
                } else {
                    strengthBar.addClass('very-strong');
                }
            });
            
            function updateRequirement(id, isValid) {
                const element = $(id);
                const icon = element.find('i');
                
                if (isValid) {
                    element.removeClass('invalid').addClass('valid');
                    icon.removeClass('bi-x-circle').addClass('bi-check-circle');
                } else {
                    element.removeClass('valid').addClass('invalid');
                    icon.removeClass('bi-check-circle').addClass('bi-x-circle');
                }
            }
            
            // ==========================================
            // PASSWORD CONFIRMATION VALIDATION
            // ==========================================
            $('#password_confirmation').on('input', function() {
                const password = $('#password').val();
                const confirm = $(this).val();
                
                if (confirm.length > 0 && password !== confirm) {
                    $(this).addClass('is-invalid');
                    $(this).siblings('.invalid-feedback').text('Passwords do not match');
                } else {
                    $(this).removeClass('is-invalid');
                    $(this).siblings('.invalid-feedback').text('');
                }
            });
            
            // ==========================================
            // FORM SUBMISSION
            // ==========================================
            $('#register-form').on('submit', function(e) {
                e.preventDefault();
                
                const form = $(this);
                const btn = $('#register-btn');
                const spinner = btn.find('.spinner-border');
                
                // Validate terms
                if (!$('#terms').is(':checked')) {
                    showToast('Error', 'Please agree to the terms and conditions', 'danger');
                    return;
                }
                
                // Validate password match
                const password = $('#password').val();
                const confirm = $('#password_confirmation').val();
                if (password !== confirm) {
                    showToast('Error', 'Passwords do not match', 'danger');
                    return;
                }
                
                // Validate password strength
                const strength = $('#password-strength').attr('class');
                if (!strength || strength.includes('weak')) {
                    showToast('Error', 'Please create a stronger password', 'danger');
                    return;
                }
                
                // Disable button and show spinner
                btn.prop('disabled', true);
                spinner.removeClass('d-none');
                
                // Get form data
                const formData = new FormData(this);
                const data = {};
                formData.forEach((value, key) => {
                    data[key] = value;
                });
                
                // Handle department field based on role
                if (data.role === 'student') {
                    data.department_id = $('#department_id').val();
                } else {
                    data.department_id = $('#lecturer_department_id').val();
                }
                delete data.lecturer_department_id;
                
                // Submit via AJAX
                $.ajax({
                    url: form.attr('action'),
                    method: form.attr('method'),
                    data: data,
                    success: function(response) {
                        if (response.success) {
                            showToast('Success', response.message, 'success');
                            
                            // Clear form
                            form[0].reset();
                            $('#password-strength').css('width', '0');
                            
                            // Redirect to login after delay
                            setTimeout(function() {
                                window.location.href = '/login';
                            }, 2000);
                        } else {
                            showToast('Error', response.message || 'Registration failed', 'danger');
                        }
                    },
                    error: function(xhr) {
                        const response = xhr.responseJSON;
                        let message = 'Registration failed. Please try again.';
                        
                        if (response && response.errors) {
                            // Display field errors
                            const errors = response.errors;
                            let errorMessages = [];
                            
                            Object.keys(errors).forEach(function(field) {
                                const fieldErrors = errors[field];
                                const input = $('[name="' + field + '"]');
                                const feedback = input.siblings('.invalid-feedback');
                                
                                if (feedback.length) {
                                    feedback.text(fieldErrors.join(', '));
                                    input.addClass('is-invalid');
                                }
                                
                                errorMessages.push(fieldErrors.join(', '));
                            });
                            
                            message = errorMessages.join('\n');
                        } else if (response && response.message) {
                            message = response.message;
                        }
                        
                        showToast('Error', message, 'danger');
                    },
                    complete: function() {
                        // Re-enable button and hide spinner
                        btn.prop('disabled', false);
                        spinner.addClass('d-none');
                    }
                });
            });
            
            // ==========================================
            // CLEAR FIELD ERRORS ON INPUT
            // ==========================================
            $('form input, form select').on('input change', function() {
                $(this).removeClass('is-invalid');
                $(this).siblings('.invalid-feedback').text('');
            });
        });
    </script>
</body>
</html>