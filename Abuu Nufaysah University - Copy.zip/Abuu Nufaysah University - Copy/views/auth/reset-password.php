<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Abuu Nufay'sah University</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-title">
                <h2>Create a new password</h2>
                <p>Choose a strong password for your account.</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php else: ?>
                <form id="reset-password-form" action="/reset-password/<?= htmlspecialchars($token ?? '') ?>" method="POST">
                    <input type="hidden" name="csrf_token" value="<?= \App\Core\CSRF::getToken() ?>">
                    <div class="mb-3">
                        <label for="password" class="form-label">New Password</label>
                        <input type="password" class="form-control" id="password" name="password" required minlength="8">
                    </div>
                    <div class="mb-3">
                        <label for="password_confirmation" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required minlength="8">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Update password</button>
                </form>
            <?php endif; ?>

            <div class="mt-3 text-center">
                <a href="/login" class="text-decoration-none">Back to login</a>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(function () {
            $('#reset-password-form').on('submit', function (e) {
                e.preventDefault();
                const form = $(this);
                $.post(form.attr('action'), form.serialize(), function (response) {
                    alert(response.message || 'Password updated');
                    if (response.success) {
                        window.location.href = '/login';
                    }
                }).fail(function (xhr) {
                    const data = xhr.responseJSON || {};
                    alert(data.message || 'Unable to update password');
                });
            });
        });
    </script>
</body>
</html>
