<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Abuu Nufay'sah University</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-title">
                <h2>Reset your password</h2>
                <p>Enter your email address and we’ll send a reset link to your Gmail inbox.</p>
            </div>

            <form id="forgot-password-form" action="/forgot-password" method="POST">
                <input type="hidden" name="csrf_token" value="<?= \App\Core\CSRF::getToken() ?>">
                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" class="form-control" id="email" name="email" required autofocus>
                </div>

                <button type="submit" class="btn btn-primary w-100">Send reset link</button>
            </form>

            <div class="mt-3 text-center">
                <a href="/login" class="text-decoration-none">Back to login</a>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(function () {
            $('#forgot-password-form').on('submit', function (e) {
                e.preventDefault();
                const form = $(this);
                $.post('/forgot-password', form.serialize(), function (response) {
                    alert(response.message || 'Request sent');
                    if (response.success) {
                        form[0].reset();
                    }
                }).fail(function (xhr) {
                    const data = xhr.responseJSON || {};
                    alert(data.message || 'Unable to process request');
                });
            });
        });
    </script>
</body>
</html>
