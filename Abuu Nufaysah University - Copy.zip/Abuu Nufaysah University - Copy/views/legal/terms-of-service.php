<?php
$this->view('layouts/main', ['title' => 'Terms of Service'], true);
?>
<div class="container py-5">
  <div class="card shadow-sm">
    <div class="card-body">
      <h1 class="mb-4">Terms of Service</h1>
      <p class="text-muted">Effective Date: 4 July 2026</p>

      <h2>1. Acceptance of Terms</h2>
      <p>By accessing, registering for, or using the Abuu Nufay'sah University Student Management System, you agree to be bound by these Terms of Service. These Terms apply to all users, including students, lecturers, administrators, finance staff, and any other authorised individuals using the System.</p>

      <h2>2. User Roles and Responsibilities</h2>
      <p>Users are responsible for complying with the rules and obligations applicable to their role:</p>
      <ul>
        <li><strong>Students</strong> must use the System lawfully, maintain accurate information, and respect academic and institutional rules.</li>
        <li><strong>Lecturers</strong> must use the System responsibly, maintain academic records accurately, and protect confidential information.</li>
        <li><strong>Administrators</strong> must manage the System in accordance with institutional policy, data protection law, and access control requirements.</li>
        <li><strong>Finance staff</strong> must handle financial records and payment data with the highest level of integrity and confidentiality.</li>
      </ul>

      <h2>3. Acceptable Use Policy</h2>
      <p>Users must not:</p>
      <ul>
        <li>Attempt unauthorised access to accounts, systems, or data.</li>
        <li>Engage in hacking, credential theft, data manipulation, or any unlawful activity.</li>
        <li>Upload harmful, offensive, false, or unlawful content.</li>
        <li>Misuse the chat system, send spam, harass others, or distribute abusive content.</li>
      </ul>

      <h2>4. Account Security</h2>
      <p>Users are responsible for keeping their passwords and account credentials secure. Accounts must not be shared with others. Users must log out after use, especially on shared or public devices.</p>

      <h2>5. Academic Integrity</h2>
      <p>Users must not manipulate grades, falsify records, submit fraudulent academic information, or otherwise violate academic integrity policies. Any suspected misuse may be investigated and may result in disciplinary action.</p>

      <h2>6. Messaging and Communication Rules</h2>
      <p>The messaging and chat features may be monitored and reviewed by authorised personnel where necessary for security, safety, compliance, or institutional administration. Users must not use the communication tools to harass, threaten, spam, or distribute inappropriate content.</p>

      <h2>7. System Availability</h2>
      <p>The University will make reasonable efforts to ensure the availability of the System; however, no service can be guaranteed to be free from downtime, interruption, maintenance, or failure. Planned maintenance windows may occur from time to time.</p>

      <h2>8. Limitation of Liability</h2>
      <p>To the maximum extent permitted by law, the University shall not be liable for any loss, damage, delay, interruption, or disclosure arising from user error, internet disruption, third-party service failure, cyber incidents, or other events beyond reasonable control.</p>

      <h2>9. Termination</h2>
      <p>The University may suspend or terminate access to the System where a user violates these Terms, engages in misuse, submits fraudulent content, or otherwise compromises security, compliance, or institutional operations.</p>

      <h2>10. Changes to Terms</h2>
      <p>These Terms may be updated from time to time. Continued use of the System after any amendment constitutes acceptance of the revised Terms. Users will be notified of significant changes where practicable.</p>

      <h2>11. Governing Law</h2>
      <p>These Terms shall be governed by and construed in accordance with the applicable laws of the jurisdiction in which the University operates, and any disputes shall be subject to the exclusive jurisdiction of the competent courts.</p>
    </div>
  </div>
</div>
