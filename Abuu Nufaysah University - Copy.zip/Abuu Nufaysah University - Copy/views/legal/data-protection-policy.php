<?php
$this->view('layouts/main', ['title' => 'Data Protection Policy'], true);
?>
<div class="container py-5">
  <div class="card shadow-sm">
    <div class="card-body">
      <h1 class="mb-4">Data Protection Policy</h1>
      <p>The University is committed to protecting personal and institutional data processed through the Student Management System. Access is restricted to authorised users based on role and need-to-know principles. Data will be processed lawfully, fairly, and transparently, and appropriate technical and organisational safeguards will be maintained.</p>
    </div>
  </div>
</div>
