<?php
$this->view('layouts/main', ['title' => 'Privacy Policy'], true);
?>
<div class="container py-5">
  <div class="card shadow-sm">
    <div class="card-body">
      <h1 class="mb-4">Privacy Policy</h1>
      <p class="text-muted">Effective Date: 4 July 2026</p>

      <h2>1. Introduction</h2>
      <p>Abuu Nufay'sah University Student Management System (the "System") is a university platform designed to support student registration, academic administration, financial operations, attendance tracking, communications, file management, and AI-assisted support. This Privacy Policy explains how the University collects, uses, stores, shares, and protects personal and institutional data submitted through the System.</p>

      <h2>2. Information We Collect</h2>
      <p>We may collect and process the following categories of information:</p>
      <ul>
        <li>Personal information, including full name, email address, phone number, national ID or student ID, and login credentials.</li>
        <li>Academic information, including courses, enrolment records, results, attendance, timetables, and academic progress.</li>
        <li>Financial information, including fees, payment records, receipts, and transaction history.</li>
        <li>Communication data, including messages, chat content, notifications, and metadata associated with system communications.</li>
        <li>Uploaded files, including documents, images, videos, and other attachments submitted by users.</li>
        <li>Technical information, including IP address, device information, browser type, session logs, login timestamps, and access history.</li>
      </ul>

      <h2>3. How We Use Your Information</h2>
      <p>We use personal and institutional data for the following purposes:</p>
      <ul>
        <li>To administer student registration and academic records.</li>
        <li>To support attendance, results, timetable, and report generation.</li>
        <li>To process fees and maintain payment records.</li>
        <li>To facilitate internal communication through the messaging system.</li>
        <li>To provide AI assistant features and improve system performance.</li>
        <li>To maintain security, monitor misuse, and comply with legal and regulatory requirements.</li>
      </ul>

      <h2>4. Data Storage and Security</h2>
      <p>Data is stored in a MySQL database and protected through role-based access controls, secure authentication, password hashing, session management, and restricted access to administrative functions. Where technically feasible, encryption of sensitive data and secure storage practices are applied. However, no system can guarantee absolute security, and users are responsible for safeguarding credentials and sensitive information.</p>

      <h2>5. Data Sharing</h2>
      <p>We do not sell personal data. Information may be shared only within authorised university roles, such as students, lecturers, administrators, and finance staff, where necessary for academic or administrative purposes. Data may also be disclosed where required by law, court order, or legitimate public interest obligations.</p>

      <h2>6. User Rights</h2>
      <p>Users may request access to, correction of, or deletion of personal data held in the System, subject to legal, academic, and administrative retention obligations. Users may also request review of how personal data is processed and exercise privacy controls where available.</p>

      <h2>7. Cookies and Tracking</h2>
      <p>The System may use session cookies to maintain login state, security, and user preferences. Analytics or tracking technologies may be used only where necessary for system performance, user experience, or institutional reporting.</p>

      <h2>8. Third-Party Services</h2>
      <p>We may use third-party hosting providers, email services, SMS services, and AI processing services such as OpenAI or similar providers to support certain features. These providers process information strictly in accordance with contractual safeguards and applicable law.</p>

      <h2>9. Data Retention</h2>
      <p>Personal and academic data is retained for as long as required to fulfil academic, administrative, financial, security, and legal obligations. Active student records may be retained during enrolment and for a period thereafter. Graduated students' records may be archived according to institutional policy and legal requirements. Deleted accounts may have residual data retained temporarily for backup, security, or compliance purposes.</p>

      <h2>10. Contact</h2>
      <p>For privacy-related questions, requests, or complaints, please contact the University Data Protection or Administration Office.</p>
    </div>
  </div>
</div>
