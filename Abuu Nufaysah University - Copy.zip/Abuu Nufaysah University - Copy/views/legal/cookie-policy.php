<?php
$this->view('layouts/main', ['title' => 'Cookie Policy'], true);
?>
<div class="container py-5">
  <div class="card shadow-sm">
    <div class="card-body">
      <h1 class="mb-4">Cookie Policy</h1>
      <p>The System uses cookies and similar technologies to maintain user sessions, remember preferences, improve functionality, and support security. Session cookies are necessary for login and authentication. Users may disable cookies in their browser settings, although this may affect the usability of some features.</p>
    </div>
  </div>
</div>
