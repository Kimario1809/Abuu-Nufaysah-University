<div class="card">
  <div class="card-body">
    <h4 class="mb-4">Student Report</h4>
    <div class="row mb-3">
      <div class="col-md-6">
        <strong>Name:</strong> <?= htmlspecialchars($user['full_name']) ?>
      </div>
      <div class="col-md-6">
        <strong>Role:</strong> <?= htmlspecialchars($user['role']) ?>
      </div>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered">
        <thead>
          <tr><th>Item</th><th>Status</th></tr>
        </thead>
        <tbody>
          <tr><td>Attendance</td><td>Present</td></tr>
          <tr><td>Fees</td><td>Cleared</td></tr>
          <tr><td>Results</td><td>Available</td></tr>
        </tbody>
      </table>
    </div>
    <div class="mt-4">
      <button class="btn btn-primary" onclick="window.print()">Print</button>
      <a class="btn btn-outline-secondary" href="/chat">Back to chat</a>
    </div>
  </div>
</div>
