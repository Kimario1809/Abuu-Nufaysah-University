<?php
/**
 * Abuu Nufay'sah University - Web Routes
 * All routes are defined here and loaded by public/index.php
 */

use App\Core\Router;
use App\Middleware\AuthMiddleware;
use App\Middleware\RoleMiddleware;

// Initialize router
$router = new Router();

// ============================================
// 1. PUBLIC ROUTES (No authentication required)
// ============================================

// Landing page
$router->get('/', 'PageController', 'home');

// Authentication Routes
$router->get('/login', 'AuthController', 'login');
$router->post('/login', 'AuthController', 'postLogin');
$router->get('/register', 'AuthController', 'register');
$router->post('/register', 'AuthController', 'postRegister');
$router->get('/forgot-password', 'AuthController', 'forgotPassword');
$router->post('/forgot-password', 'AuthController', 'postForgotPassword');
$router->get('/reset-password/{token}', 'AuthController', 'resetPassword');
$router->post('/reset-password/{token}', 'AuthController', 'postResetPassword');
$router->get('/logout', 'AuthController', 'logout');
$router->get('/ai/chat', 'AIController', 'chat', [AuthMiddleware::class]);
$router->post('/ai/ask', 'AIController', 'ask', [AuthMiddleware::class]);
$router->get('/ai/history', 'AIController', 'history', [AuthMiddleware::class]);
$router->get('/chat', 'ChatController', 'index', [AuthMiddleware::class]);
$router->get('/privacy-policy', 'PageController', 'privacyPolicy');
$router->get('/terms-of-service', 'PageController', 'termsOfService');
$router->get('/cookie-policy', 'PageController', 'cookiePolicy');
$router->get('/data-protection-policy', 'PageController', 'dataProtectionPolicy');
$router->get('/chat/conversations/{contactId}', 'ChatController', 'conversations', [AuthMiddleware::class]);
$router->post('/chat/send', 'ChatController', 'sendMessage', [AuthMiddleware::class]);
$router->post('/chat/upload', 'ChatController', 'uploadFile', [AuthMiddleware::class]);
$router->post('/chat/theme', 'ChatController', 'theme', [AuthMiddleware::class]);
$router->get('/chat/status', 'ChatController', 'status', [AuthMiddleware::class]);
$router->get('/print/report', 'PrintController', 'report', [AuthMiddleware::class]);

// ============================================
// 2. ADMIN ROUTES (Requires admin role)
// ============================================

// Dashboard
$router->get('/admin/dashboard', 'DashboardController', 'admin', [AuthMiddleware::class]);

// Profile
$router->get('/admin/profile', 'AdminController', 'profile', [AuthMiddleware::class]);
$router->post('/admin/profile', 'AdminController', 'updateProfile', [AuthMiddleware::class]);

// Activity Logs
$router->get('/admin/activity-logs', 'AdminController', 'activityLogs', [AuthMiddleware::class]);
$router->get('/admin/activity-logs/export', 'AdminController', 'exportActivityLogs', [AuthMiddleware::class]);
$router->post('/admin/activity-logs/clear-old', 'AdminController', 'clearOldActivityLogs', [AuthMiddleware::class]);

// ============================================
// 2.1 STUDENT MANAGEMENT (Admin only)
// ============================================
$router->get('/students', 'StudentController', 'index', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/students/create', 'StudentController', 'create', [AuthMiddleware::class, RoleMiddleware::class]);
$router->post('/students', 'StudentController', 'store', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/students/{id}', 'StudentController', 'show', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/students/{id}/edit', 'StudentController', 'edit', [AuthMiddleware::class, RoleMiddleware::class]);
$router->put('/students/{id}', 'StudentController', 'update', [AuthMiddleware::class, RoleMiddleware::class]);
$router->delete('/students/{id}', 'StudentController', 'delete', [AuthMiddleware::class, RoleMiddleware::class]);

// ============================================
// 2.2 LECTURER MANAGEMENT (Admin only)
// ============================================
$router->get('/lecturers', 'LecturerController', 'index', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/lecturers/create', 'LecturerController', 'create', [AuthMiddleware::class, RoleMiddleware::class]);
$router->post('/lecturers', 'LecturerController', 'store', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/lecturers/{id}', 'LecturerController', 'show', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/lecturers/{id}/edit', 'LecturerController', 'edit', [AuthMiddleware::class, RoleMiddleware::class]);
$router->put('/lecturers/{id}', 'LecturerController', 'update', [AuthMiddleware::class, RoleMiddleware::class]);
$router->delete('/lecturers/{id}', 'LecturerController', 'delete', [AuthMiddleware::class, RoleMiddleware::class]);

// ============================================
// 2.3 COURSE MANAGEMENT (Admin only)
// ============================================
$router->get('/courses', 'CourseController', 'index', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/courses/create', 'CourseController', 'create', [AuthMiddleware::class, RoleMiddleware::class]);
$router->post('/courses', 'CourseController', 'store', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/courses/{id}/edit', 'CourseController', 'edit', [AuthMiddleware::class, RoleMiddleware::class]);
$router->put('/courses/{id}', 'CourseController', 'update', [AuthMiddleware::class, RoleMiddleware::class]);
$router->delete('/courses/{id}', 'CourseController', 'delete', [AuthMiddleware::class, RoleMiddleware::class]);
$router->post('/courses/{id}/toggle', 'CourseController', 'toggleStatus', [AuthMiddleware::class, RoleMiddleware::class]);

// ============================================
// 2.4 DEPARTMENT MANAGEMENT (Admin only)
// ============================================
$router->get('/departments', 'DepartmentController', 'index', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/departments/create', 'DepartmentController', 'create', [AuthMiddleware::class, RoleMiddleware::class]);
$router->post('/departments', 'DepartmentController', 'store', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/departments/{id}/edit', 'DepartmentController', 'edit', [AuthMiddleware::class, RoleMiddleware::class]);
$router->put('/departments/{id}', 'DepartmentController', 'update', [AuthMiddleware::class, RoleMiddleware::class]);
$router->delete('/departments/{id}', 'DepartmentController', 'delete', [AuthMiddleware::class, RoleMiddleware::class]);

// ============================================
// 2.5 PAYMENT MANAGEMENT (Admin only)
// ============================================
$router->get('/payments', 'PaymentController', 'index', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/payments/create', 'PaymentController', 'create', [AuthMiddleware::class, RoleMiddleware::class]);
$router->post('/payments', 'PaymentController', 'store', [AuthMiddleware::class, RoleMiddleware::class]);
$router->post('/payments/{id}/mark-paid', 'PaymentController', 'markPaid', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/payments/{id}/receipt', 'PaymentController', 'receipt', [AuthMiddleware::class, RoleMiddleware::class]);

// ============================================
// 2.6 ANNOUNCEMENT MANAGEMENT (Admin & Lecturer)
// ============================================
$router->get('/announcements', 'AnnouncementController', 'index', [AuthMiddleware::class]);
$router->get('/announcements/create', 'AnnouncementController', 'create', [AuthMiddleware::class]);
$router->post('/announcements', 'AnnouncementController', 'store', [AuthMiddleware::class]);
$router->get('/announcements/{id}/edit', 'AnnouncementController', 'edit', [AuthMiddleware::class]);
$router->put('/announcements/{id}', 'AnnouncementController', 'update', [AuthMiddleware::class]);
$router->delete('/announcements/{id}', 'AnnouncementController', 'delete', [AuthMiddleware::class]);
$router->post('/announcements/{id}/publish', 'AnnouncementController', 'publish', [AuthMiddleware::class]);
$router->post('/announcements/{id}/unpublish', 'AnnouncementController', 'unpublish', [AuthMiddleware::class]);

// ============================================
// 2.7 LOG MANAGEMENT (Admin only) - NEW
// ============================================
$router->get('/logs', 'LogController', 'index', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/api/logs/{file}', 'LogController', 'view', [AuthMiddleware::class, RoleMiddleware::class]);
$router->delete('/api/logs/{file}', 'LogController', 'delete', [AuthMiddleware::class, RoleMiddleware::class]);
$router->post('/api/logs/{file}/clear', 'LogController', 'clear', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/api/logs/stats', 'LogController', 'stats', [AuthMiddleware::class, RoleMiddleware::class]);

// ============================================
// 3. LECTURER ROUTES (Requires lecturer role)
// ============================================

// Dashboard
$router->get('/lecturer/dashboard', 'DashboardController', 'lecturer', [AuthMiddleware::class]);

// Profile
$router->get('/lecturer/profile', 'LecturerController', 'profile', [AuthMiddleware::class]);
$router->post('/lecturer/profile', 'LecturerController', 'updateProfile', [AuthMiddleware::class]);

// ============================================
// 3.1 RESULT MANAGEMENT (Lecturer only)
// ============================================
$router->get('/results/upload', 'ResultController', 'upload', [AuthMiddleware::class, RoleMiddleware::class]);
$router->post('/results/upload', 'ResultController', 'postUploadResults', [AuthMiddleware::class, RoleMiddleware::class]);
$router->post('/results/publish', 'ResultController', 'publishResults', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/results', 'ResultController', 'index', [AuthMiddleware::class]);

// ============================================
// 3.2 ATTENDANCE MANAGEMENT (Lecturer only)
// ============================================
$router->get('/attendance/mark', 'AttendanceController', 'mark', [AuthMiddleware::class, RoleMiddleware::class]);
$router->post('/attendance/mark', 'AttendanceController', 'postMarkAttendance', [AuthMiddleware::class, RoleMiddleware::class]);
$router->get('/attendance/report', 'AttendanceController', 'report', [AuthMiddleware::class]);

// ============================================
// 3.3 COURSE VIEW (Lecturer)
// ============================================
$router->get('/lecturer/courses', 'LecturerController', 'courses', [AuthMiddleware::class]);
$router->get('/lecturer/courses/{id}/students', 'LecturerController', 'courseStudents', [AuthMiddleware::class]);

// ============================================
// 4. STUDENT ROUTES (Requires student role)
// ============================================

// Dashboard
$router->get('/student/dashboard', 'DashboardController', 'student', [AuthMiddleware::class]);

// Profile
$router->get('/student/profile', 'StudentController', 'profile', [AuthMiddleware::class]);
$router->post('/student/profile', 'StudentController', 'updateProfile', [AuthMiddleware::class]);

// ============================================
// 4.1 COURSE ENROLLMENT (Student only)
// ============================================
$router->get('/student/courses', 'StudentController', 'courses', [AuthMiddleware::class]);
$router->post('/student/enroll', 'StudentController', 'enrollCourse', [AuthMiddleware::class]);
$router->post('/student/drop', 'StudentController', 'dropCourse', [AuthMiddleware::class]);

// ============================================
// 4.2 STUDENT VIEWS (Student only)
// ============================================
$router->get('/student/timetable', 'StudentController', 'viewTimetable', [AuthMiddleware::class]);
$router->get('/student/results', 'StudentController', 'viewResults', [AuthMiddleware::class]);
$router->get('/student/payments', 'StudentController', 'viewPayments', [AuthMiddleware::class]);

// ============================================
// 5. API ROUTES (JSON responses)
// ============================================

// ============================================
// 5.1 PUBLIC API
// ============================================
$router->get('/api/health', 'ApiController', 'health');

// ============================================
// 5.2 AUTHENTICATED API
// ============================================

// Notifications
$router->get('/api/notifications', 'ApiController', 'getNotifications', [AuthMiddleware::class]);
$router->post('/api/notifications/{id}/read', 'ApiController', 'markNotificationRead', [AuthMiddleware::class]);
$router->put('/api/notifications/{id}/toggle', 'ApiController', 'toggleNotificationRead', [AuthMiddleware::class]);
$router->post('/api/notifications/read-all', 'ApiController', 'markAllRead', [AuthMiddleware::class]);
$router->post('/api/test-notification', 'ApiController', 'testNotification', [AuthMiddleware::class]);

// Dashboard Stats
$router->get('/api/dashboard-stats', 'ApiController', 'getDashboardStats', [AuthMiddleware::class]);

// Results
$router->get('/api/results', 'ApiController', 'getResults', [AuthMiddleware::class]);
$router->post('/api/results', 'ApiController', 'postResults', [AuthMiddleware::class]);

// Students
$router->get('/api/students', 'ApiController', 'getStudents', [AuthMiddleware::class]);
$router->get('/api/students/{id}', 'ApiController', 'getStudent', [AuthMiddleware::class]);

// Courses
$router->get('/api/courses', 'ApiController', 'getCourses', [AuthMiddleware::class]);
$router->get('/api/courses/{id}', 'ApiController', 'getCourse', [AuthMiddleware::class]);
$router->get('/api/courses/{id}/students', 'ApiController', 'getCourseStudents', [AuthMiddleware::class]);

// Payments
$router->post('/api/payments', 'ApiController', 'postPayment', [AuthMiddleware::class]);
$router->get('/api/payments/{id}', 'ApiController', 'getPayment', [AuthMiddleware::class]);

// Attendance
$router->post('/api/attendance', 'ApiController', 'postAttendance', [AuthMiddleware::class]);
$router->get('/api/attendance/report', 'ApiController', 'getAttendanceReport', [AuthMiddleware::class]);

// Announcements
$router->post('/api/announcements', 'ApiController', 'postAnnouncement', [AuthMiddleware::class]);
$router->get('/api/announcements', 'ApiController', 'getAnnouncements', [AuthMiddleware::class]);

// Timetable
$router->get('/api/timetable', 'ApiController', 'getTimetable', [AuthMiddleware::class]);

// ============================================
// 6. ERROR PAGES
// ============================================

// 404 Not Found - Handled by router
$router->setNotFound(function() {
    http_response_code(404);
    if (file_exists(ROOT_PATH . '/views/errors/404.php')) {
        include ROOT_PATH . '/views/errors/404.php';
    } else {
        echo "<h1>404 - Page Not Found</h1>";
        echo "<p>The page you are looking for does not exist.</p>";
    }
});

// ============================================
// 7. RETURN ROUTER
// ============================================

return $router;