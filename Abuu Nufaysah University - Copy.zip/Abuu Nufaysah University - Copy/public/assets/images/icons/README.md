# PWA App Icons

This directory should contain the following icon sizes for the PWA:

- icon-72x72.png (72x72)
- icon-96x96.png (96x96)
- icon-128x128.png (128x128)
- icon-144x144.png (144x144)
- icon-152x152.png (152x152)
- icon-192x192.png (192x192)
- icon-384x384.png (384x384)
- icon-512x512.png (512x512)

## How to Generate Icons

### Option 1: Using Online Tools
1. Visit https://www.pwabuilder.com/imageGenerator
2. Upload your logo (minimum 512x512)
3. Download the generated icon set
4. Extract and place icons in this directory

### Option 2: Using ImageMagick
```bash
# Convert your logo to different sizes
convert logo.png -resize 72x72 icon-72x72.png
convert logo.png -resize 96x96 icon-96x96.png
convert logo.png -resize 128x128 icon-128x128.png
convert logo.png -resize 144x144 icon-144x144.png
convert logo.png -resize 152x152 icon-152x152.png
convert logo.png -resize 192x192 icon-192x192.png
convert logo.png -resize 384x384 icon-384x384.png
convert logo.png -resize 512x512 icon-512x512.png
```

### Option 3: Using Figma/Sketch
1. Create a 512x512 artboard
2. Design your app icon
3. Export at multiple resolutions
4. Place in this directory

## Icon Guidelines

- Use a simple, recognizable logo
- Ensure good contrast on all backgrounds
- Test on both light and dark backgrounds
- Avoid too much detail (icons are small)
- Use PNG format with transparency if needed
- For maskable icons, ensure content is within safe zone

## Temporary Placeholders

Until you create proper icons, the PWA will use a default browser icon. 
Replace these placeholder files with your actual app icons for the best experience.
