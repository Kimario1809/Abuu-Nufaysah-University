/**
 * Real-time Updates System
 * Handles WebSocket connections or polling for real-time data
 */

class Realtime {
    constructor() {
        this.ws = null;
        this.pollingInterval = 5000;
        this.handlers = [];
        this.isConnected = false;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.init();
    }
    
    init() {
        // Use Server-Sent Events or WebSocket
        if (this.supportsWebSocket()) {
            this.initWebSocket();
        } else {
            this.initPolling();
        }
    }
    
    supportsWebSocket() {
        return 'WebSocket' in window && window.location.protocol === 'https:';
    }
    
    initWebSocket() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/ws`;
        
        try {
            this.ws = new WebSocket(wsUrl);
            
            this.ws.onopen = () => {
                console.log('WebSocket connected');
                this.isConnected = true;
                this.reconnectAttempts = 0;
                this.onConnected();
            };
            
            this.ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.handleMessage(data);
                } catch (e) {
                    console.error('Failed to parse WebSocket message:', e);
                }
            };
            
            this.ws.onclose = () => {
                console.log('WebSocket disconnected');
                this.isConnected = false;
                this.reconnect();
            };
            
            this.ws.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.isConnected = false;
            };
        } catch (e) {
            console.error('Failed to initialize WebSocket:', e);
            this.initPolling();
        }
    }
    
    initPolling() {
        console.log('Using polling for real-time updates');
        this.pollingTimer = setInterval(() => {
            this.pollUpdates();
        }, this.pollingInterval);
    }
    
    pollUpdates() {
        // Fetch updates from server
        fetch('/api/updates')
            .then(response => response.json())
            .then(data => {
                this.handleMessage(data);
            })
            .catch(error => {
                console.error('Polling error:', error);
            });
    }
    
    reconnect() {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.log('Max reconnect attempts reached, switching to polling');
            this.initPolling();
            return;
        }
        
        this.reconnectAttempts++;
        const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30000);
        
        setTimeout(() => {
            console.log(`Attempting to reconnect (${this.reconnectAttempts}/${this.maxReconnectAttempts})...`);
            this.initWebSocket();
        }, delay);
    }
    
    onConnected() {
        // Send authentication if needed
        if (window.userToken) {
            this.send({
                type: 'auth',
                token: window.userToken
            });
        }
    }
    
    send(data) {
        if (this.ws && this.isConnected) {
            this.ws.send(JSON.stringify(data));
        }
    }
    
    handleMessage(data) {
        // Handle different message types
        switch (data.type) {
            case 'notification':
                this.handleNotification(data);
                break;
            case 'announcement':
                this.handleAnnouncement(data);
                break;
            case 'update':
                this.handleUpdate(data);
                break;
            default:
                // Call registered handlers
                this.handlers.forEach(handler => {
                    try {
                        handler(data);
                    } catch (e) {
                        console.error('Handler error:', e);
                    }
                });
        }
    }
    
    handleNotification(data) {
        // Show notification toast
        if (window.showToast) {
            window.showToast(
                data.title || 'Notification',
                data.message || 'You have a new notification',
                data.type || 'info'
            );
        }
        
        // Update notification badge
        if (data.unread_count !== undefined) {
            this.updateNotificationBadge(data.unread_count);
        }
    }
    
    handleAnnouncement(data) {
        // Update announcements list
        this.updateAnnouncements(data);
        
        // Show announcement toast
        if (window.showToast) {
            window.showToast(
                '📢 ' + data.title,
                data.message || 'New announcement available',
                'warning'
            );
        }
    }
    
    handleUpdate(data) {
        // Update dashboard stats
        if (data.stats) {
            Object.keys(data.stats).forEach(key => {
                const element = document.getElementById(key);
                if (element) {
                    element.textContent = data.stats[key];
                }
            });
        }
    }
    
    updateNotificationBadge(count) {
        const badge = document.getElementById('notification-badge');
        if (badge) {
            if (count > 0) {
                badge.textContent = count;
                badge.style.display = 'inline';
            } else {
                badge.style.display = 'none';
            }
        }
    }
    
    updateAnnouncements(data) {
        const container = document.getElementById('announcements-list');
        if (!container) return;
        
        const html = `
            <div class="announcement-item mb-3">
                <h6>${this.escapeHtml(data.title)}</h6>
                <small class="text-muted">${new Date(data.created_at).toLocaleString()}</small>
                <p class="mt-1">${this.escapeHtml(data.message.substring(0, 100))}...</p>
            </div>
            ${container.innerHTML}
        `;
        
        // Keep only last 10 items
        const items = container.querySelectorAll('.announcement-item');
        if (items.length >= 10) {
            items[items.length - 1].remove();
        }
        
        container.innerHTML = html;
    }
    
    on(handler) {
        this.handlers.push(handler);
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize real-time system
document.addEventListener('DOMContentLoaded', function() {
    window.realtime = new Realtime();
});