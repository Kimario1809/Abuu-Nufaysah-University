/**
 * Push Notification Manager
 * Handles Web Push API subscription and notification display
 */

class PushNotificationManager {
    constructor(options = {}) {
        this.applicationServerKey = options.applicationServerKey || null;
        this.subscribeUrl = options.subscribeUrl || '/api/push/subscribe';
        this.unsubscribeUrl = options.unsubscribeUrl || '/api/push/unsubscribe';
        this.serviceWorkerUrl = options.serviceWorkerUrl || '/sw.js';
        this.onPermissionGranted = options.onPermissionGranted || null;
        this.onPermissionDenied = options.onPermissionDenied || null;
        this.onSubscriptionSuccess = options.onSubscriptionSuccess || null;
        this.onSubscriptionError = options.onSubscriptionError || null;
        
        this.subscription = null;
        this.registration = null;
        this.isSupported = this.checkSupport();
    }

    /**
     * Check if push notifications are supported
     */
    checkSupport() {
        return 'serviceWorker' in navigator && 
               'PushManager' in window && 
               'Notification' in window;
    }

    /**
     * Initialize push notifications
     */
    async init() {
        if (!this.isSupported) {
            console.warn('Push notifications are not supported in this browser');
            return false;
        }

        try {
            // Register service worker
            this.registration = await navigator.serviceWorker.register(this.serviceWorkerUrl);
            console.log('Service Worker registered:', this.registration);

            // Get existing subscription
            this.subscription = await this.registration.pushManager.getSubscription();
            
            if (this.subscription) {
                console.log('Existing subscription found:', this.subscription);
                // Verify subscription with server
                await this.verifySubscription();
            } else {
                console.log('No existing subscription');
            }

            return true;
        } catch (error) {
            console.error('Push notification initialization error:', error);
            return false;
        }
    }

    /**
     * Request permission and subscribe
     */
    async subscribe() {
        if (!this.isSupported) {
            console.error('Push notifications not supported');
            return false;
        }

        try {
            // Request permission
            const permission = await Notification.requestPermission();
            
            if (permission === 'granted') {
                console.log('Notification permission granted');
                
                if (this.onPermissionGranted) {
                    this.onPermissionGranted();
                }
                
                // Subscribe to push
                return await this.createSubscription();
            } else {
                console.warn('Notification permission denied');
                
                if (this.onPermissionDenied) {
                    this.onPermissionDenied();
                }
                
                return false;
            }
        } catch (error) {
            console.error('Permission request error:', error);
            
            if (this.onSubscriptionError) {
                this.onSubscriptionError(error);
            }
            
            return false;
        }
    }

    /**
     * Create push subscription
     */
    async createSubscription() {
        if (!this.registration) {
            await this.init();
        }

        try {
            const subscribeOptions = {
                userVisibleOnly: true,
                applicationServerKey: this.urlBase64ToUint8Array(this.applicationServerKey)
            };

            this.subscription = await this.registration.pushManager.subscribe(subscribeOptions);
            console.log('Push subscription created:', this.subscription);

            // Send subscription to server
            const success = await this.sendSubscriptionToServer(this.subscription);
            
            if (success && this.onSubscriptionSuccess) {
                this.onSubscriptionSuccess(this.subscription);
            }

            return success;
        } catch (error) {
            console.error('Subscription creation error:', error);
            
            if (this.onSubscriptionError) {
                this.onSubscriptionError(error);
            }
            
            return false;
        }
    }

    /**
     * Unsubscribe from push notifications
     */
    async unsubscribe() {
        if (!this.subscription) {
            console.log('No subscription to unsubscribe');
            return true;
        }

        try {
            const success = await this.subscription.unsubscribe();
            
            if (success) {
                console.log('Unsubscribed successfully');
                
                // Remove from server
                await this.removeSubscriptionFromServer();
                
                this.subscription = null;
                return true;
            }
            
            return false;
        } catch (error) {
            console.error('Unsubscribe error:', error);
            return false;
        }
    }

    /**
     * Send subscription to server
     */
    async sendSubscriptionToServer(subscription) {
        try {
            const subscriptionData = {
                endpoint: subscription.endpoint,
                keys: {
                    p256dh: subscription.getKey('p256dh'),
                    auth: subscription.getKey('auth')
                }
            };

            const response = await fetch(this.subscribeUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-Token': this.getCsrfToken()
                },
                credentials: 'include',
                body: JSON.stringify(subscriptionData)
            });

            if (!response.ok) {
                throw new Error('Failed to send subscription to server');
            }

            const data = await response.json();
            console.log('Subscription saved on server:', data);
            return true;
        } catch (error) {
            console.error('Error sending subscription to server:', error);
            return false;
        }
    }

    /**
     * Remove subscription from server
     */
    async removeSubscriptionFromServer() {
        try {
            if (!this.subscription) {
                return true;
            }

            const response = await fetch(this.unsubscribeUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-Token': this.getCsrfToken()
                },
                credentials: 'include',
                body: JSON.stringify({
                    endpoint: this.subscription.endpoint
                })
            });

            if (!response.ok) {
                throw new Error('Failed to remove subscription from server');
            }

            console.log('Subscription removed from server');
            return true;
        } catch (error) {
            console.error('Error removing subscription from server:', error);
            return false;
        }
    }

    /**
     * Verify subscription with server
     */
    async verifySubscription() {
        try {
            if (!this.subscription) {
                return false;
            }

            const response = await fetch('/api/push/verify', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                credentials: 'include',
                body: JSON.stringify({
                    endpoint: this.subscription.endpoint
                })
            });

            if (!response.ok) {
                // Subscription invalid, resubscribe
                console.log('Subscription invalid, resubscribing...');
                await this.unsubscribe();
                await this.subscribe();
                return false;
            }

            return true;
        } catch (error) {
            console.error('Subscription verification error:', error);
            return false;
        }
    }

    /**
     * Check permission status
     */
    getPermissionStatus() {
        if (!this.isSupported) {
            return 'unsupported';
        }

        return Notification.permission;
    }

    /**
     * Check if subscribed
     */
    isSubscribed() {
        return this.subscription !== null;
    }

    /**
     * Enable/disable notifications
     */
    async setEnabled(enabled) {
        if (enabled) {
            if (this.getPermissionStatus() === 'granted') {
                if (!this.isSubscribed()) {
                    return await this.subscribe();
                }
                return true;
            } else {
                return await this.subscribe();
            }
        } else {
            if (this.isSubscribed()) {
                return await this.unsubscribe();
            }
            return true;
        }
    }

    /**
     * Convert base64 string to Uint8Array
     */
    urlBase64ToUint8Array(base64String) {
        const padding = '='.repeat((4 - base64String.length % 4) % 4);
        const base64 = (base64String + padding).replace(/\-/g, '+').replace(/_/g, '/');
        
        const rawData = window.atob(base64);
        const outputArray = new Uint8Array(rawData.length);
        
        for (let i = 0; i < rawData.length; ++i) {
            outputArray[i] = rawData.charCodeAt(i);
        }
        
        return outputArray;
    }

    /**
     * Get CSRF token
     */
    getCsrfToken() {
        const metaTag = document.querySelector('meta[name="csrf-token"]');
        if (metaTag) {
            return metaTag.getAttribute('content');
        }
        
        const match = document.cookie.match(/csrf_token=([^;]+)/);
        return match ? match[1] : '';
    }
}

// Initialize push notification manager when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is authenticated
    const isAuthenticated = document.body.getAttribute('data-authenticated') === 'true';
    
    if (!isAuthenticated) {
        return;
    }

    // Get VAPID public key from meta tag or config
    const vapidKey = document.querySelector('meta[name="vapid-key"]')?.getAttribute('content') || null;
    
    if (!vapidKey) {
        console.warn('VAPID key not found. Push notifications will not work.');
        return;
    }

    // Initialize push notification manager
    window.pushNotificationManager = new PushNotificationManager({
        applicationServerKey: vapidKey,
        subscribeUrl: '/api/push/subscribe',
        unsubscribeUrl: '/api/push/unsubscribe',
        serviceWorkerUrl: '/sw.js',
        onPermissionGranted: function() {
            console.log('Push notification permission granted');
            updatePushNotificationUI(true);
        },
        onPermissionDenied: function() {
            console.log('Push notification permission denied');
            updatePushNotificationUI(false);
        },
        onSubscriptionSuccess: function(subscription) {
            console.log('Push notification subscription successful');
            updatePushNotificationUI(true);
        },
        onSubscriptionError: function(error) {
            console.error('Push notification subscription error:', error);
            updatePushNotificationUI(false);
        }
    });

    // Initialize push notifications
    window.pushNotificationManager.init().then(success => {
        if (success) {
            // Check if user has previously enabled notifications
            const pushEnabled = localStorage.getItem('pushEnabled') === 'true';
            
            if (pushEnabled && window.pushNotificationManager.getPermissionStatus() === 'granted') {
                window.pushNotificationManager.subscribe();
            }
        }
    });
});

/**
 * Update push notification UI
 */
function updatePushNotificationUI(enabled) {
    const toggle = document.querySelector('.push-notification-toggle');
    if (toggle) {
        toggle.checked = enabled;
    }
    
    // Save preference
    localStorage.setItem('pushEnabled', enabled);
}

/**
 * Handle push notification toggle
 */
document.addEventListener('DOMContentLoaded', function() {
    const toggle = document.querySelector('.push-notification-toggle');
    
    if (toggle) {
        toggle.addEventListener('change', async function() {
            const enabled = this.checked;
            
            if (window.pushNotificationManager) {
                const success = await window.pushNotificationManager.setEnabled(enabled);
                
                if (!success) {
                    this.checked = !enabled;
                    alert('Failed to ' + (enabled ? 'enable' : 'disable') + ' push notifications');
                }
            }
        });
    }
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PushNotificationManager;
}
