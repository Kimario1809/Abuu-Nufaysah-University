/**
 * Real-time Notification Polling System
 * AJAX-based notification polling for Abuu Nufaysah University System
 */

class NotificationPoller {
    constructor(options = {}) {
        this.apiUrl = options.apiUrl || '/api/notifications';
        this.pollInterval = options.pollInterval || 30000; // 30 seconds default
        this.maxRetries = options.maxRetries || 3;
        this.retryDelay = options.retryDelay || 5000;
        this.onNewNotifications = options.onNewNotifications || null;
        this.onError = options.onError || null;
        this.onPollStart = options.onPollStart || null;
        this.onPollEnd = options.onPollEnd || null;
        
        this.polling = false;
        this.pollTimer = null;
        this.lastPollTime = null;
        this.retryCount = 0;
        this.unreadCount = 0;
        this.notifications = [];
    }

    /**
     * Start polling for notifications
     */
    start() {
        if (this.polling) {
            console.warn('Notification polling already active');
            return;
        }

        this.polling = true;
        this.retryCount = 0;
        console.log('Starting notification polling...');
        
        // Initial poll
        this.poll();
        
        // Set up interval polling
        this.pollTimer = setInterval(() => {
            this.poll();
        }, this.pollInterval);
    }

    /**
     * Stop polling for notifications
     */
    stop() {
        if (!this.polling) {
            return;
        }

        this.polling = false;
        
        if (this.pollTimer) {
            clearInterval(this.pollTimer);
            this.pollTimer = null;
        }
        
        console.log('Notification polling stopped');
    }

    /**
     * Poll for new notifications
     */
    async poll() {
        if (!this.polling) {
            return;
        }

        if (this.onPollStart) {
            this.onPollStart();
        }

        try {
            const since = this.lastPollTime ? new Date(this.lastPollTime).toISOString() : null;
            const url = `${this.apiUrl}?limit=10${since ? `&since=${since}` : ''}`;
            
            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                credentials: 'same-origin'
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            
            if (data.success) {
                this.lastPollTime = new Date();
                this.retryCount = 0;
                
                const newNotifications = data.data.notifications || [];
                const unreadCount = data.data.unread_count || 0;
                
                // Check for new notifications
                if (this.hasNewNotifications(newNotifications)) {
                    this.notifications = newNotifications;
                    this.unreadCount = unreadCount;
                    
                    if (this.onNewNotifications) {
                        this.onNewNotifications(newNotifications, unreadCount);
                    }
                    
                    // Play notification sound if enabled
                    this.playNotificationSound();
                } else {
                    // Update unread count even if no new notifications
                    if (unreadCount !== this.unreadCount) {
                        this.unreadCount = unreadCount;
                        if (this.onNewNotifications) {
                            this.onNewNotifications(this.notifications, unreadCount);
                        }
                    }
                }
            }
        } catch (error) {
            console.error('Notification polling error:', error);
            this.retryCount++;
            
            if (this.onError) {
                this.onError(error, this.retryCount);
            }
            
            // Stop polling after max retries
            if (this.retryCount >= this.maxRetries) {
                console.error('Max retries reached. Stopping notification polling.');
                this.stop();
            }
        } finally {
            if (this.onPollEnd) {
                this.onPollEnd();
            }
        }
    }

    /**
     * Check if there are new notifications
     */
    hasNewNotifications(newNotifications) {
        if (this.notifications.length === 0 && newNotifications.length > 0) {
            return true;
        }
        
        // Compare notification IDs or timestamps
        const oldIds = new Set(this.notifications.map(n => n.id));
        return newNotifications.some(n => !oldIds.has(n.id));
    }

    /**
     * Play notification sound
     */
    playNotificationSound() {
        try {
            // Check if sound is enabled in localStorage
            const soundEnabled = localStorage.getItem('notificationSound') !== 'false';
            
            if (!soundEnabled) {
                return;
            }
            
            // Create audio context for beep sound
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = 800;
            oscillator.type = 'sine';
            gainNode.gain.value = 0.1;
            
            oscillator.start();
            oscillator.stop(audioContext.currentTime + 0.2);
        } catch (error) {
            console.error('Error playing notification sound:', error);
        }
    }

    /**
     * Mark notification as read
     */
    async markAsRead(notificationId) {
        try {
            const response = await fetch(`/api/notifications/${notificationId}/read`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-Token': this.getCsrfToken()
                },
                credentials: 'same-origin',
                body: JSON.stringify({})
            });

            if (response.ok) {
                // Update local unread count
                if (this.unreadCount > 0) {
                    this.unreadCount--;
                }
                
                // Remove notification from local list
                this.notifications = this.notifications.filter(n => n.id !== notificationId);
                
                return true;
            }
        } catch (error) {
            console.error('Error marking notification as read:', error);
        }
        
        return false;
    }

    /**
     * Mark all notifications as read
     */
    async markAllAsRead() {
        try {
            const unreadIds = this.notifications
                .filter(n => !n.is_read)
                .map(n => n.id);
            
            for (const id of unreadIds) {
                await this.markAsRead(id);
            }
            
            this.unreadCount = 0;
            return true;
        } catch (error) {
            console.error('Error marking all notifications as read:', error);
        }
        
        return false;
    }

    /**
     * Get CSRF token from meta tag or cookie
     */
    getCsrfToken() {
        const metaTag = document.querySelector('meta[name="csrf-token"]');
        if (metaTag) {
            return metaTag.getAttribute('content');
        }
        
        // Fallback to cookie
        const match = document.cookie.match(/csrf_token=([^;]+)/);
        return match ? match[1] : '';
    }

    /**
     * Get current unread count
     */
    getUnreadCount() {
        return this.unreadCount;
    }

    /**
     * Get current notifications
     */
    getNotifications() {
        return this.notifications;
    }

    /**
     * Update poll interval
     */
    setPollInterval(interval) {
        this.pollInterval = interval;
        
        if (this.polling) {
            this.stop();
            this.start();
        }
    }

    /**
     * Check if polling is active
     */
    isActive() {
        return this.polling;
    }
}

// Initialize notification poller when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is authenticated
    const isAuthenticated = document.body.getAttribute('data-authenticated') === 'true';
    
    if (!isAuthenticated) {
        return;
    }
    
    // Initialize poller
    window.notificationPoller = new NotificationPoller({
        apiUrl: '/api/notifications',
        pollInterval: 30000, // 30 seconds
        maxRetries: 3,
        onNewNotifications: function(notifications, unreadCount) {
            updateNotificationUI(notifications, unreadCount);
        },
        onError: function(error, retryCount) {
            console.error(`Notification poll error (attempt ${retryCount}):`, error);
        }
    });
    
    // Start polling
    window.notificationPoller.start();
});

/**
 * Update notification UI elements
 */
function updateNotificationUI(notifications, unreadCount) {
    // Update notification badge
    const badge = document.querySelector('.notification-badge');
    if (badge) {
        if (unreadCount > 0) {
            badge.textContent = unreadCount > 99 ? '99+' : unreadCount;
            badge.style.display = 'flex';
        } else {
            badge.style.display = 'none';
        }
    }
    
    // Update notification list
    const notificationList = document.querySelector('.notification-list');
    if (notificationList) {
        renderNotificationList(notifications, notificationList);
    }
    
    // Trigger custom event for other components
    document.dispatchEvent(new CustomEvent('notificationsUpdated', {
        detail: { notifications, unreadCount }
    }));
}

/**
 * Render notification list
 */
function renderNotificationList(notifications, container) {
    if (!notifications || notifications.length === 0) {
        container.innerHTML = `
            <div class="notification-empty">
                <p>No new notifications</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = notifications.map(notification => `
        <div class="notification-item ${notification.is_read ? 'read' : 'unread'}" data-id="${notification.id}">
            <div class="notification-icon">
                <i class="bi ${getNotificationIcon(notification.type)}"></i>
            </div>
            <div class="notification-content">
                <div class="notification-title">${escapeHtml(notification.title)}</div>
                <div class="notification-message">${escapeHtml(notification.message)}</div>
                <div class="notification-time">${formatNotificationTime(notification.created_at)}</div>
            </div>
            ${!notification.is_read ? `
                <button class="notification-mark-read" data-id="${notification.id}" title="Mark as read">
                    <i class="bi bi-check"></i>
                </button>
            ` : ''}
        </div>
    `).join('');
    
    // Add click handlers for mark as read buttons
    container.querySelectorAll('.notification-mark-read').forEach(button => {
        button.addEventListener('click', async function(e) {
            e.preventDefault();
            const notificationId = this.getAttribute('data-id');
            
            if (window.notificationPoller) {
                const success = await window.notificationPoller.markAsRead(notificationId);
                if (success) {
                    this.closest('.notification-item').classList.remove('unread');
                    this.closest('.notification-item').classList.add('read');
                    this.remove();
                }
            }
        });
    });
}

/**
 * Get icon class based on notification type
 */
function getNotificationIcon(type) {
    const icons = {
        'payment': 'bi-credit-card',
        'assignment': 'bi-file-earmark-text',
        'grade': 'bi-graph-up',
        'announcement': 'bi-megaphone',
        'chat': 'bi-chat-dots',
        'system': 'bi-gear',
        'alert': 'bi-exclamation-triangle',
        'success': 'bi-check-circle',
        'info': 'bi-info-circle'
    };
    
    return icons[type] || 'bi-bell';
}

/**
 * Format notification time
 */
function formatNotificationTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) {
        return 'Just now';
    } else if (minutes < 60) {
        return `${minutes}m ago`;
    } else if (hours < 24) {
        return `${hours}h ago`;
    } else if (days < 7) {
        return `${days}d ago`;
    } else {
        return date.toLocaleDateString();
    }
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = NotificationPoller;
}
