/**
 * API Helper for Abuu Nufay'sah University
 * Handles all API calls with authentication
 */

class API {
    constructor(baseUrl = '/api') {
        this.baseUrl = baseUrl;
        this.headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };
    }
    
    setAuthToken(token) {
        this.headers['Authorization'] = 'Bearer ' + token;
    }
    
    async request(endpoint, method = 'GET', data = null) {
        const url = this.baseUrl + endpoint;
        const options = {
            method: method,
            headers: this.headers
        };
        
        if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
            options.body = JSON.stringify(data);
        }
        
        try {
            const response = await fetch(url, options);
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'API request failed');
            }
            
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }
    
    // GET requests
    async get(endpoint) {
        return this.request(endpoint, 'GET');
    }
    
    // POST requests
    async post(endpoint, data) {
        return this.request(endpoint, 'POST', data);
    }
    
    // PUT requests
    async put(endpoint, data) {
        return this.request(endpoint, 'PUT', data);
    }
    
    // DELETE requests
    async delete(endpoint) {
        return this.request(endpoint, 'DELETE');
    }
    
    // Specific API endpoints
    async getNotifications(limit = 10) {
        return this.get(`/notifications?limit=${limit}`);
    }
    
    async getDashboardStats() {
        return this.get('/dashboard-stats');
    }
    
    async getResults(studentId) {
        return this.get(`/results?student_id=${studentId}`);
    }
    
    async getStudents(search = '', department = '') {
        let url = '/students';
        const params = new URLSearchParams();
        if (search) params.append('search', search);
        if (department) params.append('department', department);
        if (params.toString()) url += '?' + params.toString();
        return this.get(url);
    }
    
    async postPayment(data) {
        return this.post('/payments', data);
    }
    
    async markAttendance(data) {
        return this.post('/attendance', data);
    }
    
    async uploadResults(data) {
        return this.post('/results', data);
    }
    
    async getTimetable(studentId) {
        return this.get(`/timetable?student_id=${studentId}`);
    }
}

// Create singleton instance
const api = new API();

// Export for use in other modules
window.api = api;