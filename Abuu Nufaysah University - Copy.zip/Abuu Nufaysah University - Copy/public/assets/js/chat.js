document.addEventListener('DOMContentLoaded', function () {
    const chatMessages = document.getElementById('chatMessages');
    const messageInput = document.getElementById('messageInput');
    const sendMessageBtn = document.getElementById('sendMessageBtn');
    const contactButtons = document.querySelectorAll('.chat-contact');
    const themePreset = document.getElementById('themePreset');
    const saveThemeBtn = document.getElementById('saveThemeBtn');

    if (!chatMessages || !messageInput || !sendMessageBtn) return;

    const renderMessage = (message) => {
        const bubble = document.createElement('div');
        bubble.className = 'chat-bubble';
        bubble.innerHTML = `<div class="message-body">${message.body || ''}</div><div class="message-meta">${message.status || 'sent'}</div>`;
        chatMessages.appendChild(bubble);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    };

    const openChat = (contactId) => {
        window.currentContactId = contactId;
        fetch(`/chat/conversations/${contactId}`)
            .then((response) => response.json())
            .then((data) => {
                window.currentChatId = data.chat.id;
                chatMessages.innerHTML = '';
                (data.messages || []).forEach(renderMessage);
            });
    };

    contactButtons.forEach((button) => {
        button.addEventListener('click', function () {
            openChat(this.dataset.contactId);
        });
    });

    sendMessageBtn.addEventListener('click', function () {
        const body = messageInput.value.trim();
        if (!body || !window.currentContactId) return;
        fetch('/chat/send', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
            body: new URLSearchParams({chat_id: window.currentChatId || '', contact_id: window.currentContactId, body})
        })
            .then((response) => response.json())
            .then(() => {
                messageInput.value = '';
            });
    });

    if (saveThemeBtn) {
        saveThemeBtn.addEventListener('click', function () {
            const customColors = {
                primary_color: document.getElementById('primaryColor').value,
                bg_color: document.getElementById('bgColor').value,
                text_color: document.getElementById('textColor').value,
                secondary_color: '#6c757d',
                sidebar_color: '#1f2937',
                card_color: '#ffffff'
            };
            fetch('/chat/theme', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
                body: new URLSearchParams({theme_name: themePreset.value, custom_colors: JSON.stringify(customColors)})
            }).then(() => window.location.reload());
        });
    }
});
