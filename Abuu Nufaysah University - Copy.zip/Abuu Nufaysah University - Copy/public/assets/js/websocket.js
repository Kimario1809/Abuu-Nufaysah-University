/**
 * WebSocket Client for Real-Time Notifications
 * Socket.io client implementation
 * Abuu Nufaysah University System
 */

class WebSocketNotificationManager {
    constructor(options = {}) {
        this.serverUrl = options.serverUrl || window.location.hostname;
        this.port = options.port || 3001;
        this.useSSL = options.useSSL || window.location.protocol === 'https:';
        this.autoReconnect = options.autoReconnect !== false;
        this.reconnectDelay = options.reconnectDelay || 5000;
        this.maxReconnectAttempts = options.maxReconnectAttempts || 10;
        
        this.socket = null;
        this.isConnected = false;
        this.isAuthenticated = false;
        this.reconnectAttempts = 0;
        this.reconnectTimer = null;
        
        this.onNotification = options.onNotification || null;
        this.onConnect = options.onConnect || null;
        this.onDisconnect = options.onDisconnect || null;
        this.onError = options.onError || null;
        this.onInitialNotifications = options.onInitialNotifications || null;
        
        this.supported = this.checkSupport();
    }
    
    /**
     * Check if WebSocket is supported
     */
    checkSupport() {
        return typeof io !== 'undefined';
    }
    
    /**
     * Connect to WebSocket server
     */
    connect() {
        if (!this.supported) {
            console.error('Socket.io not loaded. Include socket.io-client library.');
            return false;
        }
        
        if (this.socket && this.isConnected) {
            console.log('Already connected to WebSocket server');
            return true;
        }
        
        try {
            const protocol = this.useSSL ? 'https' : 'http';
            const url = `${protocol}://${this.serverUrl}:${this.port}`;
            
            console.log(`Connecting to WebSocket server: ${url}`);
            
            this.socket = io(url, {
                transports: ['websocket', 'polling'],
                reconnection: this.autoReconnect,
                reconnectionDelay: this.reconnectDelay,
                reconnectionAttempts: this.maxReconnectAttempts
            });
            
            this.setupEventHandlers();
            
            return true;
        } catch (error) {
            console.error('WebSocket connection error:', error);
            this.handleError(error);
            return false;
        }
    }
    
    /**
     * Setup Socket.io event handlers
     */
    setupEventHandlers() {
        // Connection established
        this.socket.on('connect', () => {
            console.log('Connected to WebSocket server');
            this.isConnected = true;
            this.reconnectAttempts = 0;
            
            // Authenticate user
            this.authenticate();
            
            if (this.onConnect) {
                this.onConnect();
            }
        });
        
        // Connection error
        this.socket.on('connect_error', (error) => {
            console.error('WebSocket connection error:', error);
            this.handleError(error);
        });
        
        // Disconnection
        this.socket.on('disconnect', (reason) => {
            console.log('Disconnected from WebSocket server:', reason);
            this.isConnected = false;
            this.isAuthenticated = false;
            
            if (this.onDisconnect) {
                this.onDisconnect(reason);
            }
        });
        
        // Authentication response
        this.socket.on('authenticated', (data) => {
            if (data.success) {
                console.log('WebSocket authenticated:', data.user);
                this.isAuthenticated = true;
            } else {
                console.error('WebSocket authentication failed:', data.message);
                this.isAuthenticated = false;
            }
        });
        
        // Initial notifications
        this.socket.on('initial_notifications', (notifications) => {
            console.log('Received initial notifications:', notifications.length);
            
            if (this.onInitialNotifications) {
                this.onInitialNotifications(notifications);
            }
        });
        
        // New notification
        this.socket.on('notification', (notification) => {
            console.log('New notification received:', notification.title);
            
            // Play sound
            this.playNotificationSound();
            
            // Update UI
            this.updateNotificationBadge();
            
            if (this.onNotification) {
                this.onNotification(notification);
            }
        });
        
        // Reconnection attempt
        this.socket.on('reconnect_attempt', (attemptNumber) => {
            console.log(`WebSocket reconnection attempt ${attemptNumber}`);
            this.reconnectAttempts = attemptNumber;
        });
        
        // Reconnection successful
        this.socket.on('reconnect', (attemptNumber) => {
            console.log(`WebSocket reconnected after ${attemptNumber} attempts`);
            this.reconnectAttempts = 0;
        });
        
        // Reconnection failed
        this.socket.on('reconnect_failed', () => {
            console.error('WebSocket reconnection failed');
            this.isConnected = false;
            this.isAuthenticated = false;
        });
    }
    
    /**
     * Authenticate with WebSocket server
     */
    authenticate() {
        const userId = this.getUserId();
        const token = this.getCsrfToken();
        
        if (!userId) {
            console.warn('User ID not found, skipping WebSocket authentication');
            return;
        }
        
        this.socket.emit('authenticate', {
            userId: userId,
            token: token
        });
    }
    
    /**
     * Get user ID from page
     */
    getUserId() {
        // Try to get from meta tag
        const metaTag = document.querySelector('meta[name="user-id"]');
        if (metaTag) {
            return metaTag.getAttribute('content');
        }
        
        // Try to get from data attribute
        const body = document.body;
        if (body && body.dataset.userId) {
            return body.dataset.userId;
        }
        
        // Try to get from localStorage
        const storedUserId = localStorage.getItem('user_id');
        if (storedUserId) {
            return storedUserId;
        }
        
        return null;
    }
    
    /**
     * Get CSRF token
     */
    getCsrfToken() {
        const metaTag = document.querySelector('meta[name="csrf-token"]');
        if (metaTag) {
            return metaTag.getAttribute('content');
        }
        
        const match = document.cookie.match(/csrf_token=([^;]+)/);
        return match ? match[1] : '';
    }
    
    /**
     * Disconnect from WebSocket server
     */
    disconnect() {
        if (this.socket) {
            this.socket.disconnect();
            this.isConnected = false;
            this.isAuthenticated = false;
            console.log('Disconnected from WebSocket server');
        }
    }
    
    /**
     * Mark notification as read
     */
    markAsRead(notificationId) {
        if (this.socket && this.isConnected) {
            this.socket.emit('notification_read', { notificationId });
        }
    }
    
    /**
     * Join a room
     */
    joinRoom(room) {
        if (this.socket && this.isConnected) {
            this.socket.emit('join_room', room);
            console.log(`Joined room: ${room}`);
        }
    }
    
    /**
     * Leave a room
     */
    leaveRoom(room) {
        if (this.socket && this.isConnected) {
            this.socket.emit('leave_room', room);
            console.log(`Left room: ${room}`);
        }
    }
    
    /**
     * Play notification sound
     */
    playNotificationSound() {
        const soundEnabled = localStorage.getItem('notificationSound') !== 'false';
        
        if (soundEnabled && typeof Audio !== 'undefined') {
            try {
                const audio = new Audio('/assets/sounds/notification.mp3');
                audio.play().catch(error => {
                    console.log('Audio play failed:', error);
                });
            } catch (error) {
                console.log('Audio creation failed:', error);
            }
        }
    }
    
    /**
     * Update notification badge
     */
    updateNotificationBadge() {
        const badge = document.getElementById('notificationBadge');
        if (badge) {
            const currentCount = parseInt(badge.textContent) || 0;
            badge.textContent = currentCount + 1;
            badge.style.display = 'flex';
        }
    }
    
    /**
     * Handle error
     */
    handleError(error) {
        console.error('WebSocket error:', error);
        
        if (this.onError) {
            this.onError(error);
        }
    }
    
    /**
     * Get connection status
     */
    getConnectionStatus() {
        return {
            connected: this.isConnected,
            authenticated: this.isAuthenticated,
            reconnectAttempts: this.reconnectAttempts
        };
    }
}

// Initialize WebSocket manager when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is authenticated
    const isAuthenticated = document.body.getAttribute('data-authenticated') === 'true';
    
    if (!isAuthenticated) {
        return;
    }
    
    // Get WebSocket configuration from meta tags or defaults
    const wsServerUrl = document.querySelector('meta[name="ws-server-url"]')?.getAttribute('content') || window.location.hostname;
    const wsPort = document.querySelector('meta[name="ws-port"]')?.getAttribute('content') || 3001;
    const wsUseSSL = document.querySelector('meta[name="ws-use-ssl"]')?.getAttribute('content') === 'true';
    
    // Check if Socket.io is loaded
    if (typeof io === 'undefined') {
        console.warn('Socket.io not loaded. WebSocket notifications will not work.');
        console.warn('Include socket.io-client library: <script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>');
        return;
    }
    
    // Initialize WebSocket manager
    window.websocketManager = new WebSocketNotificationManager({
        serverUrl: wsServerUrl,
        port: wsPort,
        useSSL: wsUseSSL,
        autoReconnect: true,
        reconnectDelay: 5000,
        maxReconnectAttempts: 10,
        onNotification: function(notification) {
            // Dispatch custom event for other listeners
            const event = new CustomEvent('websocketNotification', {
                detail: notification
            });
            document.dispatchEvent(event);
            
            // Update existing notification poller if it exists
            if (window.notificationPoller) {
                window.notificationPoller.handleNewNotification(notification);
            }
        },
        onConnect: function() {
            console.log('WebSocket connected');
            document.body.classList.add('websocket-connected');
            document.body.classList.remove('websocket-disconnected');
            
            // Update status indicator
            const indicator = document.getElementById('wsStatusIndicator');
            const statusText = document.getElementById('wsStatusText');
            if (indicator && statusText) {
                indicator.style.display = 'flex';
                indicator.classList.remove('disconnected', 'connecting');
                indicator.classList.add('connected');
                statusText.textContent = 'Connected';
            }
        },
        onDisconnect: function(reason) {
            console.log('WebSocket disconnected:', reason);
            document.body.classList.add('websocket-disconnected');
            document.body.classList.remove('websocket-connected');
            
            // Update status indicator
            const indicator = document.getElementById('wsStatusIndicator');
            const statusText = document.getElementById('wsStatusText');
            if (indicator && statusText) {
                indicator.style.display = 'flex';
                indicator.classList.remove('connected', 'connecting');
                indicator.classList.add('disconnected');
                statusText.textContent = 'Disconnected';
            }
        },
        onError: function(error) {
            console.error('WebSocket error:', error);
        },
        onInitialNotifications: function(notifications) {
            console.log('Initial notifications received:', notifications.length);
            
            // Update notification badge
            const badge = document.getElementById('notificationBadge');
            if (badge) {
                const unreadCount = notifications.filter(n => !n.is_read).length;
                if (unreadCount > 0) {
                    badge.textContent = unreadCount > 99 ? '99+' : unreadCount;
                    badge.style.display = 'flex';
                }
            }
        }
    });
    
    // Connect to WebSocket server
    window.websocketManager.connect();
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WebSocketNotificationManager;
}
