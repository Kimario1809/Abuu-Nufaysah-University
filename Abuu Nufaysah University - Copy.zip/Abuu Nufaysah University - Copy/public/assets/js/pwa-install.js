/**
 * PWA Install Manager
 * Handles PWA installation prompt and button
 */

class PWAInstallManager {
    constructor() {
        this.deferredPrompt = null;
        this.installButton = null;
        this.isInstalled = false;
        this.init();
    }

    init() {
        // Check if already installed
        this.checkInstalled();
        
        // Listen for beforeinstallprompt event
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            this.deferredPrompt = e;
            this.showInstallButton();
        });

        // Listen for app installed event
        window.addEventListener('appinstalled', () => {
            this.deferredPrompt = null;
            this.isInstalled = true;
            this.hideInstallButton();
            this.showInstalledMessage();
        });

        // Create install button
        this.createInstallButton();
    }

    checkInstalled() {
        // Check if app is running in standalone mode
        const isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
                           window.navigator.standalone === true;
        
        if (isStandalone) {
            this.isInstalled = true;
        }
    }

    createInstallButton() {
        // Check if button already exists
        if (document.getElementById('pwaInstallBtn')) {
            this.installButton = document.getElementById('pwaInstallBtn');
            return;
        }

        // Create install button
        const button = document.createElement('button');
        button.id = 'pwaInstallBtn';
        button.className = 'pwa-install-btn';
        button.innerHTML = `
            <i class="bi bi-download"></i>
            <span>Install App</span>
        `;
        button.style.display = 'none';
        
        // Add click handler
        button.addEventListener('click', () => this.promptInstall());
        
        // Add to body
        document.body.appendChild(button);
        this.installButton = button;
    }

    showInstallButton() {
        if (this.installButton && !this.isInstalled) {
            this.installButton.style.display = 'flex';
        }
    }

    hideInstallButton() {
        if (this.installButton) {
            this.installButton.style.display = 'none';
        }
    }

    async promptInstall() {
        if (!this.deferredPrompt) {
            console.log('PWA install prompt not available');
            return;
        }

        // Show the install prompt
        this.deferredPrompt.prompt();

        // Wait for user response
        const { outcome } = await this.deferredPrompt.userChoice;
        
        console.log(`User response: ${outcome}`);

        // Clear the deferred prompt
        this.deferredPrompt = null;

        if (outcome === 'accepted') {
            this.isInstalled = true;
            this.hideInstallButton();
            this.showInstalledMessage();
        }
    }

    showInstalledMessage() {
        // Show toast message
        const toast = document.createElement('div');
        toast.className = 'toast show';
        toast.style.position = 'fixed';
        toast.style.top = '20px';
        toast.style.right = '20px';
        toast.style.zIndex = '10000';
        toast.innerHTML = `
            <div class="toast-header">
                <i class="bi bi-check-circle me-2"></i>
                <strong class="me-auto">App Installed</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                App installed successfully! You can now launch it from your home screen.
            </div>
        `;
        
        document.body.appendChild(toast);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            toast.remove();
        }, 5000);
        
        // Close button handler
        toast.querySelector('.btn-close').addEventListener('click', () => {
            toast.remove();
        });
    }
}

// Initialize on DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.pwaInstallManager = new PWAInstallManager();
    });
} else {
    window.pwaInstallManager = new PWAInstallManager();
}
