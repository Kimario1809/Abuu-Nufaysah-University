// ========================================
// Abuu Nufay'sah University - Main JS
// ========================================

$(document).ready(function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Handle form submissions with CSRF
    $('form[data-ajax="true"]').on('submit', function(e) {
        e.preventDefault();
        var form = $(this);
        var data = form.serialize();
        
        $.ajax({
            url: form.attr('action'),
            method: form.attr('method'),
            data: data,
            success: function(response) {
                if (response.success) {
                    showToast('Success', response.message, 'success');
                    if (response.redirect) {
                        setTimeout(function() {
                            window.location.href = response.redirect;
                        }, 1500);
                    }
                } else {
                    showToast('Error', response.message || 'An error occurred', 'danger');
                }
            },
            error: function(xhr) {
                var error = xhr.responseJSON;
                var message = error.message || 'An error occurred';
                if (error.errors) {
                    message = Object.values(error.errors).join('\n');
                }
                showToast('Error', message, 'danger');
            }
        });
    });
    
    // Toggle sidebar on mobile
    $('#sidebarToggle').on('click', function() {
        $('.sidebar').toggleClass('active');
    });
    
    // Auto close alerts
    $('.alert').delay(5000).fadeOut('slow');
    
    // Confirm delete
    $('[data-confirm]').on('click', function(e) {
        var message = $(this).data('confirm');
        if (!confirm(message)) {
            e.preventDefault();
        }
    });
});

// Toast notification system
function showToast(title, message, type = 'info') {
    var toast = $(`
        <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <strong class="me-auto">${title}</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>
    `);
    
    // Set toast color based on type
    if (type === 'success') {
        toast.addClass('border-success');
    } else if (type === 'danger') {
        toast.addClass('border-danger');
    } else if (type === 'warning') {
        toast.addClass('border-warning');
    }
    
    $('.toast-container').append(toast);
    var toastInstance = new bootstrap.Toast(toast, { autohide: true, delay: 5000 });
    toastInstance.show();
    
    // Auto remove after 5 seconds
    setTimeout(function() {
        toast.remove();
    }, 5000);
}

// Loading spinner
function showLoading() {
    var overlay = $('<div class="spinner-overlay"><div class="spinner-border text-light" role="status"></div></div>');
    $('body').append(overlay);
}

function hideLoading() {
    $('.spinner-overlay').remove();
}

// DataTable initialization
function initDataTable(tableId, options = {}) {
    var defaultOptions = {
        responsive: true,
        pageLength: 10,
        language: {
            search: 'Search:',
            lengthMenu: 'Show _MENU_ entries',
            info: 'Showing _START_ to _END_ of _TOTAL_ entries',
            infoEmpty: 'No entries available',
            infoFiltered: '(filtered from _MAX_ total entries)'
        }
    };
    
    var settings = $.extend({}, defaultOptions, options);
    return $(tableId).DataTable(settings);
}

// File upload preview
function previewFile(input, previewId) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            $(previewId).attr('src', e.target.result);
            $(previewId).show();
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// Form validation helper
function validateForm(formId) {
    var form = $(formId);
    var valid = true;
    
    form.find('[data-validate]').each(function() {
        var field = $(this);
        var rules = field.data('validate').split('|');
        var value = field.val().trim();
        var error = '';
        
        rules.forEach(function(rule) {
            if (rule === 'required' && value === '') {
                error = 'This field is required';
            } else if (rule === 'email' && value && !isValidEmail(value)) {
                error = 'Please enter a valid email address';
            } else if (rule.startsWith('min:') && value.length < parseInt(rule.split(':')[1])) {
                error = `Minimum ${rule.split(':')[1]} characters required`;
            } else if (rule.startsWith('max:') && value.length > parseInt(rule.split(':')[1])) {
                error = `Maximum ${rule.split(':')[1]} characters allowed`;
            }
        });
        
        if (error) {
            field.addClass('is-invalid');
            field.siblings('.invalid-feedback').text(error);
            valid = false;
        } else {
            field.removeClass('is-invalid');
            field.siblings('.invalid-feedback').text('');
        }
    });
    
    return valid;
}

function isValidEmail(email) {
    var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Export function for use in other modules
window.showToast = showToast;
window.showLoading = showLoading;
window.hideLoading = hideLoading;
window.initDataTable = initDataTable;
window.previewFile = previewFile;
window.validateForm = validateForm;