/**
 * Offline Detection Manager
 * Detects online/offline status and updates UI accordingly
 */

class OfflineDetectionManager {
    constructor() {
        this.isOnline = navigator.onLine;
        this.offlineIndicator = null;
        this.init();
    }

    init() {
        // Get offline indicator element
        this.offlineIndicator = document.getElementById('offlineIndicator');
        
        // Listen for online/offline events
        window.addEventListener('online', () => this.handleOnline());
        window.addEventListener('offline', () => this.handleOffline());
        
        // Initial check
        this.updateUI();
    }

    handleOnline() {
        this.isOnline = true;
        console.log('Network: Online');
        this.updateUI();
        
        // Show toast notification
        this.showToast('You are back online', 'success');
        
        // Sync any pending data
        this.syncPendingData();
    }

    handleOffline() {
        this.isOnline = false;
        console.log('Network: Offline');
        this.updateUI();
        
        // Show toast notification
        this.showToast('You are offline. Some features may be limited.', 'warning');
    }

    updateUI() {
        // Update offline indicator
        if (this.offlineIndicator) {
            this.offlineIndicator.style.display = this.isOnline ? 'none' : 'flex';
        }
        
        // Update body class
        if (this.isOnline) {
            document.body.classList.remove('offline');
        } else {
            document.body.classList.add('offline');
        }
    }

    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast show`;
        toast.style.position = 'fixed';
        toast.style.top = '20px';
        toast.style.left = '50%';
        toast.style.transform = 'translateX(-50%)';
        toast.style.zIndex = '10001';
        toast.style.minWidth = '300px';
        
        const bgClass = type === 'success' ? 'bg-success' : 
                        type === 'warning' ? 'bg-warning' : 'bg-info';
        
        toast.innerHTML = `
            <div class="toast-header ${bgClass} text-white">
                <i class="bi bi-${type === 'success' ? 'check-circle' : 'exclamation-circle'} me-2"></i>
                <strong class="me-auto">${type === 'success' ? 'Connected' : 'Offline'}</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        `;
        
        document.body.appendChild(toast);
        
        // Auto-dismiss after 3 seconds
        setTimeout(() => {
            toast.remove();
        }, 3000);
        
        // Close button handler
        toast.querySelector('.btn-close').addEventListener('click', () => {
            toast.remove();
        });
    }

    async syncPendingData() {
        // Sync pending notifications
        if ('serviceWorker' in navigator && 'sync' in ServiceWorkerRegistration.prototype) {
            try {
                const registration = await navigator.serviceWorker.ready;
                await registration.sync.register('sync-notifications');
                console.log('Background sync registered');
            } catch (error) {
                console.log('Sync registration failed:', error);
            }
        }
    }
}

// Initialize on DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.offlineDetectionManager = new OfflineDetectionManager();
    });
} else {
    window.offlineDetectionManager = new OfflineDetectionManager();
}
