/**
 * Service Worker for PWA and Push Notifications
 * Abuu Nufaysah University System
 */

const CACHE_NAME = 'abuu-university-v2';
const RUNTIME_CACHE = 'abuu-university-runtime-v2';

// Static assets to cache immediately
const urlsToCache = [
    '/',
    '/login',
    '/manifest.json',
    '/assets/css/style.css',
    '/assets/css/notifications.css',
    '/assets/css/websocket-status.css',
    '/assets/js/app.js',
    '/assets/js/notifications.js',
    '/assets/js/websocket.js',
    '/assets/js/chat.js',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css',
    'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css',
    'https://code.jquery.com/jquery-3.6.0.min.js',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js',
    'https://cdn.socket.io/4.5.4/socket.io.min.js'
];

// Install Service Worker
self.addEventListener('install', function(event) {
    console.log('[SW] Installing service worker...');
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(function(cache) {
                console.log('[SW] Caching app shell');
                return cache.addAll(urlsToCache);
            })
            .then(() => {
                console.log('[SW] Skip waiting');
                return self.skipWaiting();
            })
    );
});

// Activate Service Worker
self.addEventListener('activate', function(event) {
    console.log('[SW] Activating service worker...');
    event.waitUntil(
        caches.keys().then(function(cacheNames) {
            return Promise.all(
                cacheNames.map(function(cacheName) {
                    if (cacheName !== CACHE_NAME && cacheName !== RUNTIME_CACHE) {
                        console.log('[SW] Deleting old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        })
        .then(() => {
            console.log('[SW] Claiming clients');
            return self.clients.claim();
        })
    );
});

// Fetch Service Worker with Network-First strategy for API, Cache-First for assets
self.addEventListener('fetch', function(event) {
    const url = new URL(event.request.url);
    
    // Skip cross-origin requests
    if (url.origin !== location.origin) {
        return;
    }
    
    // API requests - Network First
    if (url.pathname.startsWith('/api/')) {
        event.respondWith(
            fetch(event.request)
                .then(response => {
                    // Cache successful API responses
                    if (response.ok) {
                        const responseClone = response.clone();
                        caches.open(RUNTIME_CACHE).then(cache => {
                            cache.put(event.request, responseClone);
                        });
                    }
                    return response;
                })
                .catch(() => {
                    // Return cached response if network fails
                    return caches.match(event.request);
                })
        );
        return;
    }
    
    // Static assets - Cache First
    if (url.pathname.startsWith('/assets/') || 
        url.pathname.startsWith('/cdn/') ||
        url.pathname.endsWith('.css') || 
        url.pathname.endsWith('.js') ||
        url.pathname.endsWith('.png') ||
        url.pathname.endsWith('.jpg') ||
        url.pathname.endsWith('.svg')) {
        event.respondWith(
            caches.match(event.request)
                .then(function(response) {
                    if (response) {
                        return response;
                    }
                    return fetch(event.request).then(response => {
                        const responseClone = response.clone();
                        caches.open(CACHE_NAME).then(cache => {
                            cache.put(event.request, responseClone);
                        });
                        return response;
                    });
                })
        );
        return;
    }
    
    // HTML pages - Network First, fallback to cache
    event.respondWith(
        fetch(event.request)
            .then(response => {
                if (response.ok) {
                    const responseClone = response.clone();
                    caches.open(RUNTIME_CACHE).then(cache => {
                        cache.put(event.request, responseClone);
                    });
                    return response;
                }
                throw new Error('Network response was not ok');
            })
            .catch(() => {
                return caches.match(event.request)
                    .then(response => {
                        if (response) {
                            return response;
                        }
                        // Return offline page if no cached version
                        return caches.match('/offline.html');
                    });
            })
    );
});

// Push Notification Handler
self.addEventListener('push', function(event) {
    let data = {
        title: 'New Notification',
        body: 'You have a new notification',
        icon: '/assets/images/logo-icon.png',
        badge: '/assets/images/badge-icon.png',
        data: {
            url: '/notifications'
        }
    };

    if (event.data) {
        try {
            data = event.data.json();
        } catch (e) {
            console.error('Error parsing push data:', e);
        }
    }

    const options = {
        body: data.body,
        icon: data.icon,
        badge: data.badge,
        vibrate: [200, 100, 200],
        data: data.data,
        requireInteraction: true,
        tag: 'abuu-notification-' + Date.now(),
        renotify: true,
        actions: [
            {
                action: 'view',
                title: 'View',
                icon: '/assets/images/view-icon.png'
            },
            {
                action: 'close',
                title: 'Close',
                icon: '/assets/images/close-icon.png'
            }
        ]
    };

    event.waitUntil(
        self.registration.showNotification(data.title, options)
    );
});

// Notification Click Handler
self.addEventListener('notificationclick', function(event) {
    event.notification.close();

    if (event.action === 'view') {
        event.waitUntil(
            clients.openWindow(event.notification.data.url || '/notifications')
        );
    } else if (event.action === 'close') {
        // Just close the notification
    } else {
        // Default action - open the URL
        event.waitUntil(
            clients.openWindow(event.notification.data.url || '/notifications')
        );
    }
});

// Sync Handler (for background sync)
self.addEventListener('sync', function(event) {
    if (event.tag === 'sync-notifications') {
        event.waitUntil(syncNotifications());
    }
});

/**
 * Sync notifications in background
 */
function syncNotifications() {
    return fetch('/api/notifications/sync', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        credentials: 'include'
    }).then(response => {
        if (!response.ok) {
            throw new Error('Sync failed');
        }
        return response.json();
    }).then(data => {
        console.log('Notifications synced:', data);
        return data;
    }).catch(error => {
        console.error('Sync error:', error);
    });
}

// Push Subscription Change Handler
self.addEventListener('pushsubscriptionchange', function(event) {
    const oldSubscription = event.oldSubscription;
    const newSubscription = event.newSubscription;

    event.waitUntil(
        // Send new subscription to server
        fetch('/api/push/subscribe', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': getCsrfToken()
            },
            credentials: 'include',
            body: JSON.stringify({
                subscription: newSubscription,
                oldSubscription: oldSubscription
            })
        }).then(response => {
            if (!response.ok) {
                throw new Error('Subscription update failed');
            }
            return response.json();
        }).then(data => {
            console.log('Subscription updated:', data);
        }).catch(error => {
            console.error('Subscription update error:', error);
        })
    );
});

/**
 * Get CSRF token from cookies
 */
function getCsrfToken() {
    const cookies = self.clients.matchAll().then(clients => {
        return clients.map(client => {
            // This won't work in service worker context
            // CSRF token should be passed from client
            return null;
        });
    });
    return '';
}

// Message Handler (for communication from client)
self.addEventListener('message', function(event) {
    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
});
