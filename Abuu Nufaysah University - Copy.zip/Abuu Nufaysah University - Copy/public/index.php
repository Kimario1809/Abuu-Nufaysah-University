<?php
// Define root path
define('ROOT_PATH', __DIR__ . '/..');

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Load Environment Variables
if (file_exists(__DIR__ . '/../.env')) {
    $lines = file(__DIR__ . '/../.env');
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line) || strpos($line, '#') === 0) continue;
        
        list($key, $value) = explode('=', $line, 2);
        $_ENV[trim($key)] = trim($value);
        putenv("$key=$value");
    }
}

// Autoloader
spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    $base_dir = __DIR__ . '/../app/';
    
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
});

// Error Handler
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    if (error_reporting() & $errno) {
        throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
    }
});

// Exception Handler
set_exception_handler(function($exception) {
    if ($_ENV['APP_DEBUG'] ?? false) {
        echo '<h1>Exception</h1>';
        echo '<p><strong>' . get_class($exception) . '</strong></p>';
        echo '<p>' . $exception->getMessage() . '</p>';
        echo '<p>File: ' . $exception->getFile() . ':' . $exception->getLine() . '</p>';
        echo '<pre>' . $exception->getTraceAsString() . '</pre>';
    } else {
        http_response_code(500);
        include __DIR__ . '/../views/errors/500.php';
    }
});

// Load Routes
require_once __DIR__ . '/../routes/web.php';

// Dispatch Router
$router->dispatch();