<?php
// Load environment variables
require_once __DIR__ . '/../app/core/Env.php';
App\Core\Env::load();

return [
    'host' => App\Core\Env::get('DB_HOST', 'localhost'),
    'port' => App\Core\Env::get('DB_PORT', '3306'),
    'database' => App\Core\Env::get('DB_DATABASE', 'abuu_nufaysah_university'),
    'username' => App\Core\Env::get('DB_USERNAME', 'root'),
    'password' => App\Core\Env::get('DB_PASSWORD', ''),
    'charset' => App\Core\Env::get('DB_CHARSET', 'utf8mb4'),
    'collation' => 'utf8mb4_unicode_ci',
    'prefix' => '',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
];