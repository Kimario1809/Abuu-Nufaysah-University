<?php
namespace App\Models;

use App\Core\Model;

class MessageFile extends Model {
    protected $table = 'message_files';
    protected $primaryKey = 'id';

    public static function getByMessage($messageId) {
        $db = self::getDB();
        $sql = "SELECT * FROM message_files WHERE message_id = ? ORDER BY id ASC";
        $stmt = $db->query($sql, [$messageId]);
        return $stmt->fetchAll();
    }

    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}
