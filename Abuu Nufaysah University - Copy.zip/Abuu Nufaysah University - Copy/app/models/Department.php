<?php
namespace App\Models;

use App\Core\Model;

class Department extends Model {
    protected $table = 'departments';
    protected $primaryKey = 'id';
    
    public static function getAll() {
        $db = self::getDB();
        $sql = "SELECT * FROM departments ORDER BY name";
        $stmt = $db->query($sql);
        return $stmt->fetchAll();
    }
    
    public static function getWithCounts() {
        $db = self::getDB();
        $sql = "SELECT d.*,
                    (SELECT COUNT(*) FROM students WHERE department_id = d.id AND status = 'active') as student_count,
                    (SELECT COUNT(*) FROM lecturers WHERE department_id = d.id) as lecturer_count,
                    (SELECT COUNT(*) FROM courses WHERE department_id = d.id AND is_active = 1) as course_count
                FROM departments d
                ORDER BY d.name";
        $stmt = $db->query($sql);
        return $stmt->fetchAll();
    }
    
    public static function findByCode($code) {
        $db = self::getDB();
        $sql = "SELECT * FROM departments WHERE code = ? LIMIT 1";
        $stmt = $db->query($sql, [$code]);
        return $stmt->fetch();
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}