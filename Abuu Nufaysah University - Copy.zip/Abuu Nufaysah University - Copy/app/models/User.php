<?php
namespace App\Models;

use App\Core\Model;

class User extends Model {
    protected $table = 'users';
    protected $primaryKey = 'id';
    
    public static function findByEmail($email) {
        $db = self::getDB();
        $sql = "SELECT * FROM users WHERE email = ? LIMIT 1";
        $stmt = $db->query($sql, [$email]);
        return $stmt->fetch();
    }

    public static function findByEmailOrPhone($identifier) {
        $db = self::getDB();
        $sql = "SELECT * FROM users WHERE email = ? OR phone = ? LIMIT 1";
        $stmt = $db->query($sql, [$identifier, $identifier]);
        return $stmt->fetch();
    }
    
    public static function findByUsername($username) {
        $db = self::getDB();
        $sql = "SELECT * FROM users WHERE username = ? LIMIT 1";
        $stmt = $db->query($sql, [$username]);
        return $stmt->fetch();
    }
    
    public static function updateLastLogin($userId) {
        $db = self::getDB();
        $sql = "UPDATE users SET last_login = NOW() WHERE id = ?";
        $db->query($sql, [$userId]);
    }
    
    public static function getRoleSpecificData($userId) {
        $user = self::find($userId);
        if (!$user) return null;
        
        switch ($user['role']) {
            case 'student':
                return Student::getByUserId($userId);
            case 'lecturer':
                return Lecturer::getByUserId($userId);
            case 'admin':
                return Admin::getByUserId($userId);
            default:
                return null;
        }
    }
    
    public static function changePassword($userId, $newPassword) {
        $db = self::getDB();
        $hash = password_hash($newPassword, PASSWORD_BCRYPT);
        $sql = "UPDATE users SET password_hash = ? WHERE id = ?";
        $db->query($sql, [$hash, $userId]);
        return true;
    }
    
    public static function deactivate($userId) {
        $db = self::getDB();
        $sql = "UPDATE users SET is_active = 0 WHERE id = ?";
        $db->query($sql, [$userId]);
        return true;
    }
    
    public static function activate($userId) {
        $db = self::getDB();
        $sql = "UPDATE users SET is_active = 1 WHERE id = ?";
        $db->query($sql, [$userId]);
        return true;
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}