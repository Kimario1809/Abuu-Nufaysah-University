<?php
namespace App\Models;

use App\Core\Model;

class Announcement extends Model {
    protected $table = 'announcements';
    protected $primaryKey = 'id';
    
    public static function getLatest($limit = 5) {
        $db = self::getDB();
        $sql = "SELECT a.*, u.full_name as author_name
                FROM announcements a
                INNER JOIN users u ON a.author_id = u.id
                WHERE a.is_published = 1 
                AND (a.expires_at IS NULL OR a.expires_at > NOW())
                ORDER BY a.created_at DESC
                LIMIT ?";
        $stmt = $db->query($sql, [$limit]);
        return $stmt->fetchAll();
    }
    
    public static function getRecent($days = 7) {
        $db = self::getDB();
        $sql = "SELECT a.*, u.full_name as author_name
                FROM announcements a
                INNER JOIN users u ON a.author_id = u.id
                WHERE a.is_published = 1
                AND a.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                ORDER BY a.created_at DESC";
        $stmt = $db->query($sql, [$days]);
        return $stmt->fetchAll();
    }
    
    public static function getRecentCount() {
        $db = self::getDB();
        $sql = "SELECT COUNT(*) as total
                FROM announcements
                WHERE is_published = 1
                AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
        $stmt = $db->query($sql);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    public static function getByTargetAudience($audience) {
        $db = self::getDB();
        $sql = "SELECT a.*, u.full_name as author_name
                FROM announcements a
                INNER JOIN users u ON a.author_id = u.id
                WHERE a.is_published = 1
                AND (a.target_audience = 'all' OR a.target_audience = ?)
                AND (a.expires_at IS NULL OR a.expires_at > NOW())
                ORDER BY a.priority DESC, a.created_at DESC";
        $stmt = $db->query($sql, [$audience]);
        return $stmt->fetchAll();
    }
    
    public static function createAnnouncement($data) {
        $db = self::getDB();
        $sql = "INSERT INTO announcements (title, content, author_id, author_role, priority, target_audience, department_id, course_id, expires_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $db->query($sql, [
            $data['title'],
            $data['content'],
            $data['author_id'],
            $data['author_role'],
            $data['priority'] ?? 'medium',
            $data['target_audience'] ?? 'all',
            $data['department_id'] ?? null,
            $data['course_id'] ?? null,
            $data['expires_at'] ?? null
        ]);
        return $db->lastInsertId();
    }
    
    public static function publish($id) {
        $db = self::getDB();
        $sql = "UPDATE announcements SET is_published = 1 WHERE id = ?";
        $db->query($sql, [$id]);
        return true;
    }
    
    public static function unpublish($id) {
        $db = self::getDB();
        $sql = "UPDATE announcements SET is_published = 0 WHERE id = ?";
        $db->query($sql, [$id]);
        return true;
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}