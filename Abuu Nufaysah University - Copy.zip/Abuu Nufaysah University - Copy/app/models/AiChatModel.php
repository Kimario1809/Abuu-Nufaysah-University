<?php
namespace App\Models;

use App\Core\Model;

class AiChatModel extends Model {
    protected $table = 'ai_chats';
    protected $primaryKey = 'id';

    public static function saveMessage($userId, $role, $sender, $message) {
        $db = \App\Core\Database::getInstance();
        $sql = 'INSERT INTO ai_chats (user_id, role, sender, message) VALUES (?, ?, ?, ?)';
        $db->query($sql, [$userId, $role, $sender, $message]);
        return true;
    }

    public static function getHistory($userId, $limit = 50) {
        $db = \App\Core\Database::getInstance();
        $sql = 'SELECT sender, message, created_at FROM ai_chats WHERE user_id = ? ORDER BY id ASC LIMIT ?';
        $stmt = $db->query($sql, [$userId, $limit]);
        return $stmt->fetchAll();
    }
}
