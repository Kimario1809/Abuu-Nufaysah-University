<?php
namespace App\Models;

use App\Core\Model;

class Student extends Model {
    protected $table = 'students';
    protected $primaryKey = 'id';
    
    public static function getByUserId($userId) {
        $db = self::getDB();
        $sql = "SELECT s.*, u.full_name, u.email, u.phone, u.avatar, 
                d.name as department_name, d.code as department_code
                FROM students s
                INNER JOIN users u ON s.user_id = u.id
                LEFT JOIN departments d ON s.department_id = d.id
                WHERE s.user_id = ?";
        $stmt = $db->query($sql, [$userId]);
        return $stmt->fetch();
    }
    
    public static function getByStudentId($studentId) {
        $db = self::getDB();
        $sql = "SELECT s.*, u.full_name, u.email, u.phone, u.avatar,
                d.name as department_name
                FROM students s
                INNER JOIN users u ON s.user_id = u.id
                LEFT JOIN departments d ON s.department_id = d.id
                WHERE s.student_id = ?";
        $stmt = $db->query($sql, [$studentId]);
        return $stmt->fetch();
    }
    
    public static function count() {
        $db = self::getDB();
        $sql = "SELECT COUNT(*) as total FROM students WHERE status = 'active'";
        $stmt = $db->query($sql);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    public static function getRecentEnrollments($limit = 10) {
        $db = self::getDB();
        $sql = "SELECT e.*, u.full_name as student_name, c.name as course_name
                FROM enrollments e
                INNER JOIN students s ON e.student_id = s.id
                INNER JOIN users u ON s.user_id = u.id
                INNER JOIN courses c ON e.course_id = c.id
                ORDER BY e.enrollment_date DESC
                LIMIT ?";
        $stmt = $db->query($sql, [$limit]);
        return $stmt->fetchAll();
    }
    
    public static function search($search, $department = null) {
        $db = self::getDB();
        $params = [];
        $sql = "SELECT s.*, u.full_name, u.email, d.name as department_name
                FROM students s
                INNER JOIN users u ON s.user_id = u.id
                LEFT JOIN departments d ON s.department_id = d.id
                WHERE 1=1";
        
        if ($search) {
            $sql .= " AND (u.full_name LIKE ? OR s.student_id LIKE ? OR u.email LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        
        if ($department) {
            $sql .= " AND s.department_id = ?";
            $params[] = $department;
        }
        
        $sql .= " ORDER BY u.full_name";
        $stmt = $db->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    public static function getTotalStudents() {
        return self::count();
    }
    
    public static function getByDepartment($departmentId) {
        $db = self::getDB();
        $sql = "SELECT s.*, u.full_name, u.email
                FROM students s
                INNER JOIN users u ON s.user_id = u.id
                WHERE s.department_id = ? AND s.status = 'active'";
        $stmt = $db->query($sql, [$departmentId]);
        return $stmt->fetchAll();
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}