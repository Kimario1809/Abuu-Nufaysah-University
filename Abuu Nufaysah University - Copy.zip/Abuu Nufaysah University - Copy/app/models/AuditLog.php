<?php
namespace App\Models;

use App\Core\Model;

class AuditLog extends Model {
    protected $table = 'audit_logs';
    protected $primaryKey = 'id';

    public static function log($userId, $action, $module, $details = '') {
        try {
            $db = self::getDB();
            $sql = "INSERT INTO audit_logs (user_id, action, module, details, created_at) VALUES (?, ?, ?, ?, NOW())";
            $db->query($sql, [$userId, $action, $module, $details]);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    public static function getRecent($limit = 50) {
        $db = self::getDB();
        $sql = "SELECT a.*, u.full_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.created_at DESC LIMIT ?";
        $stmt = $db->query($sql, [$limit]);
        return $stmt->fetchAll();
    }

    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}
