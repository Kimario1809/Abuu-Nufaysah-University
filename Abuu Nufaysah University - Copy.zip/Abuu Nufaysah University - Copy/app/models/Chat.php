<?php
namespace App\Models;

use App\Core\Model;

class Chat extends Model {
    protected $table = 'chats';
    protected $primaryKey = 'id';

    public static function findOrCreate($userOneId, $userTwoId) {
        $db = self::getDB();
        $sql = "SELECT * FROM chats WHERE (user_one_id = ? AND user_two_id = ?) OR (user_one_id = ? AND user_two_id = ?) LIMIT 1";
        $stmt = $db->query($sql, [$userOneId, $userTwoId, $userTwoId, $userOneId]);
        $chat = $stmt->fetch();

        if ($chat) {
            return $chat;
        }

        $id = self::create([
            'user_one_id' => $userOneId,
            'user_two_id' => $userTwoId,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return self::find($id);
    }

    public static function getForUser($userId) {
        $db = self::getDB();
        $sql = "SELECT c.*, u.id as contact_id, u.full_name as contact_name, u.role as contact_role,
                (SELECT m.body FROM messages m WHERE m.chat_id = c.id ORDER BY m.created_at DESC LIMIT 1) as last_message,
                (SELECT m.created_at FROM messages m WHERE m.chat_id = c.id ORDER BY m.created_at DESC LIMIT 1) as last_message_at
                FROM chats c
                INNER JOIN users u ON (u.id = c.user_one_id OR u.id = c.user_two_id)
                WHERE (c.user_one_id = ? OR c.user_two_id = ?) AND u.id != ?
                ORDER BY last_message_at DESC, c.created_at DESC";
        $stmt = $db->query($sql, [$userId, $userId, $userId]);
        return $stmt->fetchAll();
    }

    public static function getByUsers($userOneId, $userTwoId) {
        $db = self::getDB();
        $sql = "SELECT * FROM chats WHERE (user_one_id = ? AND user_two_id = ?) OR (user_one_id = ? AND user_two_id = ?) LIMIT 1";
        $stmt = $db->query($sql, [$userOneId, $userTwoId, $userTwoId, $userOneId]);
        return $stmt->fetch();
    }

    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}
