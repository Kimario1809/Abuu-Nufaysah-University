<?php
namespace App\Models;

use App\Core\Model;

class Lecturer extends Model {
    protected $table = 'lecturers';
    protected $primaryKey = 'id';
    
    public static function getByUserId($userId) {
        $db = self::getDB();
        $sql = "SELECT l.*, u.full_name, u.email, u.phone, u.avatar,
                d.name as department_name
                FROM lecturers l
                INNER JOIN users u ON l.user_id = u.id
                LEFT JOIN departments d ON l.department_id = d.id
                WHERE l.user_id = ?";
        $stmt = $db->query($sql, [$userId]);
        return $stmt->fetch();
    }
    
    public static function getByEmployeeId($employeeId) {
        $db = self::getDB();
        $sql = "SELECT l.*, u.full_name, u.email
                FROM lecturers l
                INNER JOIN users u ON l.user_id = u.id
                WHERE l.employee_id = ?";
        $stmt = $db->query($sql, [$employeeId]);
        return $stmt->fetch();
    }
    
    public static function getAll() {
        $db = self::getDB();
        $sql = "SELECT l.*, u.full_name, u.email, d.name as department_name
                FROM lecturers l
                INNER JOIN users u ON l.user_id = u.id
                LEFT JOIN departments d ON l.department_id = d.id
                ORDER BY u.full_name";
        $stmt = $db->query($sql);
        return $stmt->fetchAll();
    }
    
    public static function getByDepartment($departmentId) {
        $db = self::getDB();
        $sql = "SELECT l.*, u.full_name, u.email
                FROM lecturers l
                INNER JOIN users u ON l.user_id = u.id
                WHERE l.department_id = ?";
        $stmt = $db->query($sql, [$departmentId]);
        return $stmt->fetchAll();
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}