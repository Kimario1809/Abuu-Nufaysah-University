<?php
namespace App\Models;

use App\Core\Model;

class Permission extends Model {
    protected $table = 'permissions';
    protected $primaryKey = 'id';

    public static function create($data) {
        $permission = self::findByName($data['name']);
        if ($permission) {
            return $permission['id'];
        }

        $instance = new self();
        return $instance->create($data);
    }

    public static function all() {
        try {
            $db = self::getDB();
            $sql = "SELECT * FROM permissions ORDER BY module ASC, name ASC";
            $stmt = $db->query($sql);
            return $stmt->fetchAll();
        } catch (\Exception $e) {
            return [];
        }
    }

    public static function findByName($name) {
        $db = self::getDB();
        $sql = "SELECT * FROM permissions WHERE name = ? LIMIT 1";
        $stmt = $db->query($sql, [$name]);
        return $stmt->fetch();
    }

    public static function getAllPermissions() {
        return self::all();
    }

    public static function getByRole($roleName) {
        try {
            $db = self::getDB();
            $sql = "SELECT p.* FROM permissions p INNER JOIN role_permissions rp ON rp.permission_id = p.id INNER JOIN roles r ON r.id = rp.role_id WHERE r.name = ? ORDER BY p.module ASC, p.name ASC";
            $stmt = $db->query($sql, [$roleName]);
            return $stmt->fetchAll();
        } catch (\Exception $e) {
            return [];
        }
    }

    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}
