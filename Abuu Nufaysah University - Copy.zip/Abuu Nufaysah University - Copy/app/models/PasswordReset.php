<?php
namespace App\Models;

use App\Core\Model;

class PasswordReset extends Model {
    protected $table = 'password_resets';
    protected $primaryKey = 'id';
    
    public static function createRecord($data) {
        $db = self::getDB();
        $sql = "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)";
        $db->query($sql, [$data['user_id'], $data['token'], $data['expires_at']]);
        return $db->lastInsertId();
    }
    
    public static function findByToken($token) {
        $db = self::getDB();
        $sql = "SELECT * FROM password_resets WHERE token = ? AND expires_at > NOW() LIMIT 1";
        $stmt = $db->query($sql, [$token]);
        return $stmt->fetch();
    }
    
    public static function deleteByUserId($userId) {
        $db = self::getDB();
        $sql = "DELETE FROM password_resets WHERE user_id = ?";
        $db->query($sql, [$userId]);
        return true;
    }
    
    public static function deleteExpired() {
        $db = self::getDB();
        $sql = "DELETE FROM password_resets WHERE expires_at < NOW()";
        $db->query($sql);
        return true;
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}