<?php
namespace App\Models;

use App\Core\Model;

class Enrollment extends Model {
    protected $table = 'enrollments';
    protected $primaryKey = 'id';
    
    public static function getByStudent($studentId) {
        $db = self::getDB();
        $sql = "SELECT e.*, c.code as course_code, c.name as course_name,
                c.credit_hours, c.semester, c.year,
                l.full_name as lecturer_name
                FROM enrollments e
                INNER JOIN courses c ON e.course_id = c.id
                LEFT JOIN lecturers l ON c.lecturer_id = l.id
                LEFT JOIN users u ON l.user_id = u.id
                WHERE e.student_id = ?
                ORDER BY c.year, c.semester";
        $stmt = $db->query($sql, [$studentId]);
        return $stmt->fetchAll();
    }
    
    public static function getByCourse($courseId) {
        $db = self::getDB();
        $sql = "SELECT e.*, u.full_name as student_name, s.student_id
                FROM enrollments e
                INNER JOIN students s ON e.student_id = s.id
                INNER JOIN users u ON s.user_id = u.id
                WHERE e.course_id = ? AND e.status = 'enrolled'
                ORDER BY u.full_name";
        $stmt = $db->query($sql, [$courseId]);
        return $stmt->fetchAll();
    }
    
    public static function exists($studentId, $courseId) {
        $db = self::getDB();
        $sql = "SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?";
        $stmt = $db->query($sql, [$studentId, $courseId]);
        return $stmt->fetch() !== false;
    }
    
    public static function countByStudent($studentId) {
        $db = self::getDB();
        $sql = "SELECT COUNT(*) as total FROM enrollments WHERE student_id = ? AND status = 'enrolled'";
        $stmt = $db->query($sql, [$studentId]);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    public static function countByLecturer($lecturerId) {
        $db = self::getDB();
        $sql = "SELECT COUNT(DISTINCT e.student_id) as total
                FROM enrollments e
                INNER JOIN courses c ON e.course_id = c.id
                WHERE c.lecturer_id = ? AND e.status = 'enrolled'";
        $stmt = $db->query($sql, [$lecturerId]);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    public static function dropCourse($studentId, $courseId) {
        $db = self::getDB();
        $sql = "UPDATE enrollments SET status = 'dropped' 
                WHERE student_id = ? AND course_id = ?";
        $db->query($sql, [$studentId, $courseId]);
        return true;
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}