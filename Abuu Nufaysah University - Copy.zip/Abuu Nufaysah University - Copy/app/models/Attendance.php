<?php
namespace App\Models;

use App\Core\Model;

class Attendance extends Model {
    protected $table = 'attendance';
    protected $primaryKey = 'id';
    
    public static function getByStudent($studentId) {
        $db = self::getDB();
        $sql = "SELECT a.*, c.code as course_code, c.name as course_name
                FROM attendance a
                INNER JOIN enrollments e ON a.enrollment_id = e.id
                INNER JOIN courses c ON e.course_id = c.id
                WHERE e.student_id = ?
                ORDER BY a.date DESC";
        $stmt = $db->query($sql, [$studentId]);
        return $stmt->fetchAll();
    }
    
    public static function getRateByStudent($studentId) {
        $db = self::getDB();
        $sql = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status IN ('present', 'late') THEN 1 ELSE 0 END) as present
                FROM attendance a
                INNER JOIN enrollments e ON a.enrollment_id = e.id
                WHERE e.student_id = ?";
        $stmt = $db->query($sql, [$studentId]);
        $result = $stmt->fetch();
        
        if (!$result || $result['total'] == 0) return 0;
        return round(($result['present'] / $result['total']) * 100, 2);
    }
    
    public static function getByDate($date) {
        $db = self::getDB();
        $sql = "SELECT a.*, u.full_name as student_name, c.code as course_code
                FROM attendance a
                INNER JOIN enrollments e ON a.enrollment_id = e.id
                INNER JOIN students s ON e.student_id = s.id
                INNER JOIN users u ON s.user_id = u.id
                INNER JOIN courses c ON e.course_id = c.id
                WHERE a.date = ?
                ORDER BY u.full_name";
        $stmt = $db->query($sql, [$date]);
        return $stmt->fetchAll();
    }
    
    public static function markAttendance($enrollmentId, $date, $status, $timeIn = null, $timeOut = null) {
        $db = self::getDB();
        
        // Check if already marked
        $sql = "SELECT id FROM attendance WHERE enrollment_id = ? AND date = ?";
        $stmt = $db->query($sql, [$enrollmentId, $date]);
        
        if ($stmt->fetch()) {
            // Update
            $sql = "UPDATE attendance 
                    SET status = ?, time_in = ?, time_out = ? 
                    WHERE enrollment_id = ? AND date = ?";
            $db->query($sql, [$status, $timeIn, $timeOut, $enrollmentId, $date]);
        } else {
            // Create
            $sql = "INSERT INTO attendance (enrollment_id, date, status, time_in, time_out) 
                    VALUES (?, ?, ?, ?, ?)";
            $db->query($sql, [$enrollmentId, $date, $status, $timeIn, $timeOut]);
        }
        
        return true;
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}