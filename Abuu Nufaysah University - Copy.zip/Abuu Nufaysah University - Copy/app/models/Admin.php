<?php
namespace App\Models;

use App\Core\Model;

class Admin extends Model {
    protected $table = 'admins';
    protected $primaryKey = 'id';
    
    public static function getByUserId($userId) {
        $db = self::getDB();
        $sql = "SELECT a.*, u.full_name, u.email, u.phone
                FROM admins a
                INNER JOIN users u ON a.user_id = u.id
                WHERE a.user_id = ?";
        $stmt = $db->query($sql, [$userId]);
        return $stmt->fetch();
    }
    
    public static function getByAdminId($adminId) {
        $db = self::getDB();
        $sql = "SELECT a.*, u.full_name, u.email
                FROM admins a
                INNER JOIN users u ON a.user_id = u.id
                WHERE a.admin_id = ?";
        $stmt = $db->query($sql, [$adminId]);
        return $stmt->fetch();
    }
    
    public static function getAll() {
        $db = self::getDB();
        $sql = "SELECT a.*, u.full_name, u.email
                FROM admins a
                INNER JOIN users u ON a.user_id = u.id
                ORDER BY u.full_name";
        $stmt = $db->query($sql);
        return $stmt->fetchAll();
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}