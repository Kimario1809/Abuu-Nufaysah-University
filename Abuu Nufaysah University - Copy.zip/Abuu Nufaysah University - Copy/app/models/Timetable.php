<?php
namespace App\Models;

use App\Core\Model;

class Timetable extends Model {
    protected $table = 'timetables';
    protected $primaryKey = 'id';
    
    public static function getByStudent($studentId) {
        $db = self::getDB();
        $sql = "SELECT t.*, c.code as course_code, c.name as course_name,
                u.full_name as lecturer_name
                FROM timetables t
                INNER JOIN courses c ON t.course_id = c.id
                LEFT JOIN lecturers l ON t.lecturer_id = l.id
                LEFT JOIN users u ON l.user_id = u.id
                WHERE t.course_id IN (
                    SELECT course_id FROM enrollments 
                    WHERE student_id = ? AND status = 'enrolled'
                )
                AND t.is_active = 1
                ORDER BY FIELD(t.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'), t.start_time";
        $stmt = $db->query($sql, [$studentId]);
        return $stmt->fetchAll();
    }
    
    public static function getByLecturer($lecturerId) {
        $db = self::getDB();
        $sql = "SELECT t.*, c.code as course_code, c.name as course_name
                FROM timetables t
                INNER JOIN courses c ON t.course_id = c.id
                WHERE t.lecturer_id = ? AND t.is_active = 1
                ORDER BY FIELD(t.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'), t.start_time";
        $stmt = $db->query($sql, [$lecturerId]);
        return $stmt->fetchAll();
    }
    
    public static function getByCourse($courseId) {
        $db = self::getDB();
        $sql = "SELECT t.*, u.full_name as lecturer_name
                FROM timetables t
                LEFT JOIN lecturers l ON t.lecturer_id = l.id
                LEFT JOIN users u ON l.user_id = u.id
                WHERE t.course_id = ? AND t.is_active = 1
                ORDER BY FIELD(t.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'), t.start_time";
        $stmt = $db->query($sql, [$courseId]);
        return $stmt->fetchAll();
    }
    
    public static function checkConflict($lecturerId, $dayOfWeek, $startTime, $endTime, $excludeId = null) {
        $db = self::getDB();
        $sql = "SELECT id FROM timetables 
                WHERE lecturer_id = ? 
                AND day_of_week = ? 
                AND is_active = 1
                AND ((start_time <= ? AND end_time > ?) OR (start_time < ? AND end_time >= ?))
                AND id != ?";
        $stmt = $db->query($sql, [$lecturerId, $dayOfWeek, $startTime, $startTime, $endTime, $endTime, $excludeId ?? 0]);
        return $stmt->fetch() !== false;
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}