<?php
namespace App\Models;

use App\Core\Model;

class PushSubscription extends Model {
    protected $table = 'push_subscriptions';
    protected $primaryKey = 'id';
    
    /**
     * Get subscription by user ID
     * 
     * @param int $userId User ID
     * @return array|null
     */
    public static function getByUserId($userId) {
        $db = self::getDB();
        $sql = "SELECT * FROM push_subscriptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1";
        $stmt = $db->query($sql, [$userId]);
        return $stmt->fetch();
    }
    
    /**
     * Get subscription by endpoint
     * 
     * @param string $endpoint Subscription endpoint
     * @return array|null
     */
    public static function getByEndpoint($endpoint) {
        $db = self::getDB();
        $sql = "SELECT * FROM push_subscriptions WHERE endpoint = ?";
        $stmt = $db->query($sql, [$endpoint]);
        return $stmt->fetch();
    }
    
    /**
     * Create or update subscription
     * 
     * @param array $data Subscription data
     * @return int Subscription ID
     */
    public static function createOrUpdate($data) {
        $db = self::getDB();
        
        // Check if subscription already exists
        $existing = self::getByEndpoint($data['endpoint']);
        
        if ($existing) {
            // Update existing subscription
            $sql = "UPDATE push_subscriptions 
                    SET user_id = ?, 
                        p256dh_key = ?, 
                        auth_key = ?, 
                        updated_at = CURRENT_TIMESTAMP 
                    WHERE id = ?";
            $db->query($sql, [
                $data['user_id'],
                $data['p256dh_key'],
                $data['auth_key'],
                $existing['id']
            ]);
            return $existing['id'];
        }
        
        // Create new subscription
        $sql = "INSERT INTO push_subscriptions (user_id, endpoint, p256dh_key, auth_key) 
                VALUES (?, ?, ?, ?)";
        $db->query($sql, [
            $data['user_id'],
            $data['endpoint'],
            $data['p256dh_key'],
            $data['auth_key']
        ]);
        return $db->lastInsertId();
    }
    
    /**
     * Delete subscription
     * 
     * @param string $endpoint Subscription endpoint
     * @return bool
     */
    public static function deleteByEndpoint($endpoint) {
        $db = self::getDB();
        $sql = "DELETE FROM push_subscriptions WHERE endpoint = ?";
        $db->query($sql, [$endpoint]);
        return true;
    }
    
    /**
     * Delete subscription by user ID
     * 
     * @param int $userId User ID
     * @return bool
     */
    public static function deleteByUserId($userId) {
        $db = self::getDB();
        $sql = "DELETE FROM push_subscriptions WHERE user_id = ?";
        $db->query($sql, [$userId]);
        return true;
    }
    
    /**
     * Get all active subscriptions
     * 
     * @return array
     */
    public static function getAllActive() {
        $db = self::getDB();
        $sql = "SELECT * FROM push_subscriptions WHERE is_active = 1";
        $stmt = $db->query($sql);
        return $stmt->fetchAll();
    }
    
    /**
     * Get subscriptions by role
     * 
     * @param string $role User role
     * @return array
     */
    public static function getByRole($role) {
        $db = self::getDB();
        $sql = "SELECT ps.* FROM push_subscriptions ps
                INNER JOIN users u ON ps.user_id = u.id
                WHERE u.role = ? AND ps.is_active = 1";
        $stmt = $db->query($sql, [$role]);
        return $stmt->fetchAll();
    }
    
    /**
     * Deactivate subscription
     * 
     * @param int $id Subscription ID
     * @return bool
     */
    public static function deactivate($id) {
        $db = self::getDB();
        $sql = "UPDATE push_subscriptions SET is_active = 0 WHERE id = ?";
        $db->query($sql, [$id]);
        return true;
    }
    
    /**
     * Activate subscription
     * 
     * @param int $id Subscription ID
     * @return bool
     */
    public static function activate($id) {
        $db = self::getDB();
        $sql = "UPDATE push_subscriptions SET is_active = 1 WHERE id = ?";
        $db->query($sql, [$id]);
        return true;
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}
