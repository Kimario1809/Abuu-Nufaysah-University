<?php
namespace App\Models;

use App\Core\Model;

class Notification extends Model {
    protected $table = 'notifications';
    protected $primaryKey = 'id';
    
    /**
     * Get notifications for a user (both user-specific and role-based)
     * 
     * @param int $userId User ID
     * @param string $userRole User role (admin, lecturer, student)
     * @param int $limit Limit number of results
     * @param string $since Get notifications since this timestamp
     * @return array
     */
    public static function getByUser($userId, $userRole = null, $limit = 10, $since = null) {
        $db = self::getDB();
        $params = [];
        
        // Build query to get both user-specific and role-based notifications
        $sql = "SELECT * FROM notifications WHERE (user_id = ? OR user_id IS NULL)";
        $params[] = $userId;
        
        // Add role filter if provided
        if ($userRole) {
            $sql .= " AND (target_role = ? OR target_role = 'all')";
            $params[] = $userRole;
        } else {
            $sql .= " AND target_role = 'all'";
        }
        
        // Add time filter if provided
        if ($since) {
            $sql .= " AND created_at > ?";
            $params[] = $since;
        }
        
        $sql .= " ORDER BY created_at DESC LIMIT ?";
        $params[] = $limit;
        
        $stmt = $db->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    /**
     * Get unread count for a user (including role-based notifications)
     * 
     * @param int $userId User ID
     * @param string $userRole User role
     * @return int
     */
    public static function getUnreadCount($userId, $userRole = null) {
        $db = self::getDB();
        $params = [];
        
        $sql = "SELECT COUNT(*) as total FROM notifications 
                WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0";
        $params[] = $userId;
        
        if ($userRole) {
            $sql .= " AND (target_role = ? OR target_role = 'all')";
            $params[] = $userRole;
        } else {
            $sql .= " AND target_role = 'all'";
        }
        
        $stmt = $db->query($sql, $params);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    /**
     * Mark notification as read
     * 
     * @param int $id Notification ID
     * @return bool
     */
    public static function markAsRead($id) {
        $db = self::getDB();
        $sql = "UPDATE notifications SET is_read = 1 WHERE id = ?";
        $db->query($sql, [$id]);
        return true;
    }
    
    /**
     * Mark all notifications as read for a user
     * 
     * @param int $userId User ID
     * @return bool
     */
    public static function markAllAsRead($userId) {
        $db = self::getDB();
        $sql = "UPDATE notifications SET is_read = 1 WHERE user_id = ?";
        $db->query($sql, [$userId]);
        return true;
    }
    
    /**
     * Create a notification
     * 
     * @param array $data Notification data
     * @return int Notification ID
     */
    public static function create($data) {
        $db = self::getDB();
        $sql = "INSERT INTO notifications (user_id, target_role, type, title, message, link) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $db->query($sql, [
            $data['user_id'] ?? null,
            $data['target_role'] ?? 'all',
            $data['type'] ?? 'info',
            $data['title'],
            $data['message'],
            $data['link'] ?? null
        ]);
        return $db->lastInsertId();
    }
    
    /**
     * Create notification for specific users
     * 
     * @param array $userIds Array of user IDs
     * @param array $data Notification data
     * @return array Created notification IDs
     */
    public static function createForUsers($userIds, $data) {
        $db = self::getDB();
        $ids = [];
        
        foreach ($userIds as $userId) {
            $notificationData = array_merge($data, ['user_id' => $userId]);
            $ids[] = self::create($notificationData);
        }
        
        return $ids;
    }
    
    /**
     * Create notification for specific role
     * 
     * @param string $targetRole Target role (admin, lecturer, student, all)
     * @param array $data Notification data
     * @return int Notification ID
     */
    public static function createForRole($targetRole, $data) {
        $data['target_role'] = $targetRole;
        $data['user_id'] = null; // Role-based notifications don't have specific user
        return self::create($data);
    }
    
    /**
     * Get role-specific notification types
     * 
     * @param string $role User role
     * @return array Allowed notification types
     */
    public static function getRoleNotificationTypes($role) {
        $types = [
            'admin' => ['info', 'success', 'warning', 'error', 'payment', 'result', 'announcement', 'system', 'assignment', 'grade', 'chat'],
            'lecturer' => ['info', 'success', 'warning', 'assignment', 'grade', 'chat', 'announcement'],
            'student' => ['info', 'success', 'warning', 'payment', 'result', 'assignment', 'grade', 'chat', 'announcement']
        ];
        
        return $types[$role] ?? ['info', 'success', 'warning'];
    }
    
    /**
     * Get recent notifications for a role (for admin dashboard)
     * 
     * @param string $role Target role
     * @param int $limit Limit
     * @return array
     */
    public static function getRecentByRole($role, $limit = 20) {
        $db = self::getDB();
        $sql = "SELECT * FROM notifications 
                WHERE target_role = ? OR target_role = 'all'
                ORDER BY created_at DESC LIMIT ?";
        $stmt = $db->query($sql, [$role, $limit]);
        return $stmt->fetchAll();
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}