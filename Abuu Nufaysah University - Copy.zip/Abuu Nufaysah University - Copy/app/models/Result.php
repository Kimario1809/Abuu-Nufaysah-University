<?php
namespace App\Models;

use App\Core\Model;

class Result extends Model {
    protected $table = 'results';
    protected $primaryKey = 'id';
    
    public static function getByStudent($studentId) {
        $db = self::getDB();
        $sql = "SELECT r.*, c.code as course_code, c.name as course_name,
                c.credit_hours, e.id as enrollment_id
                FROM results r
                INNER JOIN enrollments e ON r.enrollment_id = e.id
                INNER JOIN courses c ON e.course_id = c.id
                WHERE e.student_id = ? AND r.is_published = 1
                ORDER BY c.year DESC, c.semester DESC";
        $stmt = $db->query($sql, [$studentId]);
        return $stmt->fetchAll();
    }
    
    public static function getByLecturer($lecturerId) {
        $db = self::getDB();
        $sql = "SELECT r.*, u.full_name as student_name, s.student_id,
                c.code as course_code, c.name as course_name
                FROM results r
                INNER JOIN enrollments e ON r.enrollment_id = e.id
                INNER JOIN courses c ON e.course_id = c.id
                INNER JOIN students s ON e.student_id = s.id
                INNER JOIN users u ON s.user_id = u.id
                WHERE c.lecturer_id = ? AND r.is_published = 0
                ORDER BY r.created_at DESC";
        $stmt = $db->query($sql, [$lecturerId]);
        return $stmt->fetchAll();
    }
    
    public static function getPendingByLecturer($lecturerId) {
        $db = self::getDB();
        $sql = "SELECT COUNT(*) as total
                FROM results r
                INNER JOIN enrollments e ON r.enrollment_id = e.id
                INNER JOIN courses c ON e.course_id = c.id
                WHERE c.lecturer_id = ? AND r.is_published = 0";
        $stmt = $db->query($sql, [$lecturerId]);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    public static function countPendingByLecturer($lecturerId) {
        return self::getPendingByLecturer($lecturerId);
    }
    
    public static function calculateGPA($studentId) {
        $results = self::getByStudent($studentId);
        if (empty($results)) return 0;
        
        $totalPoints = 0;
        $totalCredits = 0;
        
        foreach ($results as $result) {
            $totalPoints += $result['grade_point'] * $result['credit_hours'];
            $totalCredits += $result['credit_hours'];
        }
        
        return $totalCredits > 0 ? round($totalPoints / $totalCredits, 2) : 0;
    }
    
    public static function calculateCGPA($studentId) {
        // For simplicity, we'll use the same as GPA
        // In a real system, this would be cumulative across all semesters
        return self::calculateGPA($studentId);
    }
    
    public static function publish($resultId) {
        $db = self::getDB();
        $sql = "UPDATE results SET is_published = 1 WHERE id = ?";
        $db->query($sql, [$resultId]);
        return true;
    }
    
    public static function getGrade($score) {
        if ($score >= 80) return ['grade' => 'A', 'point' => 4.0];
        if ($score >= 75) return ['grade' => 'B+', 'point' => 3.5];
        if ($score >= 70) return ['grade' => 'B', 'point' => 3.0];
        if ($score >= 65) return ['grade' => 'C+', 'point' => 2.5];
        if ($score >= 60) return ['grade' => 'C', 'point' => 2.0];
        if ($score >= 55) return ['grade' => 'D+', 'point' => 1.5];
        if ($score >= 50) return ['grade' => 'D', 'point' => 1.0];
        return ['grade' => 'F', 'point' => 0.0];
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}