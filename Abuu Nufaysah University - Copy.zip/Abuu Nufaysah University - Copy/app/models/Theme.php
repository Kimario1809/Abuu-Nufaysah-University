<?php
namespace App\Models;

use App\Core\Model;

class Theme extends Model {
    protected $table = 'user_themes';
    protected $primaryKey = 'id';

    public static function getByUserId($userId) {
        $db = self::getDB();
        $sql = "SELECT * FROM user_themes WHERE user_id = ? LIMIT 1";
        $stmt = $db->query($sql, [$userId]);
        return $stmt->fetch();
    }

    public static function saveForUser($userId, $themeName, $customColors) {
        $existing = self::getByUserId($userId);
        $data = [
            'user_id' => $userId,
            'theme_name' => $themeName,
            'custom_colors' => json_encode($customColors),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if ($existing) {
            self::getDB()->query("UPDATE user_themes SET theme_name = ?, custom_colors = ?, updated_at = NOW() WHERE user_id = ?", [$themeName, json_encode($customColors), $userId]);
            return self::getByUserId($userId);
        }

        self::getDB()->query("INSERT INTO user_themes (user_id, theme_name, custom_colors, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())", [$userId, $themeName, json_encode($customColors)]);
        return self::getByUserId($userId);
    }

    public static function getPresetThemes() {
        return [
            ['name' => 'Default Blue Theme', 'primary' => '#0d6efd', 'secondary' => '#6c757d', 'bg' => '#f4f7ff', 'text' => '#1f2937', 'sidebar' => '#1f2937', 'card' => '#ffffff'],
            ['name' => 'Dark Mode Theme', 'primary' => '#22c55e', 'secondary' => '#64748b', 'bg' => '#111827', 'text' => '#f9fafb', 'sidebar' => '#020617', 'card' => '#1f2937'],
            ['name' => 'Light Minimal Theme', 'primary' => '#64748b', 'secondary' => '#94a3b8', 'bg' => '#f8fafc', 'text' => '#0f172a', 'sidebar' => '#ffffff', 'card' => '#ffffff'],
            ['name' => 'Green Academic Theme', 'primary' => '#16a34a', 'secondary' => '#4b5563', 'bg' => '#f0fdf4', 'text' => '#14532d', 'sidebar' => '#14532d', 'card' => '#ffffff'],
            ['name' => 'Purple Modern Theme', 'primary' => '#7c3aed', 'secondary' => '#a78bfa', 'bg' => '#f5f3ff', 'text' => '#2e1065', 'sidebar' => '#2e1065', 'card' => '#ffffff'],
            ['name' => 'Red Alert Theme', 'primary' => '#dc2626', 'secondary' => '#f87171', 'bg' => '#fef2f2', 'text' => '#7f1d1d', 'sidebar' => '#7f1d1d', 'card' => '#ffffff'],
            ['name' => 'Orange Energy Theme', 'primary' => '#f59e0b', 'secondary' => '#fb923c', 'bg' => '#fff7ed', 'text' => '#9a2c00', 'sidebar' => '#9a2c00', 'card' => '#ffffff'],
            ['name' => 'Black Pro Hacker Theme', 'primary' => '#00ff88', 'secondary' => '#00d4ff', 'bg' => '#000000', 'text' => '#e2e8f0', 'sidebar' => '#111111', 'card' => '#111111'],
            ['name' => 'Gradient Ocean Theme', 'primary' => '#0ea5e9', 'secondary' => '#14b8a6', 'bg' => '#ecfeff', 'text' => '#082f49', 'sidebar' => '#0f172a', 'card' => '#ffffff'],
            ['name' => 'Gradient Sunset Theme', 'primary' => '#fb923c', 'secondary' => '#f43f5e', 'bg' => '#fff1f2', 'text' => '#7c2d12', 'sidebar' => '#7c2d12', 'card' => '#ffffff'],
            ['name' => 'Glassmorphism Theme', 'primary' => '#38bdf8', 'secondary' => '#818cf8', 'bg' => '#e0f2fe', 'text' => '#0f172a', 'sidebar' => '#ffffff', 'card' => 'rgba(255,255,255,0.6)'],
            ['name' => 'Corporate Gray Theme', 'primary' => '#475569', 'secondary' => '#94a3b8', 'bg' => '#f8fafc', 'text' => '#111827', 'sidebar' => '#334155', 'card' => '#ffffff'],
            ['name' => 'Teal Education Theme', 'primary' => '#0f766e', 'secondary' => '#2dd4bf', 'bg' => '#f0fdfa', 'text' => '#042f2e', 'sidebar' => '#115e59', 'card' => '#ffffff'],
            ['name' => 'Midnight Navy Theme', 'primary' => '#1d4ed8', 'secondary' => '#60a5fa', 'bg' => '#020617', 'text' => '#f8fafc', 'sidebar' => '#0f172a', 'card' => '#111827'],
            ['name' => 'Neon Cyber Theme', 'primary' => '#ff00ff', 'secondary' => '#00f5ff', 'bg' => '#040816', 'text' => '#f0fdfa', 'sidebar' => '#0f172a', 'card' => '#111827']
        ];
    }

    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}
