<?php
namespace App\Models;

use App\Core\Model;

class ActivityLog extends Model {
    protected $table = 'activity_logs';
    protected $primaryKey = 'id';
    
    /**
     * Log an activity
     * 
     * @param array $data Activity data
     * @return int Log ID
     */
    public static function log($data) {
        $db = self::getDB();
        $sql = "INSERT INTO activity_logs (user_id, action, entity_type, entity_id, description, ip_address, user_agent, metadata) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        $db->query($sql, [
            $data['user_id'] ?? null,
            $data['action'],
            $data['entity_type'] ?? null,
            $data['entity_id'] ?? null,
            $data['description'] ?? null,
            $data['ip_address'] ?? self::getClientIP(),
            $data['user_agent'] ?? self::getUserAgent(),
            isset($data['metadata']) ? json_encode($data['metadata']) : null
        ]);
        
        return $db->lastInsertId();
    }
    
    /**
     * Get logs by user ID
     * 
     * @param int $userId User ID
     * @param int $limit Limit
     * @param int $offset Offset
     * @return array
     */
    public static function getByUserId($userId, $limit = 50, $offset = 0) {
        $db = self::getDB();
        $sql = "SELECT al.*, u.full_name, u.email, u.role 
                FROM activity_logs al
                LEFT JOIN users u ON al.user_id = u.id
                WHERE al.user_id = ?
                ORDER BY al.created_at DESC
                LIMIT ? OFFSET ?";
        $stmt = $db->query($sql, [$userId, $limit, $offset]);
        return $stmt->fetchAll();
    }
    
    /**
     * Get logs by action
     * 
     * @param string $action Action name
     * @param int $limit Limit
     * @param int $offset Offset
     * @return array
     */
    public static function getByAction($action, $limit = 50, $offset = 0) {
        $db = self::getDB();
        $sql = "SELECT al.*, u.full_name, u.email, u.role 
                FROM activity_logs al
                LEFT JOIN users u ON al.user_id = u.id
                WHERE al.action = ?
                ORDER BY al.created_at DESC
                LIMIT ? OFFSET ?";
        $stmt = $db->query($sql, [$action, $limit, $offset]);
        return $stmt->fetchAll();
    }
    
    /**
     * Get logs by entity
     * 
     * @param string $entityType Entity type
     * @param int $entityId Entity ID
     * @param int $limit Limit
     * @return array
     */
    public static function getByEntity($entityType, $entityId, $limit = 50) {
        $db = self::getDB();
        $sql = "SELECT al.*, u.full_name, u.email, u.role 
                FROM activity_logs al
                LEFT JOIN users u ON al.user_id = u.id
                WHERE al.entity_type = ? AND al.entity_id = ?
                ORDER BY al.created_at DESC
                LIMIT ?";
        $stmt = $db->query($sql, [$entityType, $entityId, $limit]);
        return $stmt->fetchAll();
    }
    
    /**
     * Get all logs with filtering
     * 
     * @param array $filters Filters (user_id, action, entity_type, date_from, date_to)
     * @param int $limit Limit
     * @param int $offset Offset
     * @return array
     */
    public static function getAll($filters = [], $limit = 100, $offset = 0) {
        $db = self::getDB();
        $params = [];
        
        $sql = "SELECT al.*, u.full_name, u.email, u.role 
                FROM activity_logs al
                LEFT JOIN users u ON al.user_id = u.id
                WHERE 1=1";
        
        if (isset($filters['user_id'])) {
            $sql .= " AND al.user_id = ?";
            $params[] = $filters['user_id'];
        }
        
        if (isset($filters['action'])) {
            $sql .= " AND al.action = ?";
            $params[] = $filters['action'];
        }
        
        if (isset($filters['entity_type'])) {
            $sql .= " AND al.entity_type = ?";
            $params[] = $filters['entity_type'];
        }
        
        if (isset($filters['date_from'])) {
            $sql .= " AND al.created_at >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (isset($filters['date_to'])) {
            $sql .= " AND al.created_at <= ?";
            $params[] = $filters['date_to'];
        }
        
        $sql .= " ORDER BY al.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $db->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    /**
     * Count logs with filtering
     * 
     * @param array $filters Filters
     * @return int
     */
    public static function count($filters = []) {
        $db = self::getDB();
        $params = [];
        
        $sql = "SELECT COUNT(*) as total FROM activity_logs WHERE 1=1";
        
        if (isset($filters['user_id'])) {
            $sql .= " AND user_id = ?";
            $params[] = $filters['user_id'];
        }
        
        if (isset($filters['action'])) {
            $sql .= " AND action = ?";
            $params[] = $filters['action'];
        }
        
        if (isset($filters['entity_type'])) {
            $sql .= " AND entity_type = ?";
            $params[] = $filters['entity_type'];
        }
        
        if (isset($filters['date_from'])) {
            $sql .= " AND created_at >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (isset($filters['date_to'])) {
            $sql .= " AND created_at <= ?";
            $params[] = $filters['date_to'];
        }
        
        $stmt = $db->query($sql, $params);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    /**
     * Get recent logs
     * 
     * @param int $limit Limit
     * @return array
     */
    public static function getRecent($limit = 20) {
        $db = self::getDB();
        $sql = "SELECT al.*, u.full_name, u.email, u.role 
                FROM activity_logs al
                LEFT JOIN users u ON al.user_id = u.id
                ORDER BY al.created_at DESC
                LIMIT ?";
        $stmt = $db->query($sql, [$limit]);
        return $stmt->fetchAll();
    }
    
    /**
     * Get activity statistics
     * 
     * @param int $days Number of days
     * @return array
     */
    public static function getStatistics($days = 30) {
        $db = self::getDB();
        
        $sql = "SELECT 
                    action,
                    entity_type,
                    COUNT(*) as count,
                    DATE(created_at) as date
                FROM activity_logs
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                GROUP BY action, entity_type, DATE(created_at)
                ORDER BY date DESC, count DESC";
        
        $stmt = $db->query($sql, [$days]);
        return $stmt->fetchAll();
    }
    
    /**
     * Get client IP address
     * 
     * @return string
     */
    private static function getClientIP() {
        $ip = '';
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        }
        
        return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '';
    }
    
    /**
     * Get user agent
     * 
     * @return string
     */
    private static function getUserAgent() {
        return $_SERVER['HTTP_USER_AGENT'] ?? '';
    }
    
    /**
     * Delete old logs
     * 
     * @param int $days Days to keep
     * @return int Number of deleted logs
     */
    public static function deleteOld($days = 90) {
        $db = self::getDB();
        $sql = "DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)";
        $stmt = $db->query($sql, [$days]);
        return $stmt->rowCount();
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}
