<?php
namespace App\Models;

use App\Core\Model;

class Course extends Model {
    protected $table = 'courses';
    protected $primaryKey = 'id';
    
    public static function getAll() {
        $db = self::getDB();
        $sql = "SELECT c.*, d.name as department_name, 
                u.full_name as lecturer_name
                FROM courses c
                LEFT JOIN departments d ON c.department_id = d.id
                LEFT JOIN lecturers l ON c.lecturer_id = l.id
                LEFT JOIN users u ON l.user_id = u.id
                WHERE c.is_active = 1
                ORDER BY c.code";
        $stmt = $db->query($sql);
        return $stmt->fetchAll();
    }
    
    public static function getByLecturer($lecturerId, $onlyActive = false) {
        $db = self::getDB();
        $sql = "SELECT c.*, d.name as department_name
                FROM courses c
                LEFT JOIN departments d ON c.department_id = d.id
                WHERE c.lecturer_id = ?";
        if ($onlyActive) {
            $sql .= " AND c.is_active = 1";
        }
        $sql .= " ORDER BY c.code";
        $stmt = $db->query($sql, [$lecturerId]);
        return $stmt->fetchAll();
    }
    
    public static function countByLecturer($lecturerId) {
        $db = self::getDB();
        $sql = "SELECT COUNT(*) as total FROM courses WHERE lecturer_id = ? AND is_active = 1";
        $stmt = $db->query($sql, [$lecturerId]);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    public static function getTotalStudentsByLecturer($lecturerId) {
        $db = self::getDB();
        $sql = "SELECT COUNT(DISTINCT e.student_id) as total
                FROM enrollments e
                INNER JOIN courses c ON e.course_id = c.id
                WHERE c.lecturer_id = ? AND e.status = 'enrolled'";
        $stmt = $db->query($sql, [$lecturerId]);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    public static function hasCapacity($courseId) {
        $db = self::getDB();
        $sql = "SELECT c.capacity, COUNT(e.id) as enrolled
                FROM courses c
                LEFT JOIN enrollments e ON c.id = e.course_id AND e.status = 'enrolled'
                WHERE c.id = ?
                GROUP BY c.id";
        $stmt = $db->query($sql, [$courseId]);
        $result = $stmt->fetch();
        
        if (!$result) return false;
        return $result['enrolled'] < $result['capacity'];
    }
    
    public static function count() {
        $db = self::getDB();
        $sql = "SELECT COUNT(*) as total FROM courses WHERE is_active = 1";
        $stmt = $db->query($sql);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}