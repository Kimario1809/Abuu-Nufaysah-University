<?php
namespace App\Models;

use App\Core\Model;

class Role extends Model {
    protected $table = 'roles';
    protected $primaryKey = 'id';

    public static function create($data) {
        $role = self::findByName($data['name']);
        if ($role) {
            return $role['id'];
        }

        $instance = new self();
        return $instance->create($data);
    }

    public static function findByName($name) {
        $db = self::getDB();
        $sql = "SELECT * FROM roles WHERE name = ? LIMIT 1";
        $stmt = $db->query($sql, [$name]);
        return $stmt->fetch();
    }

    public static function getUserRoles($userId) {
        try {
            $db = self::getDB();
            $sql = "SELECT r.* FROM roles r INNER JOIN user_roles ur ON ur.role_id = r.id WHERE ur.user_id = ?";
            $stmt = $db->query($sql, [$userId]);
            return $stmt->fetchAll();
        } catch (\Exception $e) {
            return [];
        }
    }

    public static function assignPermission($roleId, $permissionId) {
        try {
            $db = self::getDB();
            $sql = "INSERT IGNORE INTO role_permissions (role_id, permission_id, created_at) VALUES (?, ?, NOW())";
            $db->query($sql, [$roleId, $permissionId]);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    public static function assignUserRole($userId, $roleId) {
        try {
            $db = self::getDB();
            $sql = "INSERT IGNORE INTO user_roles (user_id, role_id, created_at) VALUES (?, ?, NOW())";
            $db->query($sql, [$userId, $roleId]);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}
