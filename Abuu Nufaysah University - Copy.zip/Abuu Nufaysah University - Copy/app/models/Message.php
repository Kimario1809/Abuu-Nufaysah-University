<?php
namespace App\Models;

use App\Core\Model;

class Message extends Model {
    protected $table = 'messages';
    protected $primaryKey = 'id';

    public static function getByChat($chatId) {
        $db = self::getDB();
        $sql = "SELECT m.*, u.full_name as sender_name, u.role as sender_role
                FROM messages m
                LEFT JOIN users u ON u.id = m.sender_id
                WHERE m.chat_id = ?
                ORDER BY m.created_at ASC";
        $stmt = $db->query($sql, [$chatId]);
        $messages = $stmt->fetchAll();

        foreach ($messages as &$message) {
            $message['files'] = MessageFile::getByMessage($message['id']);
        }

        return $messages;
    }

    public static function createMessage($data) {
        $id = self::create([
            'chat_id' => $data['chat_id'],
            'sender_id' => $data['sender_id'],
            'body' => $data['body'] ?? '',
            'message_type' => $data['message_type'] ?? 'text',
            'status' => $data['status'] ?? 'sent',
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return self::find($id);
    }

    public static function markRead($chatId, $userId) {
        $db = self::getDB();
        $sql = "UPDATE messages SET status = 'read' WHERE chat_id = ? AND sender_id != ? AND status != 'read'";
        $db->query($sql, [$chatId, $userId]);
        return true;
    }

    public static function getUnreadCount($userId) {
        $db = self::getDB();
        $sql = "SELECT COUNT(*) as total FROM messages m
                INNER JOIN chats c ON c.id = m.chat_id
                WHERE (c.user_one_id = ? OR c.user_two_id = ?) AND m.sender_id != ? AND m.status != 'read'";
        $stmt = $db->query($sql, [$userId, $userId, $userId]);
        $result = $stmt->fetch();
        return (int)($result['total'] ?? 0);
    }

    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}
