<?php
namespace App\Models;

use App\Core\Model;

class Payment extends Model {
    protected $table = 'payments';
    protected $primaryKey = 'id';
    
    public static function getByStudent($studentId) {
        $db = self::getDB();
        $sql = "SELECT p.*, u.full_name as student_name, s.student_id
                FROM payments p
                INNER JOIN students s ON p.student_id = s.id
                INNER JOIN users u ON s.user_id = u.id
                WHERE p.student_id = ?
                ORDER BY p.payment_date DESC";
        $stmt = $db->query($sql, [$studentId]);
        return $stmt->fetchAll();
    }
    
    public static function getPendingByStudent($studentId) {
        $db = self::getDB();
        $sql = "SELECT SUM(amount) as total
                FROM payments
                WHERE student_id = ? AND status IN ('pending', 'overdue')";
        $stmt = $db->query($sql, [$studentId]);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    public static function getPendingTotal() {
        $db = self::getDB();
        $sql = "SELECT SUM(amount) as total
                FROM payments
                WHERE status IN ('pending', 'overdue')";
        $stmt = $db->query($sql);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    public static function getPendingCount() {
        $db = self::getDB();
        $sql = "SELECT COUNT(*) as total
                FROM payments
                WHERE status IN ('pending', 'overdue')";
        $stmt = $db->query($sql);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    public static function getTotalRevenue() {
        $db = self::getDB();
        $sql = "SELECT SUM(amount) as total
                FROM payments
                WHERE status = 'paid'";
        $stmt = $db->query($sql);
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    
    public static function markAsPaid($paymentId, $transactionId = null) {
        $db = self::getDB();
        $sql = "UPDATE payments 
                SET status = 'paid', payment_date = NOW(), transaction_id = ?
                WHERE id = ?";
        $db->query($sql, [$transactionId, $paymentId]);
        return true;
    }
    
    public static function generateReceiptNo() {
        return 'REC-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
    }

    public static function formatAmount($amount, $currency = 'USD') {
        $currency = strtoupper($currency);
        if ($currency === 'TSH') {
            return number_format((float)$amount, 0) . ' TSH';
        }
        return '$' . number_format((float)$amount, 2);
    }
    
    private static function getDB() {
        return \App\Core\Database::getInstance();
    }
}