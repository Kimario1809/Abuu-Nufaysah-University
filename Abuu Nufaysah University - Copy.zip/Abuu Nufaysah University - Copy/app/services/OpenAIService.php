<?php
namespace App\Services;

class OpenAIService {
    private $apiKey;
    private $baseUrl;

    public function __construct() {
        $this->apiKey = $_ENV['OPENAI_API_KEY'] ?? getenv('OPENAI_API_KEY') ?: '';
        $this->baseUrl = 'https://api.openai.com/v1/responses';
    }

    public function ask($prompt, $context = []) {
        if (empty($this->apiKey)) {
            return ['success' => false, 'message' => 'OpenAI API key is not configured.'];
        }

        $payload = [
            'model' => 'gpt-4o-mini',
            'input' => [
                [
                    'role' => 'system',
                    'content' => 'You are a helpful AI assistant for an academic student system. Answer in Swahili or English. Use only the provided context and never invent data.'
                ],
                [
                    'role' => 'user',
                    'content' => $prompt . "\n\nContext:\n" . json_encode($context)
                ]
            ],
            'temperature' => 0.2
        ];

        $ch = curl_init($this->baseUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->apiKey
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            return ['success' => false, 'message' => 'OpenAI request failed.', 'http_code' => $httpCode, 'raw' => $response];
        }

        $data = json_decode($response, true);
        $text = $data['output'][0]['content'][0]['text'] ?? ($data['choices'][0]['message']['content'] ?? '');

        return ['success' => true, 'answer' => $text];
    }
}
