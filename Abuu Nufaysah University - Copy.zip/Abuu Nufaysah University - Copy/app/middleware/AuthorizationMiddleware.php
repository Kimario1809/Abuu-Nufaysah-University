<?php
namespace App\Middleware;

use App\Core\Auth;
use App\Core\Session;

class AuthorizationMiddleware {
    private $auth;
    private $session;

    public function __construct() {
        $this->auth = Auth::getInstance();
        $this->session = Session::getInstance();
    }

    public function handle($permission = null, $module = null) {
        if (!$this->auth->isAuthenticated()) {
            $this->session->setFlash('error', 'Please login to continue');
            header('Location: /login');
            exit;
        }

        if ($this->auth->getCurrentRole() === 'admin') {
            return true;
        }

        if ($permission && !$this->auth->checkPermission($permission)) {
            $this->session->setFlash('error', 'You do not have permission to access this resource');
            header('Location: /' . $this->auth->getCurrentRole() . '/dashboard');
            exit;
        }

        if ($module && !$this->auth->canAccessModule($module)) {
            $this->session->setFlash('error', 'This module is not available for your role');
            header('Location: /' . $this->auth->getCurrentRole() . '/dashboard');
            exit;
        }

        return true;
    }
}
