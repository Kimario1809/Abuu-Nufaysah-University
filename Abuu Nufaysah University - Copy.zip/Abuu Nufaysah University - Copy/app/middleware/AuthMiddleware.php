<?php
namespace App\Middleware;

use App\Core\Auth;
use App\Core\Session;
use App\Core\RateLimiter;

class AuthMiddleware {
    private $auth;
    private $session;
    private $rateLimiter;
    
    public function __construct() {
        $this->auth = Auth::getInstance();
        $this->session = Session::getInstance();
        $this->rateLimiter = RateLimiter::getInstance();
    }
    
    /**
     * Require authentication
     * Redirects to login if not authenticated
     * 
     * @return bool
     */
    public function handle() {
        // Validate session to prevent session fixation
        if (!$this->session->validate()) {
            $this->session->destroy();
            $this->session->setFlash('error', 'Session expired. Please login again');
            header('Location: /login');
            exit;
        }
        
        if (!$this->auth->isAuthenticated()) {
            $this->session->setFlash('error', 'Please login to continue');
            header('Location: /login');
            exit;
        }
        return true;
    }
    
    /**
     * Check rate limiting before login attempt
     * 
     * @param string $ip IP address
     * @return array|bool Returns error array if rate limited, true otherwise
     */
    public function checkRateLimit($ip) {
        if ($this->rateLimiter->isRateLimited($ip)) {
            $seconds = $this->rateLimiter->availableIn($ip);
            return [
                'success' => false,
                'message' => "Too many login attempts. Please try again in {$seconds} seconds."
            ];
        }
        return true;
    }
    
    /**
     * Record failed login attempt
     * 
     * @param string $ip IP address
     * @param string $email Email/identifier
     * @return void
     */
    public function recordFailedAttempt($ip, $email = null) {
        $this->rateLimiter->recordAttempt($ip, $email);
    }
    
    /**
     * Clear login attempts on successful login
     * 
     * @param string $ip IP address
     * @return void
     */
    public function clearAttempts($ip) {
        $this->rateLimiter->clearAttempts($ip);
    }
}