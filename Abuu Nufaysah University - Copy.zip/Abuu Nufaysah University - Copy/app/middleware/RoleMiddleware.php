<?php
namespace App\Middleware;

use App\Core\Auth;
use App\Core\Session;

class RoleMiddleware {
    private $auth;
    private $session;
    
    // Role-based module access permissions
    private $rolePermissions = [
        'admin' => [
            'dashboard', 'users', 'students', 'lecturers', 'courses', 'grades',
            'attendance', 'assignments', 'chat', 'reports', 'settings', 'ai',
            'announcements', 'departments', 'faculties', 'finance', 'library',
            'hostel', 'system', 'audit'
        ],
        'lecturer' => [
            'dashboard', 'courses', 'grades', 'attendance', 'assignments',
            'chat', 'announcements', 'students', 'submissions'
        ],
        'student' => [
            'dashboard', 'announcements', 'assignments', 'grades', 'attendance',
            'chat', 'courses', 'submissions', 'profile'
        ]
    ];
    
    public function __construct() {
        $this->auth = Auth::getInstance();
        $this->session = Session::getInstance();
    }
    
    /**
     * Require specific role(s)
     * 
     * @param string|array $roles Required role(s)
     * @return bool
     */
    public function handle($roles = ['admin']) {
        if (!$this->auth->isAuthenticated()) {
            $this->session->setFlash('error', 'Please login to continue');
            header('Location: /login');
            exit;
        }
        
        $userRole = $this->auth->getCurrentRole();
        $roles = (array)$roles;
        
        if (!in_array($userRole, $roles)) {
            $this->session->setFlash('error', 'You do not have permission to access this page');
            header('Location: /' . $userRole . '/dashboard');
            exit;
        }
        
        return true;
    }
    
    /**
     * Check if user has access to specific module
     * 
     * @param string $module Module name
     * @return bool
     */
    public function canAccessModule($module) {
        if (!$this->auth->isAuthenticated()) {
            return false;
        }
        
        $userRole = $this->auth->getCurrentRole();
        
        if (!isset($this->rolePermissions[$userRole])) {
            return false;
        }
        
        return in_array($module, $this->rolePermissions[$userRole]);
    }
    
    /**
     * Require access to specific module
     * 
     * @param string $module Module name
     * @return bool
     */
    public function requireModule($module) {
        if (!$this->canAccessModule($module)) {
            $this->session->setFlash('error', 'You do not have permission to access this module');
            $userRole = $this->auth->getCurrentRole();
            header('Location: /' . $userRole . '/dashboard');
            exit;
        }
        return true;
    }
    
    /**
     * Check if user has specific permission
     * 
     * @param string $permission Permission name
     * @return bool
     */
    public function hasPermission($permission) {
        return $this->auth->checkPermission($permission);
    }
    
    /**
     * Require specific permission
     * 
     * @param string $permission Permission name
     * @return bool
     */
    public function requirePermission($permission) {
        if (!$this->hasPermission($permission)) {
            $this->session->setFlash('error', 'You do not have permission to perform this action');
            $userRole = $this->auth->getCurrentRole();
            header('Location: /' . $userRole . '/dashboard');
            exit;
        }
        return true;
    }
    
    /**
     * Get allowed modules for current user's role
     * 
     * @return array
     */
    public function getAllowedModules() {
        $userRole = $this->auth->getCurrentRole();
        return $this->rolePermissions[$userRole] ?? [];
    }
}